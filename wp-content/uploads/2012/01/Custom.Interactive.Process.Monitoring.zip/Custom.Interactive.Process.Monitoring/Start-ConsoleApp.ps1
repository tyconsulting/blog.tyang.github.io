#===========================================================================================
# AUTHOR:  Tao Yang 
# DATE:    16/01/2012
# Version: 1.0
# COMMENT: Start a exe on console session under LocalSystem Context
#===========================================================================================
param([string]$PsExecPath, [string]$PathToExe, [string]$Context, [string]$Arguments)
# $Context should have only 2 possible values: "System" or "User". "User" needs Auto Admin Logon Enabled
Function Get-ConsoleSessionInfo
{
$results = Query Session
$ConsoleSession = $results | select-string "console\s+(\w+)\s+(\d+)\s+(\w+)"
if ($ConsoleSession)
{
	$UserName = $ConsoleSession.Matches[0].groups[1].value
	$SessionID = $ConsoleSession.Matches[0].groups[2].value
	$State = $ConsoleSession.Matches[0].groups[3].value
	$objConsoleSession = New-Object psobject
	Add-Member -InputObject $objConsoleSession -Name "UserName" -Value $UserName -MemberType NoteProperty
	Add-Member -InputObject $objConsoleSession -Name "SessionID" -Value $SessionID -MemberType NoteProperty
	Add-Member -InputObject $objConsoleSession -Name "State" -Value $State -MemberType NoteProperty
} else { $objConsoleSession = $null }
Return $objConsoleSession
}

$Mode = $null
#Determine UserID
If ($Context -ieq "User")
{
	$strUserName = $null
	$DefaultPassword = $null
	#detect if auto admin is enabled, if so, retrieve username and password from registry
	$WinlogonRegKey = get-itemproperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\"
	If ($WinlogonRegKey.AutoAdminLogon = "1")
	{
		$DefaultUserName = $WinlogonRegKey.DefaultUserName
		$DefaultDomainName = $WinlogonRegKey.DefaultDomainName
		$DefaultPassword = $WinlogonRegKey.DefaultPassword
		$strUserName = "$DefaultDomainName`\$DefaultUserName"
	}
	
	If ($strUserName -and $DefaultPassword)
	{
		$Mode = "User"
	} else {
		Write-Error "Owner variable set to `"User`" but Auto Admin Logon is not configured!"
	}
} elseif ($Context -ieq "System") {
	$Mode = "System"
} else {
	Write-Error "Incorrect Owner variable. it can only be `"User`" or `"System`""
}

#$thisScript = Split-Path $myInvocation.MyCommand.Path -Leaf
#$scriptRoot = Split-Path(Resolve-Path $myInvocation.MyCommand.Path)
#$PsExecPath = Join-Path $scriptRoot "PsExec.exe"
If (!(Test-Path $PsExecPath))
{
	Write-Error "Unable to locate PsExec.exe in $scriptRoot. Please make sure it is located in this directory!"
} else {
	#Get Console Session ID
	$ConsoleSessionID = (Get-ConsoleSessionInfo).SessionID
	if ($ConsoleSessionID)
	{
		If ($Mode -eq "User")
		{
			$strCmd = "$PsExecPath -accepteula -i $ConsoleSessionID -d -u $strUsername -p $DefaultPassword $PathToExe $arguments"
			Write-Host "Executing $strCmd`..."
			Invoke-Expression $strCmd
		} elseif ($Mode -eq "System") {
			$strCmd = "$PsExecPath -accepteula -i $ConsoleSessionID -d -s $PathToExe $arguments"
			#run app under LOCALSYSTEM context
			Write-Host "Executing $strCmd`..."
			Invoke-Expression $strCmd
		}
	} else {
		Write-Error "No one is currently logged on to the console session at the moment."
	}
}