#===========================================================================================
# AUTHOR:         	Tao Yang
# Script Name:    	Enable-AgentProxy.ps1
# DATE:           	06/0\9/2012
# Version:        	2.5
# COMMENT:			- Script to enable Agent Proxy for all agents
#===========================================================================================
Param (
[Parameter(Mandatory=$false)]
[int]$SQLQueryTimeout = 120,
[Parameter(Mandatory=$false)]
[string]$ManagementServer = $env:COMPUTERNAME)

#Region FunctionLibs
function Load-SDK()
{
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.EnterpriseManagement.OperationsManager.Common") | Out-Null
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.EnterpriseManagement.OperationsManager") | Out-Null
}
#EndRegion

#Read SCOM Operational DB location from management server registry
$objReg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $ManagementServer)
$objRegKey= $objReg.OpenSubKey("SOFTWARE\\Microsoft\\Microsoft Operations Manager\\3.0\\Setup" )
$OpsDBServerName = $objRegKey.GetValue("DatabaseServerName")
$OpsDBName = $objRegKey.GetValue("DatabaseName")

#Read Default SDK service computer name from the management server
$objRegKey= $objReg.OpenSubKey("SOFTWARE\\Microsoft\\Microsoft Operations Manager\\3.0\\Machine Settings" )
$MachineRegKeyPath = "HKLM:\software\Microsoft\Microsoft Operations Manager\3.0\Machine Settings"
$SDKServiceMachine = $objRegKey.GetValue("DefaultSDKServiceMachine")

If (!$SDKServiceMachine)
{
	#can't detect the default SDK service machine, cannot continue...
	Exit
}

#Connect to Ops DB
$conString = "Server`=$OpsDBServerName;Integrated Security=true;Initial Catalog=$OpsDBName"
$SQLCon = New-Object System.Data.SqlClient.SqlConnection
$SQLCon.ConnectionString = $conString
$SQLCon.Open()
$sqlCmd = $SQLCon.CreateCommand()

#Note Remote Mangeable agents count before update
$strSQLQuery = @"
select bme.Path AS 'AgentName' from MT_HealthService mths 
INNER JOIN BaseManagedEntity bme on bme.BaseManagedEntityId = mths.BaseManagedEntityId 
where (ProxyingEnabled = 0 OR ProxyingEnabled IS NULL) AND IsManagementServer = 0
"@
$sqlCmd.CommandTimeout=$SQLQueryTimeout
$sqlCmd.CommandText = $strSQLQuery
$Reader = $sqlCmd.ExecuteReader()
$Counter = $Reader.FieldCount

$ProxyingEnabledForAll = $true
$arrAgentNames = New-Object system.Collections.ArrayList
while ($Reader.Read()) {
	$ProxyingEnabledForAll = $false
	for ($i = 0; $i -lt $Counter; $i++) {
		$AgentName = $Reader.GetValue($i)
	}
	[Void]$arrAgentNames.Add($AgentName)
}
$Reader.close()
$SQLCon.Close()
$agentsCount = $arrAgentNames.count

#Turn on Agent Proxy for the agents detected
If (!$ProxyingEnabledForAll)
{
	Load-SDK
	$MGConnSetting = New-Object Microsoft.EnterpriseManagement.ManagementGroupConnectionSettings($SDKServiceMachine)
	$MG = New-Object Microsoft.EnterpriseManagement.ManagementGroup($MGConnSetting)

	#Get Management Group administration
	$Admin = $MG.GetAdministration()
	#Update
	Foreach ($AgentName in $arrAgentNames)
	{
	$query = "Name= '$AgentName'"
	$AgentCriteria = New-Object Microsoft.EnterpriseManagement.Administration.AgentManagedComputerCriteria($query)
	$Agent = ($Admin.GetAgentManagedComputers($AgentCriteria))[0]
	Write-Host "Enabling Agent proxy for $AgentName`..." -ForegroundColor Green
	$Agent.ProxyingEnabled = $true
	$Agent.ApplyChanges()
	}
}
