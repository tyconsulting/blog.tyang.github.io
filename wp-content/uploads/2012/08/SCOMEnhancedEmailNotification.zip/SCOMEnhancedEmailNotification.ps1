#Requires -version 2
#=====================================================================================================
# AUTHOR:	Tao Yang 
# DATE:		30/09/2010
# Name:		SCOMEnhancedEmailNotification.PS1
# Version:	2.0
# COMMENT:	SCOM Enhanced Email notification which includes detailed alert information
# Update:	30/09/2010	- Removed GetNetbiosName function
#						- Reformatted HTML email body
#						- Added error handling for $rule.GetKnowledgeArticle() as sometimes there is no knowledge article.
#			16/08/2012	- Updated SMTP setting so it can use external SMTP that requies authentication
#						- Moved all scripts customisations to the external config XML file.
#						- Rewritten the script to use SCOM SDK rather than using PowerShell Snap-ins / Modules. Now also works on SCOM 2012.
# Usage:	On SCOM 2007 RMS or SCOM 2012 MS: .\SCOMEnhancedEmailNotification.ps1 -alertID xxxxx -WebConsoleLink xxxxxxxx -Recipients @('John Smith;john.smith@xxx.com','Bill Gates;billgates@xxxx.com','Osama Bin Laden;Osama.BinLaden@whitehouse.gov')
#=====================================================================================================

param([string]$alertID,[string]$WebConsoleLink,[string[]]$Recipients)
$error.clear()


#Region Function Libs
function Load-SDK()
{
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.EnterpriseManagement.OperationsManager.Common") | Out-Null
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.EnterpriseManagement.OperationsManager") | Out-Null
}

##any other resolution state created in SCOM need to be added to this function
function Get-ResStateName($arrResStates, $resStateNumber)
{
	Foreach ($resState in $arrResStates)
	{
		if ($resState.Number -eq $resStateNumber)
		{
			$resStateName = $resState.Name
		}
	}
	$resStateName
}

function fnMamlToHTML($MAMLText)
{
	$HTMLText = "";
	$HTMLText = $MAMLText -replace ('xmlns:maml="http://schemas.microsoft.com/maml/2004/10"');
	$HTMLText = $HTMLText -replace ("maml:para", "p");
	$HTMLText = $HTMLText -replace ("maml:");
	$HTMLText = $HTMLText -replace ("</section>");
	$HTMLText = $HTMLText -replace ("<section>");
	$HTMLText = $HTMLText -replace ("<section >");
	$HTMLText = $HTMLText -replace ("<title>", "<h3>");
	$HTMLText = $HTMLText -replace ("</title>", "</h3>");
	$HTMLText = $HTMLText -replace ("<listitem>", "<li>");
	$HTMLText = $HTMLText -replace ("</listitem>", "</li>");
	$HTMLText;
}

function fnTrimHTML($HTMLText)
{
	$TrimedText = "";
	$TrimedText = $HTMLText -replace ("&lt;", "<")
	$TrimedText = $TrimedText -replace ("&gt;", ">")
	$TrimedText = $TrimedText -replace ("<html>")
	$TrimedText = $TrimedText -replace ("<HTML>")
	$TrimedText = $TrimedText -replace ("</html>")
	$TrimedText = $TrimedText -replace ("</HTML>")
	$TrimedText = $TrimedText -replace ("<body>")
	$TrimedText = $TrimedText -replace ("<BODY>")
	$TrimedText = $TrimedText -replace ("</body>")
	$TrimedText = $TrimedText -replace ("</BODY>")
	$TrimedText = $TrimedText -replace ("<h1>", "<h3>")
	$TrimedText = $TrimedText -replace ("</h1>", "</h3>")
	$TrimedText = $TrimedText -replace ("<h2>", "<h3>")
	$TrimedText = $TrimedText -replace ("</h2>", "</h3>")
	$TrimedText = $TrimedText -replace ("<H1>", "<h3>")
	$TrimedText = $TrimedText -replace ("</H1>", "</h3>")
	$TrimedText = $TrimedText -replace ("<H2>", "<h3>")
	$TrimedText = $TrimedText -replace ("</H2>", "</h3>")
	$TrimedText;
}

#Endregion

$thisScript = $myInvocation.MyCommand.Path
$scriptRoot = Split-Path(Resolve-Path $thisScript)
$errorLogFile = Join-Path $scriptRoot "error.log"

#Load SDK
Load-SDK

#Get Configuration
$ConfigXML = Join-Path $scriptRoot "Config.xml"
$xml = [xml](get-content $configXML)

#Region Get XML Config
#SMTP server Address
$strSMTP = $xml.Configuration.SMTP.ServerName

#SMTP Port
$iPort = $xml.Configuration.SMTP.Port

#SMTP Use SSL
$bSSL = $xml.Configuration.SMTP.SSL

#SMTP Sender (return address)
$SenderName = $xml.Configuration.SMTP.SenderName
$SenderAddress = $xml.Configuration.SMTP.SenderAddress

#Resolution States
$arrResStates = $xml.Configuration.ResolutionStates.ResolutionState

#Notified Res State - Set to -1 in XML if you don't want to script to change the resolution state in the end.
$NotifiedResState = $xml.Configuration.NotifiedState
#Endregion

$Sender = New-Object System.Net.Mail.MailAddress($SenderAddress, $SenderName)

#If error occured while excuting the script, the recipient for error notification email.
$ErrRecipientName = $xml.Configuration.SMTP.ErrorRecipient.Name
$ErrRecipientAddress = $xml.Configuration.SMTP.ErrorRecipient.Address
$ErrRecipient = New-Object System.Net.Mail.MailAddress($ErrRecipientAddress, $ErrRecipientName)

if (Test-Path $errorLogFile) {Remove-Item $errorLogFile -Force}

######################

$alertID = $alertID.toString()

#remove "{" and "}" around the $alertID if exist
if ($alertID.substring(0,1) -match "{")
{
	$alertID = $alertID.substring(1, ( $alertID.length -1 ))
}
if ($alertID.substring(($alertID.length -1), 1) -match "}")
{
	$alertID = $alertID.substring(0, ( $alertID.length -1 ))
}

#Set Culture Info
$cultureInfo = [System.Globalization.CultureInfo]'en-US'

#Connect to RMS
$MGConnSetting = New-Object Microsoft.EnterpriseManagement.ManagementGroupConnectionSettings($Env:COMPUTERNAME)
$ManagementGroup = New-Object Microsoft.EnterpriseManagement.ManagementGroup($MGConnSetting)



##Get recipients names and email addresses from input array
$arrRecipients = @()
Foreach ($Recipient in $Recipients)
{
	$objRecipient = New-Object psobject
	$strRecipientName = ($Recipient.split(";"))[0]
	$strEmail = ($Recipient.split(";"))[1]
	Add-Member -InputObject $objRecipient -MemberType NoteProperty -Name Name -Value $strRecipientName
	Add-Member -InputObject $objRecipient -MemberType NoteProperty -Name Email -Value $strEmail
	$arrRecipients += $objRecipient
	Remove-Variable objRecipient
}

##locate the specific alert
$AlertSearchCriteria = "Id = `'$alertID`'"
$AlertCriteria = New-object Microsoft.EnterpriseManagement.Monitoring.MonitoringAlertCriteria($AlertSearchCriteria)
$alert = ($ManagementGroup.GetMonitoringAlerts($AlertCriteria))[0]

#get alert details
$alertName = $alert.Name
$strResolutionState = ($alert.resolutionstate).ToString()
if ($strResolutionState -eq "255")
{ exit }
$localtimeRaised = ($alert.timeraised).tolocaltime()
$severity = $alert.Severity.ToString()
$severitycolor="3300CC"	#Blue
if ($severity.ToLower() -eq "error")
	{
		$severity = "Critical"
		$severitycolor = "FF0000"	#Red
	} elseif ($severity.ToLower() -eq "warning")
	{
		$severitycolor = "FFFF00"	#Yellow
	} else
	{
		$severitycolor = "000000"	#Black
	}
	
$monitoringObjectId = $alert.monitoringobjectID.tostring()
$pathName = $alert.MonitoringObjectPath
$ruleID = $alert.MonitoringRuleId
$bIsMonitorAlert = $alert.IsMonitorAlert

#knowledge article / company knowledge
$KnowledgeArticles = $ManagementGroup.GetMonitoringKnowledgeArticles($ruleID)

$strTimeRaised = $localtimeraised.ToString()


##locate the alert associated rule / monitor

if (!$error)	#no point retrieving the monitoring rule when there's error processing the alert
{
	if ($bIsMonitorAlert -eq $false)
	{
		$rule = $ManagementGroup.GetMonitoringRule($ruleID)	
		$RuleName = $rule.DisplayName

	}
	elseif ($bIsMonitorAlert -eq $true)
	{
		$monitor = $ManagementGroup.GetMonitor($ruleID)
		$MonitorName = $monitor.DisplayName
	}
	
	#Convert Knowledge articles
	$arrArticles = @()
	Foreach ($article in $KnowledgeArticles)
	{
		If ($article.Visible)
		{
			$LanguageCode = $article.LanguageCode
			#Retrieve and format article content
			$MamlText = $null
			$HtmlText = $null
				
			if ($article.MamlContent -ne $null)
			{
				$MamlText = $article.MamlContent
				$articleContent = fnMamlToHtml($MamlText)
			}
				
			if ($article.HtmlContent -ne $null)
			{
				$HtmlText = $article.HtmlContent
				$articleContent = fnTrimHTML($HtmlText)
			}
			$objArticle = New-Object psobject
			Add-Member -InputObject $objArticle -MemberType NoteProperty -Name Content -Value $articleContent
			Add-Member -InputObject $objArticle -MemberType NoteProperty -Name Language -Value $LanguageCode
			$arrArticles += $objArticle
			Remove-Variable LanguageCode, articleContent
		}
	}
		
}
if ($KnowledgeArticles -eq $null)
{
	$articleContent = "No resolutions were found for this alert."
}

$AlertSource = $alert.MonitoringObjectDisplayName
$alertPrincipalName=$alert.principalName
$strAlertName = $alert.Name
$strSubject = "SCOM $severity Alert on $strAgentName : $strAlertName"
$strErrSubject = "Error emailing SCOM Notification for Alert ID $alertID"

$strDesc = $alert.Description
$strResStateName = Get-ResStateName $arrResStates $strResolutionState

#populate email body
$strBody = @"
<html>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<body>
  <table>
		<tr>
			<td style="padding-bottom:5px;width:50%;">
				<b><div style="margin-top:2px;">$alertName</div></b>
			</td>
			<hr>
			<td style="padding:5px;"></td>
			<td style="padding-bottom:5px;">
				<b><div style="margin-top:2px;">Alert Description</div></b>
			</td>
			<hr>
		</tr>		
		<tr>
		   <td>
				<table>
					<tr>
						<td>Severity:</td>
						<td/>
						<td><Font color='$SeverityColor'> $severity</Font></td>
					</tr>
					<tr>
						<td>Source:</td>
						<td/>
						<td>$AlertSource</td>
					</tr>
					<tr>
						<td>Path:</td>
						<td/>
						<td>$pathName</td>
					</tr>
					<tr>
						<td>Principal Name:</td>
						<td/>
						<td>$alertPrincipalName</td>
					</tr>
"@

if ($bIsMonitorAlert -eq $true) {
$strBody = $strBody + @"
					<tr>
						<td>Alert Monitor:</td>
						<td/>
						<td>$MonitorName</td>
					</tr>
"@
}elseif ($bIsMonitorAlert -eq $false) {
$strBody = $strBody + @"
					<tr>
						<td>Alert Rule:</td>
						<td/>
						<td>$RuleName</td>
					</tr>
"@
}

$strBody = $strBody + @"
					<tr>
						<td>Created:</td>
						<td/>
						<td>$strTimeRaised</td>
					</tr>
					<tr>
						<td>Resolution State:</td>
						<td/>
						<td>$strResStateName</td>
					</tr>
				</table>
		   </td> 
		   <td/>
		   <td>$StrDesc</td>

		</tr>
		
		<tr>
			<td style="padding-bottom:5px;padding-top:20px;"><b>Knowledge</b></td>

			<td />
			<td style="padding-bottom:5px;padding-top:20px;">				
			</td>
		</tr>
	</table>
	<hr>
"@


Foreach ($objArticle in $arrArticles)
{
 $articleContent = $objArticle.Content
$strBody = $strBody + @"
<b><p> Knowledge Article / Company Knowledge `-$($objArticle.Language)</b>
<p> $articleContent
<hr>
"@
}
$strBody = $strBody + @"
<p>Alert ID:</b> $alertID
<p>Web Console Link:<a href = $WebConsoleLink>$WebConsoleLink</a>
<p>
</body></html>
"@

$strErrBody = @"
<html><body>
<p>Error occurred when excuting $thisScript located at $RMS for alert ID $alertID.
<p>
<p>Alert Resolution State: $strResStateName
<p>**Note:Error will occur if the script tries to process an alert with Resolution State other than <b>New</b>.
<p>
<p>$error
<p>
<p><b>**Use below command to view the full details of this alert in SCOM Powershell console:</b>
<p>$psCmd
<p>
<p> Web Console Link: <a href = $WebConsoleLink>$WebConsoleLink</a>
</body></html> 
"@

$MailMessage = New-Object System.Net.Mail.MailMessage
$MailMessage.IsBodyHtml = $true
$SMTPClient = New-Object System.Net.Mail.smtpClient
$SMTPClient.host =  $strSMTP
$SMTPClient.port = $iPort
if ($bSSL -ieq "true")
{
	$SMTPClient.EnableSSL = $true
} elseif ($bSSL -ieq "false") {
	$SMTPClient.EnableSSL = $false
}

#Get authentication method
$AuthenticationMethod = ($xml.Configuration.SMTP.AuthenticationMethod.value).ToLower()
Switch ($AuthenticationMethod)
{
	"anonymous" {$SMTPClient.UseDefaultCredentials = $false}
	"integrated" {$SMTPClient.UseDefaultCredentials = $true}
	"credential" {
		$SMTPClient.UseDefaultCredentials = $true
		$SMTPUsername = $xml.Configuration.SMTP.Credential.Username
		$SMTPPassword = $xml.Configuration.SMTP.Credential.Password
		$SMTPClient.Credentials = New-Object System.Net.NetworkCredential($SMTPUsername, $SMTPPassword)
	}
}


$MailMessage.Sender = $Sender
$MailMessage.From = $Sender
if ($error.count -eq "0")
{
	$MailMessage.Subject = $strSubject
	Foreach ($item in $arrRecipients)
	{
		$to = New-Object System.Net.Mail.MailAddress($item.email, $item.name)
		$MailMessage.To.add($to)
		Remove-Variable to
	}
	$MailMessage.Body = $strBody
}
else
{
	$MailMessage.Subject = $strErrSubject
	$MailMessage.To.add($ErrRecipient)
	$MailMessage.Body = $strErrBody
}
$SMTPClient.Send($MailMessage)

Write-Host $error
##Make sure the script is closed
if ($error.count -eq "0")
{
	if ($alert.ResolutionState -eq "0" -and $NotifiedResState -ne "-1")
	{ 
		$alert.ResolutionState = $NotifiedResState
		$alert.Update("")
	}
}
else
{
	$Error | Out-File $errorLogFile
}