$HelloKitty = new-object -com SAPI.SpVoice
$Greetings = "Hi George, I am Hello Kitty. Craig sent me to show you how to write Hello World in PowerShell."
$message = @"
        .-. __ _ .-.
        |  `  / \  |
        /     '.()--\
       |         '._/
      _| O   _   O |_
      =\    '-'    /=
        '-._____.-'
        /`/\___/\`\
       /\/o     o\/\
      (_|         |_)
        |____,____|
        (____|____)
		
	Hello World
"@
Write-Host $message -foregroundcolor magenta
$HelloKitty.speak($Greetings) | out-null