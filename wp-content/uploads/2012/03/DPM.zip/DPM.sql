DECLARE @DPMServer varchar(40), @Jobname varchar(max), @ownerloginname varchar(40), @query nvarchar(max),
		@stepname varchar(max), @schedulename varchar(max), @starttime int, @name varchar(36)
select @DPMServer = netbiosname from DPMDB.dbo.tbl_am_server where ServerId = DPMServerId
set @Jobname	    = 'Cancel DPM Auto Discovery'
set @ownerloginname =  'sa'
set @stepname       = 'Inactivate DPM Auto Discovery Job'
set @schedulename   = 'Job to cancel Auto Discovery'
set @DPMServer = @DPMServer + '\MSDPM2010' 
set @query = 'use msdb
select @jobname = name from msdb.dbo.sysjobs 
where name = convert(varchar(36),
   (select ScheduleId  from dpmdb.dbo.tbl_SCH_ScheduleDefinition 
	where JobDefinitionId in 
	   (select JobDefinitionId from dpmdb.dbo.tbl_JM_JobDefinition 
        where Type = ''8BC21871-BE3D-469D-AB26-C6C758C15621'')
and isdeleted = 0))'
exec sp_executesql @statement = @query, @parameters = N'@jobname varchar(36) output', @Jobname = @name output
set @query = 'Declare @jobname varchar(36) ' + @query  + ' EXEC sp_update_job @job_name = @jobname, @enabled = 0'
USE msdb
EXEC dbo.sp_add_job @job_name = @Jobname, @enabled = 1, @description = 'Job to cancel DPM Auto Discovery',
                     @category_name = N'[Uncategorized (Local)]', @owner_login_name = @ownerloginname;
EXEC sp_add_jobstep @job_name = @Jobname, @step_name = @stepname, @subsystem = N'TSQL', @command = @query;
select @starttime = active_start_time from msdb.dbo.sysschedules sche
join msdb.dbo.sysjobschedules jobsche
on sche.schedule_id = jobsche.schedule_id
join msdb.dbo.sysjobs jobs
on jobsche.job_id = jobs.job_id
where jobs.name = @name
set @starttime = @starttime - 4500
EXEC sp_add_schedule @schedule_name = @schedulename, @freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20120229, 
		@active_end_date=99991231, 
		@active_start_time=5500, 
		@active_end_time=235959;
EXEC sp_attach_schedule @job_name = @Jobname, @schedule_name = @schedulename ;
EXEC sp_add_jobserver @job_name = @Jobname, @Server_name = @DPMServer
GO
