Add the content of OpsMgrServer_AddtoConfigurationMof.txt to the end of Configuration.mof
Add the content of OpsMgrServer_AddtoSmsDefMof.txt to the end of sms_def.mof

http://blog.tyang.org/2011/10/12/extend-configmgr-hardware-inventory-to-capture-opsmgr-configurations/