﻿#requires -version 2
#======================================================================================================================================================
# AUTHOR:	Tao Yang 
# DATE:		10/05/2011
# Name:		SCCM-HealthCheck.PS1
# Version:	3.3
# COMMENT:	-	Basic Health Check for SCCM infrastructure. It checks the following:
#					*	Ping check all servers in the SCCM infrastructure
#							-	If first ping failes, wait for number of seconds (defined in XML file)
#								then attemp to ping few more times (Number of retries defined in XML file).
#							-	if returns any successful pings, ping test is classfied as success.
#					*	DNS name resolution check for all servers in SCCM infrasturecture
#							-	forward lookup check
#							-	reverse lookup check
#							-	compare DNS A record with the FQDN that's set on the server
#							-	Check if Host records exist in multiple domains
#							-	Check if multiple IP addresses registered in DNS.
#					*	All site systems in warning or critical state
#					*	All site components in warning or critical state
#					*	All package distribution with issues
#					*	Checks all Non-PXE boot image packages in PXE DP share
#					*	any inboxes that contain number of files that's over the threshold (threshold is set in the XML file)
#					*	Chceks availability of Inbox folders on all primary site servers
#					*	Checks SCCM site backups on all primary sites within the "DaysToCheck" that's set in XML file.
#					*	Checks any errors in SQL server and SQL agent logs
#					*	Checks Applicaiton logs on SQL servers for any SQL related errors
#			-	Security requirement:
#					*	The powershell execution policy on the computer that's running the script needs to be set to at RemoteSigned or Unrestricted.
#					*	The account used to run this script needs to have:
#							-	local admin rights on Central site server, Central site provider server (if not the site server itself)
#							-	at least access to the master DB on all SQL servers to be able to read SQL server and agent logs.
#							-	SMS admin access on all primary sites
#							-	NTFS read permission to "inboxes" folders on all primary site servers.
#			-	The script has the option to email out the health check report (can be switched on and off in XML file)
#					*	The email body is in HTML format that contains the overall status of each check
#					*	The detailed report is in TXT format and it is attached to the email. it is also located in the same folder as the script
#						with the timestamp. if emailing is turned off, the detailed report can be located there.
#			-	The script can either use System.Net.Mail or legacy CDO Message object to send emails. This can be set in the XML file (<EmailMethod> section)
#			-	Ultilizing diruse.exe from Windows 2000 Resource Kit to check SCCM inboxes.
#			-	Settings are set in the "Health-Check.xml" file located under the same folder of the script.
#			-	PowerShell Remoting can be used to check inboxes backlogs. This can be enabled on the xml config file.
#			-	Diruse.exe (http://support.microsoft.com/kb/927229) is used instead of Get-ChildItem to read SCCM inboxes size. When Powershell Remoting is not
#				ultilized, Diruse.exe is used to check SCCM inboxes backlogs.
#				because it runs faster against remote servers.
#			-	option to utilise Powershell Remoting (if it's enabled on site servers) to improve the performance or fall back to the lagacy method of diruse.exe
#			-	Get-WinEvent is used to read event log rather using Get-EventLog because Get-EventLog does not support server side filtering.
#				Therefore Get-WinEvent is used to improve performance when reading remote event logs. However, Get-WinEvent only works on
#				Vista and later version of Windows.
#				In this script, Get-WinEvent is only used to read SQL server application logs. Hence all SQL servers should be running on Windows 2008 at least.
#			-	Scheduling the script in Windows Task Scheduler:
#					*	"Allow log on as batch job" rights is required for the user account to run scheduled jobs
#					*	if scheduling in Windows 2008 or later, please make sure "Run with highest privleges" is ticked to bypass UAC
#			-	Update History
#					3.3	-	Fixed the bug where when using DOTNET sending emails to multiple recipients, it only sends to the first recipient from the list
#						-	It now zip the txt attachment to zip file before sending it. this is to improve the performance and avoid sending large attachments.
#
#					3.2	-	Added functionality to check all current active package distribution
#						-	Able to create exemptions for DNS suffix check. This can be configured in the XML.
#						-	Improved DNS checks
#						-	Fixed the bug when SQL DB is not running under default instance. The script now reads SQL DB location from primary site server's registry.
# Usage:	This script can be scheduled to run via Windows Task Scheduler.
#			The action account requires SCCM administrator rights and local admin rights on all site systems.
#======================================================================================================================================================
$ErrorActionPreference = "SilentlyContinue"
#Load .NET DLL if not loaded
If (!([appdomain]::currentdomain.getassemblies() | Where-Object {$_.FullName -ieq "system.core"}))
{
	Try {
		Write-Host "Loading .NET DLL into Powershell..." -ForegroundColor Green
		[Void][System.Reflection.Assembly]::LoadWithPartialName("System.Core")
	} Catch {
		#We cannot use Write-Error cmdlet here because $ErrorActionPreference is set to "SilentlyContinue" so it won't display on the screen.
		Write-Host "Unable to load .NET Framework into Powershell, please make sure it is installed!" -ForegroundColor
		Exit
		}
}
##First of all, make sure there are enough real estate on the powershell console
$BufferWidth = 700
$BufferHeight = 800
$bUpdateSize = $false
$RawUI = (Get-Host).UI.RawUI
$BufferSize = $RawUI.BufferSize
if ($BufferSize.Width -lt $BufferWidth) {$BufferSize.Width = $BufferWidth; $bUpdateSize = $true}
if ($BufferSize.Height -lt $BufferHeight) {$BufferSize.Height = $BufferHeight; $bUpdateSize = $true}
if ($bUpdateSize -eq $true) {$RawUI.BufferSize = $BufferSize}
Remove-Variable bUpdateSize

$Global:arrFailedBackupSite = @()
$Global:arrSQLServersWithErrors = @()
$Global:arrSQLAgentsWithErrors = @()

#Get current date time
$Date = Get-Date
$strDate = "$($Date.day)-$($Date.month)-$($Date.Year)"

$Global:strEmailBody = @"
<html>
<head>
<style>
TABLE{border-width: 2px;text-align: center;border-style: solid;border-color: black;border-collapse: collapse;}
TH{border-width: 1px;padding: 4px;border-style: solid;border-color: black;background-color:#CCCC99}
TD{border-width: 1px;padding: 4px;border-style: solid;border-color: black;}
</style>
</head>
<body>
<h1>Overall Health for $strDate :</h1>
<hr>

"@

##Function libraries

function Validate-DNSRecord ($strComputer, $DNSSuffix, $arrExemptionDevices)
{
	[int]$iValidFQDN = 1	#False = 1, True = 0
	[int]$iValidDNSRecords = 2	#False = 2, True = 0
	[int]$iHostRecordsInOtherDomains = 0	#False = 0, True = 3
	[int]$iMultipleHostRecords = 0			#False = 0, True = 4
	[int]$iValidNameFromWMI = 5				#False = 5, True = 0
	#Get FQDN from WMI on remote computer
	Try
	{
		$objCompSys = Get-WmiObject -Query "SELECT DNSHostName, Domain FROM Win32_ComputerSystem" -ComputerName $strComputer
		if ($objCompSys -ne $null)
		{
			$NetBiosName = $objCompSys.DNSHostName
			$ComputerDomain = $objCompSys.Domain
			$strFQDN = $NetBiosName+"."+$ComputerDomain
		} else {
			$NetBiosName = $null
			$strFQDN = "Unable to retrieve FQDN from WMI"	
		}
	} catch {
		$NetBiosName = $null
		$strFQDN = "Unable to retrieve FQDN from WMI"
	}
	
	#process exemption list
	$ExemptedDevice = $null
	$PTRRecordExemption = $null
	$arrDNSSuffixExemption = New-Object system.Collections.ArrayList
	Foreach ($item in $arrExemptionDevices)
	{
		if ($item.name -ieq $NetBiosName -or $item.name -ieq $strFQDN)
		{
			$ExemptedDevice = $item
			foreach ($SuffixExemption in $ExemptedDevice.DNSSuffix)
			{
				if ($SuffixExemption.length -gt 0)
				{
					[Void]$arrDNSSuffixExemption.Add($SuffixExemption.ToUpper())
				}
			}
		}
	}
	
	

	$objDNSCheckResult = New-Object psobject
	Add-Member -InputObject $objDNSCheckResult -membertype noteproperty -name "Server Name" -value $strComputer
	Add-Member -InputObject $objDNSCheckResult -membertype noteproperty -name "Server Name matches FQDN from Computer WMI" -value $false
	Add-Member -InputObject $objDNSCheckResult -membertype noteproperty -name "FQDN from Computer WMI" -value $strFQDN
	Add-Member -InputObject $objDNSCheckResult -membertype noteproperty -name "FQDN from SCCM matches DNS A Record" -value $false
	Add-Member -InputObject $objDNSCheckResult -membertype noteproperty -name "IP Address From Forward Lookup" -value $null
	Add-Member -InputObject $objDNSCheckResult -membertype noteproperty -name "Multiple Host Records" -value $false
	Add-Member -InputObject $objDNSCheckResult -membertype noteproperty -name "A Records Exist in Other Domains" -value $false
	Add-Member -InputObject $objDNSCheckResult -membertype noteproperty -name "DNS A Records from ALL Domains" -value $null
	Add-Member -InputObject $objDNSCheckResult -membertype noteproperty -name "Host Name From Forward Lookup" -value $null
	Add-Member -InputObject $objDNSCheckResult -membertype noteproperty -name "PTR Record matches FQDN from SCCM" -value $false
	Add-Member -InputObject $objDNSCheckResult -membertype noteproperty -name "Host Name From Reverse Lookup" -value $null
	
	If ($strComputer -ieq $strFQDN)
	{
		$iValidNameFromWMI = 0
		$objDNSCheckResult."Server Name matches FQDN from Computer WMI" = $true
	}
	#Forward Lookup Check
	$arrHostRecords = New-Object system.Collections.ArrayList
	Try
	{
		$HostRecord = [JHSoftware.DNSClient]::Lookup("$strComputer","A")
		Foreach ($AnswerRecord in $HostRecord.AnswerRecords)
		{
			$strHost = $AnswerRecord.name.ToUpper()
			if (!($arrHostRecords.Contains($AnswerRecord.name.ToUpper())))
			{
				[Void]$arrHostRecords.Add($AnswerRecord.name.ToUpper())
			}
			$strHostRecord = $null
			Foreach ($record in $arrHostRecords)
			{
				if ($strHostRecord -eq $null)
				{
					$strHostRecord = $record
				} else {
					$strHostRecord = $strHostRecord + ";" +$record
				}
			}
		}
	} Catch {
		[Void]$arrHostRecords.Add("Host Record not found for $strComputer")
	}
	#validate FQDN
		$objDNSCheckResult."Host Name From Forward Lookup" = $strHostRecord
	
	if ($arrHostRecords.Contains($strComputer.ToUpper()))
	{
		$iValidFQDN = 0
		$objDNSCheckResult."FQDN from SCCM matches DNS A Record" = $true
	}
	
	$arrIPs = New-Object system.Collections.ArrayList
	Try
	{
		$ReverseRecords = [JHSoftware.DNSClient]::LookupHost($strComputer)
		Foreach ($record in $ReverseRecords)
		{
			[Void]$arrIPs.Add($record.IPAddressToString)
		}
		if ($arrIPs.count -ge 2)
		{
			$objDNSCheckResult."Multiple Host Records" = $true
			$iMultipleHostRecords = 4
		}
	} Catch {
		[Void]$arrIPs.Add("No Forward Lookup Record Found for $strComputer")
	}
	$strIP = $null
	Foreach ($ip in $arrIPs)
	{
		if ($strIP -eq $null)
		{
			$strIP = $ip
		} else {
			$strIP = $strIP + ";" + $ip
		}
	}
	$objDNSCheckResult."IP Address From Forward Lookup" = $strIP
	
	#Check A records against all domains
	if ($DNSSuffix -ne $null)
	{
		$strAllHostRecords = $null
		Foreach ($suffix in $DNSSuffix)
		{
			if ($suffix.length -gt 0)
			{
				$StrFQDNToCheck = $strComputer.split(".")[0]+"."+$suffix
				$arrFQDNCheck = [System.Net.Dns]::GetHostEntry("$StrFQDNToCheck")
				if ($arrFQDNCheck -ne $null)
				{
					Foreach ($item in $arrFQDNCheck)
					{
						If ($suffix -ine $ComputerDomain -and (!($arrDNSSuffixExemption.Contains($suffix.ToUpper()))))
						{
							$objDNSCheckResult."A Records Exist in Other Domains" = $true
							$iHostRecordsInOtherDomains = 3
						}
						if ($arrDNSSuffixExemption.contains($suffix.ToUpper()))
						{
							$strHostName = $item.hostname + " `(Exemption`)"
						} else {
							$strHostName = $item.hostname
						}
						If ($item.hostname -ne $null)
						{
							if ($strAllHostRecords -eq $null)
							{
								$strAllHostRecords = $strHostName
							} else {
								$strAllHostRecords = $strAllHostRecords + "; " + $strHostName
							}
						}
					}
					Remove-Variable arrFQDNCheck, strHostName
				}
			}
		}
		$objDNSCheckResult."DNS A Records from ALL Domains" = $strAllHostRecords
	}
	
	#validate PTR records against Host records
	$arrPTRRecords = New-Object system.Collections.ArrayList
	Foreach ($ip in $arrIPs)
	{
		Try {
			Foreach ($item in ([JHSoftware.DNSClient]::LookupReverse("$ip")))
			{
				if (!($arrPTRRecords.Contains($item.ToUpper())))
				{
					[Void]$arrPTRRecords.add($item.ToUpper())
				}
			}
		} Catch {
				[Void]$arrPTRRecords.add("PTR Record not found for $ip")
		}
	}
	
	$strPTRRecord = $null
	Foreach ($PTRRecord in $arrPTRRecords)
	{
		if ($strPTRRecord -eq $null)
		{
			$strPTRRecord = $PTRRecord
		} else {
			$strPTRRecord = $strPTRRecord + ";" + $PTRRecord
		}
	}
	$objDNSCheckResult."Host Name From Reverse Lookup" = $strPTRRecord
	
	if ($arrPTRRecords.Contains($strComputer.ToUpper()) -or $PTRRecordExemption -eq $true)
	{
		$iValidDNSRecords = 0
		$objDNSCheckResult."PTR Record matches FQDN from SCCM" = $true
	}
	Remove-Variable arrPTRRecords, strPTRRecord, arrIPs
	
	$iValid = $iValidDNSRecords + $iValidFQDN + $iHostRecordsInOtherDomains + $iMultipleHostRecords + $iValidNameFromWMI
	# $Valid = 0 -->All good
	Add-Member -InputObject $objDNSCheckResult -membertype noteproperty -name "Overall Check Result" -value $iValid
	return $objDNSCheckResult
}

Function Get-RemoteDateTime ($strComputerName)
{
	#Get current date time on remote server
	$objLocalDateTime = Get-WmiObject Win32_LocalTime -ComputerName $strComputerName
	$objDateTime = Get-Date -Year $objLocalDateTime.Year -Month $objLocalDateTime.Month -Day $objLocalDateTime.Day -Hour $objLocalDateTime.Hour -Minute $objLocalDateTime.Minute -Second $objLocalDateTime.Second
	Return $objDateTime
}

Function ConvertTo-RemoteDateTime ($LocalDateTime, $strRemoteComputer)
{
	#Retrieve remote timezone info from WMI
	$objRemoteWMITimeZoneInfo = Get-WmiObject win32_timezone -ComputerName $strRemoteComputer
	#Convert to System.TimeZoneInfo object
	$ObjTz = [System.TimeZoneInfo]::FindSystemTimeZoneById("$($objRemoteWMITimeZoneInfo.StandardName)")
	#Convert to remote time
	$RemoteDateTime = [System.TimeZoneInfo]::ConvertTime($LocalDateTime, $ObjTz)
	Return $RemoteDateTime
}

Function Convert-From-UTC-To-RemoteDateTime ($LocalDateTime, $strRemoteComputer)
{
	#Retrieve remote timezone info from WMI
	$objRemoteWMITimeZoneInfo = Get-WmiObject win32_timezone -ComputerName $strRemoteComputer
	#Convert to System.TimeZoneInfo object
	$ObjTz = [System.TimeZoneInfo]::FindSystemTimeZoneById("$($objRemoteWMITimeZoneInfo.StandardName)")
	#Convert to remote time
	$RemoteDateTime = [System.TimeZoneInfo]::ConvertTimeFromUtc($LocalDateTime, $ObjTz)
	Return $RemoteDateTime
}

#Note:	this function (check-SCCMBackups) is no longer used as I have changed to code to retrieve same information from central site sms provider because the NT event log can be overwriteen
#		and make not contain older information therefore giving false result.
#Function Check-SCCMBackups ($arrPrimarySites, $BackupDaysToCheck)
#{
#	$arrSuccessfulBackup = @()
#	Foreach ($site in $arrPrimarySites)
#	{
#		$StartDate = (Get-Date).AddDays(-$BackupDaysToCheck)
#		Write-Host "    Checking SCCM backups for $($site.sitecode) on $($site.ServerName)" -ForegroundColor Green
#		$arrBackupFinishEvent = get-winevent -FilterHashtable @{logname="application";starttime=$startDate; ID=5057; providername="SMS Server"} -ComputerName $($site.ServerName)
#
#		if ($arrBackupFinishEvent -ne $null)
#		{
#			Foreach ($BackupFinishEvent in $arrBackupFinishEvent)
#			{	
#				$BackupFinishTime = ConvertTo-RemoteDateTime $BackupFinishEvent.TimeCreated $site.ServerName
#				$objBackupEvent = New-Object psobject
#				Add-Member -InputObject $objBackupEvent -membertype noteproperty -name ServerName -value $site.ServerName
#				Add-Member -InputObject $objBackupEvent -membertype noteproperty -name SiteCode -value $site.SiteCode
#				Add-Member -InputObject $objBackupEvent -membertype noteproperty -name BackupFinishTime -value $BackupFinishTime
#				$arrSuccessfulBackup += $objBackupEvent
#				Remove-Variable BackupFinishTime
#			}
#		} else {
#			$objFailedBackupSite = New-Object psobject
#			Add-Member -InputObject $objFailedBackupSite -membertype noteproperty -name ServerName -value $site.ServerName
#			Add-Member -InputObject $objFailedBackupSite -membertype noteproperty -name SiteCode -value $site.SiteCode
#			$Global:arrFailedBackupSite += $objFailedBackupSite
#		}
#	}
#	Return ,$arrSuccessfulBackup
#}


Function Check-SCCMBackups ($CentralSiteCode, $CentralSiteProvider, $arrPrimarySites, $BackupDaysToCheck)
{
	$arrSuccessfulBackup = @()
	Foreach ($site in $arrPrimarySites)
	{
		$StartDate = [System.Management.ManagementDateTimeconverter]::ToDmtfDateTime($(((Get-Date).AddDays(-$BackupDaysToCheck)).ToUniversalTime()))
		$strSiteServer = $site.ServerName
		Write-Host "    Checking SCCM backups for $($site.sitecode) on $($site.ServerName)" -ForegroundColor Green
		$arrBackupFinishEvent = Get-WmiObject -Namespace root\SMS\Site_$CentralSiteCode -Query "SELECT * FROM SMS_StatusMessage WHERE Component='SMS_SITE_BACKUP' AND MachineName='$strSiteServer' AND MessageID=5035 AND Time>='$StartDate'" -ComputerName $CentralSiteProvider

		if ($arrBackupFinishEvent -ne $null)
		{
			Foreach ($BackupFinishEvent in $arrBackupFinishEvent)
			{	
				$BackupFinishTime = Convert-From-UTC-To-RemoteDateTime ([System.Management.ManagementDateTimeconverter]::ToDateTime($BackupFinishEvent.Time)) $site.ServerName
				$objBackupEvent = New-Object psobject
				Add-Member -InputObject $objBackupEvent -membertype noteproperty -name ServerName -value $site.ServerName
				Add-Member -InputObject $objBackupEvent -membertype noteproperty -name SiteCode -value $site.SiteCode
				Add-Member -InputObject $objBackupEvent -membertype noteproperty -name BackupFinishTime -value $BackupFinishTime
				$arrSuccessfulBackup += $objBackupEvent
				Remove-Variable BackupFinishTime
			}
		} else {
			$objFailedBackupSite = New-Object psobject
			Add-Member -InputObject $objFailedBackupSite -membertype noteproperty -name ServerName -value $site.ServerName
			Add-Member -InputObject $objFailedBackupSite -membertype noteproperty -name SiteCode -value $site.SiteCode
			$Global:arrFailedBackupSite += $objFailedBackupSite
		}
	}
	Return ,$arrSuccessfulBackup
}


Function Get-TallyInterval ($objDate, $Deviant)
{
	$StartDate = $objDate.AddDays(-$Deviant)
	if ($Deviant -gt 6)
	{
		$strDayOfWeek = ""
	} else {
		$strDayOfWeek = $StartDate.DayOfWeek
	}
	
	Switch ($strDayOfWeek)
	{
		Sunday {$TallyInterval = "0001128000192000"}
		Monday {$TallyInterval = "00011280001A2000"}
		Tuesday {$TallyInterval = "00011280001B2000"}
		Wednesday {$TallyInterval = "00011280001C2000"}
		Thursday {$TallyInterval = "00011280001D2000"}
		Friday {$TallyInterval = "00011280001E2000"}
		Saturday {$TallyInterval = "00011280001F2000"}
		default { $TallyInterval = "0001128000080008"} #Since site installation
	}
	Return $TallyInterval
}

function Convert-NALPath ($strNALPath)
{
	$arrSubstring = @()
	$arrSubstring += $strNALPath -split "]"
	$strPath = $arrSubString[$arrSubstring.count-1]
	$strPath = $strPath.trim("\")
	Return $strPath
}

function Get-PackageName ($CentralSiteCode, $CentralSiteProvider, $strPackageID)
{
	$strPackageName = (Get-WmiObject -Namespace root\sms\site_$CentralSiteCode SMS_PackageBaseClass -Filter "PackageID='$strPackageID'" -ComputerName $CentralSiteProvider).Name
	if ($strPackageName -eq $null) {$strPackageName = "~Unknown~"}
	Return $strPackageName
}

function Get-PackageStatus ($iStatusCode)
{
	Switch ($iStatusCode)
	{
		0 {$StrPkgStatus = "NONE"}
		1 {$StrPkgStatus = "SENT"}
		2 {$StrPkgStatus = "RECEIVED"}
		3 {$StrPkgStatus = "INSTALLED"}
		4 {$StrPkgStatus = "RETRY"}
		5 {$StrPkgStatus = "FAILED"}
		6 {$StrPkgStatus = "REMOVED"}
		7 {$StrPkgStatus = "PENDING_REMOVE"}
		default {$StrPkgStatus = "Unknown"}
	}
	Return $StrPkgStatus
}

function Get-PackageInstallationStatus ($iStatusCode)
{
	Switch ($iStatusCode)
	{
		0 {$StrPkgInstStatus = "INSTALLED"}
		1 {$StrPkgInstStatus = "INSTALL_PENDING"}
		2 {$StrPkgInstStatus = "INSTALL_RETRYING"}
		3 {$StrPkgInstStatus = "INSTALL_FAILED"}
		4 {$StrPkgInstStatus = "REMOVAL_PENDING"}
		5 {$StrPkgInstStatus = "REMOVAL_RETRYING"}
		6 {$StrPkgInstStatus = "REMOVAL_FAILED"}
		default {$StrPkgInstStatus = "Unknown"}
	}
	Return $StrPkgInstStatus
}

function Get-DPStatus ($iStatusCode)
{
		Switch ($iStatusCode)
	{
		0 {$StrDPStatus = "NONE"}
		1 {$StrDPStatus = "UPDATED"}
		2 {$StrDPStatus = "ADDED"}
		3 {$StrDPStatus = "DELETED"}
		default {$StrDPStatus = "Unknown"}
	}
	Return $StrDPStatus
}

function Get-PackageType ($CentralSiteCode, $CentralSiteProvider, $strPackageID)
{
	$objPkgBase = Get-WmiObject -Namespace root\sms\site_$CentralSiteCode SMS_PackageBaseClass -Filter "PackageID = '$strPackageID'" -ComputerName $CentralSiteProvider
	Switch ($objPkgBase.PackageType)
	{
		0 {$strPkgType="Regular software distribution package"}
		3 {$strPkgType="Driver package"}
		4 {$strPkgType="Task sequence package"}
		5 {$strPkgType="Software update package"}
		6 {$strPkgType="Device setting package"}
		257 {$strPkgType="Image package"}
		258 {$strPkgType="Boot image package"}
		259 {$strPkgType="Operating system install package"}
		default {$strPkgType="Unknown"}
	}
	Return $strPkgType
}

function Get-PackagesWithIssues ($CentralSiteCode, $CentralSiteProvider, $arrSkippedSites)
{
	$arrPackagesWithIssues = @()
	$arrAllPackagesWithIssues = Get-WmiObject -Namespace root\sms\site_$CentralSiteCode -query "SELECT * FROM SMS_PackageStatus WHERE status>3" -ComputerName $CentralSiteProvider
	if ($arrAllPackagesWithIssues -ne $null)
	{
		foreach ($package in $arrAllPackagesWithIssues)
		{
				$SiteCode = $package.SiteCode.ToUpper()
				if (!($arrSkippedSites.contains($SiteCode)))
				{
					$objPkgStatus = New-Object psobject
					Add-Member -InputObject $objPkgStatus -membertype noteproperty -name PackageID -value $package.PackageID
					Add-Member -InputObject $objPkgStatus -membertype noteproperty -name PackageName -value $(Get-PackageName $CentralSiteCode $CentralSiteProvider $($package.PackageID))
					Add-Member -InputObject $objPkgStatus -membertype noteproperty -name PackageLocation -value $($package.Location.substring(23,$package.location.length-23))
					Add-Member -InputObject $objPkgStatus -membertype noteproperty -name PackageServer -value (Convert-NALPath $package.PkgServer)
					Add-Member -InputObject $objPkgStatus -membertype noteproperty -name SiteCode -value $package.SiteCode
					Add-Member -InputObject $objPkgStatus -MemberType NoteProperty -Name Status -Value $(Get-PackageStatus $package.Status)
					$arrPackagesWithIssues += $objPkgStatus
				}
		}
	}
	
	Remove-Variable arrAllPackagesWithIssues
	Return ,$arrPackagesWithIssues
}

function Get-ActivePackageDistributions ($CentralSiteCode, $CentralSiteProvider, $arrSkippedSites)
{
	$arrActivePkgDistSummarizer = Get-WmiObject -Namespace root\sms\site_$CentralSiteCode -query "SELECT * FROM SMS_PackageStatusDistPointsSummarizer WHERE state<>0" -ComputerName $CentralSiteProvider
	$ArrActivePkgDist = @()
	Foreach ($PkgDist in $arrActivePkgDistSummarizer)
	{
		$PkgID = $PkgDist.PackageID
		$ServerNALPath = $PkgDist.ServerNALPath
		$FixedServerNALPath = $ServerNALPath.replace("\", "\\")
		$ObjPkg = Get-WmiObject -Namespace root\sms\site_$CentralSiteCode -Query "SELECT * FROM SMS_PackageBaseClass WHERE PackageID='$PkgID'" -ComputerName $CentralSiteProvider
		$ObjDP = Get-WmiObject -Namespace root\sms\site_$CentralSiteCode -Query "SELECT * FROM SMS_DistributionPoint WHERE PackageID='$PkgID' AND ServerNALPath = '$FixedServerNALPath'" -ComputerName $CentralSiteProvider
		#Get package type
		Switch ($ObjPkg.PackageType)
		{
			0 {$strPkgType="Regular software distribution package"}
			3 {$strPkgType="Driver package"}
			4 {$strPkgType="Task sequence package"}
			5 {$strPkgType="Software update package"}
			6 {$strPkgType="Device setting package"}
			257 {$strPkgType="Image package"}
			258 {$strPkgType="Boot image package"}
			259 {$strPkgType="Operating system install package"}
			default {$strPkgType="Unknown"}
		}
		#determine if it's Branch DP
		if ($ObjDP.IsPeerDP -eq $true)
		{
			$strBranchDP = "Yes"
		} else {
			$strBranchDP = "No"
		}
		#Get DP, site code and convert Last Refresh Time
		if ($ObjDP -eq $null)
		{
			$strDP = Convert-NALPath $ServerNALPath
			$strSiteCode = $PkgDist.SiteCode
			$LastRefreshTime = ""
		} else {
			$strDP = Convert-NALPath $ObjDP.ServerNALPath
			$strSiteCode = $ObjDP.SiteCode
			$LastRefreshTime = [System.Management.ManagementDateTimeconverter]::ToDateTime($ObjDP.LastRefreshTime)
		}
		
		#Convert Last Copied time
		if ($PkgDist.LastCopied -ne $null)
		{
			$LastCopied = [System.Management.ManagementDateTimeconverter]::ToDateTime($PkgDist.LastCopied)
		} else {
			$LastCopied = ""
		}
		
		#Convert Summart Date
		if ($PkgDist.SummaryDate -ne $null)
		{
			$SummaryDate = [System.Management.ManagementDateTimeconverter]::ToDateTime($PkgDist.SummaryDate)
		} else {
			$SummaryDate = ""
		}
		
		$objActivePkgDist = New-Object psobject
		if (!($arrSkippedSites.contains($strSiteCode)))
		{
			Add-Member -InputObject $objActivePkgDist -MemberType NoteProperty -Name "Package Name" -Value $ObjPkg.Name
			Add-Member -InputObject $objActivePkgDist -MemberType NoteProperty -Name "Package ID" -Value $ObjPkg.PackageID
			Add-Member -InputObject $objActivePkgDist -MemberType NoteProperty -Name "Package Type" -Value $($strPkgType)
			Add-Member -InputObject $objActivePkgDist -MemberType NoteProperty -Name "Distribution Point" -Value $strDP
			Add-Member -InputObject $objActivePkgDist -MemberType NoteProperty -Name "Site Code" -Value $strSiteCode
			Add-Member -InputObject $objActivePkgDist -MemberType NoteProperty -Name "Last Refresh Time" -Value $LastRefreshTime
			Add-Member -InputObject $objActivePkgDist -MemberType NoteProperty -Name "Source Version" -Value $PkgDist.SourceVersion
			Add-Member -InputObject $objActivePkgDist -MemberType NoteProperty -Name "Last Copied" -Value $LastCopied
			Add-Member -InputObject $objActivePkgDist -MemberType NoteProperty -Name "Summary Date" -Value $SummaryDate
			Add-Member -InputObject $objActivePkgDist -MemberType NoteProperty -Name "Installation Status" -Value $(Get-PackageInstallationStatus $PkgDist.state)
			Add-Member -InputObject $objActivePkgDist -MemberType NoteProperty -Name "Branch DP" -Value $strBranchDP
			$ArrActivePkgDist += $objActivePkgDist
		}
		Remove-Variable objActivePkgDist, PkgID, ServerNALPath, objPkg, objDP, strBranchDP, FixedServerNALPath, strDP, strSiteCode, LastRefreshTime, LastCopied, SummaryDate
	}
	$ArrActivePkgDist = $ArrActivePkgDist | Sort-Object "Package Name"
	Return ,$ArrActivePkgDist
}

function Get-NormalPackagesInPXEShare ($CentralSiteCode, $CentralSiteProvider, $arrSkippedSites)
{
	$arrNormalPackagesInPXEShare = @()
	$arrAllPkgsInPXE = Get-WmiObject -Namespace root\sms\site_$CentralSiteCode -query "SELECT * FROM SMS_DistributionPoint WHERE ServerNALPath LIKE '%SMSPXEIMAGES$%' AND Status <>3" -ComputerName $CentralSiteProvider
	if ($arrAllPkgsInPXE -ne $null)
	{
		Foreach ($package in $arrAllPkgsInPXE)
		{
			$SiteCode = $package.SiteCode.ToUpper()
			$strPkgType = Get-PackageType $CentralSiteCode $CentralSiteProvider $package.packageID
			
			if (!($arrSkippedSites.contains($package.$SiteCode)) -and $strPkgType -inotmatch "boot image package")
			{
				$objPXEPkg = New-Object psobject
				#$strLocation = $package.Location.substring(23,$package.location.length-23)
				Add-Member -InputObject $objPXEPkg -membertype noteproperty -name PackageID -value $package.PackageID
				Add-Member -InputObject $objPXEPkg -membertype noteproperty -name PackageName -value $(Get-PackageName $CentralSiteCode $CentralSiteProvider $package.packageID)
				Add-Member -InputObject $objPXEPkg -membertype noteproperty -name PackageType -value $(Get-PackageType $CentralSiteCode $CentralSiteProvider $package.packageID)
				Add-Member -InputObject $objPXEPkg -membertype noteproperty -name PackageLocation -value (Convert-NALPath $package.ServerNALPath)
				Add-Member -InputObject $objPXEPkg -membertype noteproperty -name SiteCode -value $SiteCode
				Add-Member -InputObject $objPXEPkg -MemberType NoteProperty -Name Status -Value $(Get-DPStatus $package.Status)		
				$arrNormalPackagesInPXEShare += $objPXEPkg
				#Remove-Variable strLocation
			}
		}
	}
	Remove-Variable arrAllPkgsInPXE
	Return ,$arrNormalPackagesInPXEShare
}

#Get the SCCM SQL instance service name as it is not always running on default instance of MSSQLSERVER
Function Get-SQLServiceName ($siteServer)
{
	#firstly determine the registry path based on OS architecture
	$objOS = Get-WmiObject Win32_OperatingSystem -ComputerName $siteServer
	If ($objOS.version -ge 6)
	{
		$OSarch = $objOS.OSArchitecture
	} else {
		if ($objOS.caption.contains("x64"))
		{
			$OSarch = "64-bit"
		} else {
			$OSarch = "32-bit"
		}
	}
		Switch ($OSarch)
	{
		"64-bit" {$regPath = "SOFTWARE\\Wow6432Node\\Microsoft\\SMS\\SQL Server"}
		"32-bit" {$regPath = "SOFTWARE\\Microsoft\\SMS\\SQL Server"}
	}
	$reg = [microsoft.win32.registrykey]::OpenRemoteBaseKey('LocalMachine',$siteServer)
	$regKey = $reg.OpenSUbKey($regPath)
	$SQLServiceName = $regKey.GetValue("Service Name")
	Return $SQLServiceName
}

#Note:	-	I'm using this way to read SQL logs directory from master database rather than using Microsoft.SqlServer.Smo because it is much faster
#			if using Microsoft.SqlServer.Smo, the entire log needs to be retireved before filtering it thus very time consuming.
Function Get-SQLLog ($Instance)
{
	Write-Host "   Reading SQL error log for $instance" -ForegroundColor Green
	$EarlistDate = $(Get-RemoteDateTime $Instance).AddDays(-$BackupDaysToCheck)
	$arrSQLServerLogs = @()
	$sqlConnection = new-object System.Data.SqlClient.SqlConnection "server='$Instance';database=master;Integrated Security=sspi"
	$sqlConnection.Open()
	#Create a command object
	$sqlCommand = $sqlConnection.CreateCommand()
	$sqlCommand.CommandText = "xp_ReadErrorLog 0, 1, 'failed', 'error'"
	#Execute the Command
	$sqlReader = $sqlCommand.ExecuteReader()
	#Parse the records, read all three columns returned
	while ($sqlReader.Read())
	{
		$LogDate = $sqlReader[0]
		if ($LogDate -gt $EarlistDate)
		{
			$objSQLLog = New-Object psobject
			Add-Member -InputObject $objSQLLog -MemberType NoteProperty -Name LogDate -Value $LogDate
			Add-Member -InputObject $objSQLLog -MemberType NoteProperty -Name ProcessInfo -Value $sqlReader[1]
			Add-Member -InputObject $objSQLLog -MemberType NoteProperty -Name Text -Value $sqlReader[2]
			$arrSQLServerLogs += $objSQLLog
		}
		Remove-Variable LogDate
	}
	Return ,$arrSQLServerLogs
}

Function Get-SQLAgentLog ($Instance)
{
	Write-Host "   Reading SQL Agent error log for $instance" -ForegroundColor Green
	$EarlistDate = $(Get-RemoteDateTime $Instance).AddDays(-$BackupDaysToCheck)
	$arrSQLAgentLogs = @()
	$sqlConnection = new-object System.Data.SqlClient.SqlConnection "server='$instance';database=master;Integrated Security=sspi"
	$sqlConnection.Open()
	#Create a command object
	$sqlCommand = $sqlConnection.CreateCommand()
	$sqlCommand.CommandText = "xp_ReadErrorLog 0, 2, 'failed', 'error'"
	#Execute the Command
	$sqlReader = $sqlCommand.ExecuteReader()
	#Parse the records, read all three columns returned
	while ($sqlReader.Read())
	{
		$LogDate = $sqlReader[0]
		if ($LogDate -gt $EarlistDate)
		{
			$objSQLLog = New-Object psobject
			Add-Member -InputObject $objSQLLog -MemberType NoteProperty -Name LogDate -Value $LogDate
			Add-Member -InputObject $objSQLLog -MemberType NoteProperty -Name ProcessInfo -Value $sqlReader[1]
			Add-Member -InputObject $objSQLLog -MemberType NoteProperty -Name Text -Value $sqlReader[2]
			$arrSQLAgentLogs += $objSQLLog
		}
		Remove-Variable LogDate
	}
	Return ,$arrSQLAgentLogs
}

Function Ping-Check($computer, $iPingRetryWait, $iPingRetryTimes)
{
	$bPing = $false
	$ping = New-Object Net.NetworkInformation.Ping
	$PingResult = $ping.send($computer)
	if ($PingResult.Status.Tostring().ToLower() -eq "success")
	{
		$bPing = $true
	} else {
		#if first attemp failed, wait for number of seconds that's defined in XML file and try again
		Start-Sleep $iPingRetryWait
		#attemp to ping few more times (defined in XML file)
		For ($i=1; $i -le $iPingRetryTimes; $i++)
		{
			$PingResult = $ping.send($computer)
			if ($PingResult.Status.Tostring().ToLower() -eq "success")
			{
				$bPing = $true
			}
		}
		
	}
	return $bPing
}

Function Get-PrimarySites ($CentralSiteCode, $CentralSiteProvider, $arrSkippedSites)
{
	$arrPrimarySites = @()
	$arrSites=Get-WmiObject -Namespace root\sms\site_$CentralSiteCode SMS_Site -Filter "Type=2" -ComputerName $CentralSiteProvider

	foreach ($site in $arrSites)
	{
		$SiteCode = $site.SiteCode.ToUpper()
		if (!($arrSkippedSites.contains($SiteCode))) {$arrPrimarySites += $site}
	}
	Remove-Variable arrSites
	Return ,$arrPrimarySites
}

Function Get-SiteServer ($CentralSiteCode, $CentralSiteProvider, $SiteCode)
{
	$siteServerName = (Get-WmiObject -ComputerName $CentralSiteProvider -Namespace root\sms\site_$CentralSiteCode -query "SELECT * FROM SMS_SystemResourceList WHERE RoleName='SMS Site Server' AND SiteCode='$sitecode'").ServerRemoteName
	Return $siteServerName
}

Function Get-AllSiteServers ($CentralSiteCode, $CentralSiteProvider, $arrSkippedSites)
{
	$SiteRoles = Get-WmiObject -ComputerName $CentralSiteProvider -Namespace root\sms\site_$CentralSiteCode SMS_SystemResourceList

	$arrServers = new-object System.Collections.ArrayList
	Foreach ($item in $SiteRoles)
	{
		$StrFQDNinUpper = ($item.ServerRemoteName).ToUpper()
		$strSiteCodeinUpper = ($item.SiteCode).ToUpper()
		if (!($arrServers.contains($StrFQDNinUpper)) -and !($arrSkippedSites.contains($strSiteCodeinUpper)))
		{
			Write-Host "Adding $StrFQDNinUpper to the server list" -ForegroundColor Yellow
			$arrServers.Add($StrFQDNinUpper) | Out-Null
		}
	}
	$arrServers = $arrServers | sort
	Return ,$arrServers
}

Function Get-AllSCCMSQLServers ($CentralSiteCode, $CentralSiteProvider, $arrSkippedSites)
{
	$arrSQLServers = @()
	$SQLServers = Get-WmiObject -Namespace root\sms\site_$CentralSiteCode SMS_SystemResourceList -filter "RoleName = 'SMS SQL Server'" -ComputerName $CentralSiteProvider
	foreach ($SQLServer in $SQLServers)
	{
		$SiteCode = ($SQLServer.SiteCode).ToUpper()
		if (!($arrSkippedSites.contains($SiteCode))) {$arrSQLServers += $SQLServer}
	}
	Remove-Variable SQLServers 
	
	Return ,$arrSQLServers
}

Function Translate-StatusCode ($StatusCode)
{
		switch ($StatusCode)
		{
			0 {$strStatus = "OK"}
			1 {$strStatus = "Warning"}
			2 {$strStatus = "Critical"}
			default {$strStatus = "Unknown"}
		}
		Return $strStatus
}

#Provides the overall status of an individual site. The status is based on component counts and thresholds.
Function Check-SummarizerSiteStatusError ($CentralSiteCode, $CentralSiteProvider, $arrSkippedSites)
{
	$arrSiteStatus = @()
	$arrSiteWithIssues = Get-WmiObject -namespace root\sms\site_$CentralSiteCode -query "Select * from SMS_SummarizerSiteStatus where status <> 0" -ComputerName $CentralSiteProvider
	if ($arrSiteWithIssues -ne $null)
	{
		Foreach ($site in $arrSiteWithIssues)
		{
			$SiteCode = $site.SiteCode.ToUpper()
			if (!($arrSkippedSites.contains($SiteCode)))
			{
				$objStatus = New-Object psobject
				Add-Member -InputObject $objStatus -membertype noteproperty -name SiteCode -value $site.SiteCode
				Add-Member -InputObject $objStatus -MemberType NoteProperty -Name Status -Value $(Translate-StatusCode $site.Status)
				$arrSiteStatus += $objStatus
			}
		}
	}
	Remove-Variable arrSiteWithIssues
	Return ,$arrSiteStatus
}

#Provides per site status of SMS roles, such as client access points, the server running Microsoft?SQL Server? and the site server. The status is based on physical thresholds.
Function Check-SiteSystemSummarizerError ($CentralSiteCode, $CentralSiteProvider, $arrSkippedSites)
{
	$arrSiteSystemSummarizer = @()
	$arrSiteSystemWithIssues = Get-WmiObject -Namespace root\sms\Site_$CentralSiteCode -query "Select * from SMS_SiteSystemSummarizer where Status <> 0" -ComputerName $CentralSiteProvider
	if ($arrSiteSystemWithIssues -ne $null)
	{
		Foreach ($status in $arrSiteSystemWithIssues)
		{
			$SiteCode = $status.SiteCode.ToUpper()
			if (!($arrSkippedSites.contains($SiteCode)))
			{
				switch ($status.ObjectType)
				{
					0 {$ObjectType = "Directory"}
					1 {$ObjectType = "SQL_DB"}
					2 {$ObjectType = "SQL_LOG"}
					default {$ObjectType = "Unknown"}
				}
				
				$objSiteSystemStatus = New-Object psobject
				Add-Member -InputObject $objSiteSystemStatus -MemberType NoteProperty -Name SiteCode -Value $status.SiteCode
				Add-Member -InputObject $objSiteSystemStatus -MemberType NoteProperty -Name Role -Value $status.Role
				Add-Member -InputObject $objSiteSystemStatus -MemberType NoteProperty -Name ObjectType -Value $ObjectType
				Add-Member -InputObject $objSiteSystemStatus -MemberType NoteProperty -Name PercentFree -Value $status.PercentFree
				Add-Member -InputObject $objSiteSystemStatus -MemberType NoteProperty -Name Status -Value $(Translate-StatusCode $status.status)
				$arrSiteSystemSummarizer += $objSiteSystemStatus
			}
		}
	}
	Remove-Variable arrSiteSystemWithIssues
	Return ,$arrSiteSystemSummarizer
}

Function Check-ComponentSummarizerError ($CentralSiteCode, $CentralSiteProvider, $TallyInterval, $arrSkippedSites)
{
	$arrComponentSummarizer = @()
	$arrCompoentsWithIssues = Get-WmiObject -Namespace root\sms\Site_$CentralSiteCode -query "Select * from SMS_ComponentSummarizer where Status <> 0 AND TallyInterval = '$TallyInterval'" -ComputerName $CentralSiteProvider
	if ($arrCompoentsWithIssues -ne $null)
	{
		Foreach ($CompStatus in $arrCompoentsWithIssues)
		{
			$SiteCode = $CompStatus.SiteCode.ToUpper()
			if (!($arrSkippedSites.contains($SiteCode)))
			{
				switch ($CompStatus.state)
				{
					0 {$strState = "STOPPED"}
					1 {$strState = "STARTED"}
					2 {$strState = "PAUSED"}
					3 {$strState = "INSTALLING"}
					4 {$strState = "RE_INSTALLING"}
					5 {$strState = "DE_INSTALLING"}
					default {$strState = "UNKNOWN"}
				}
				
				$objComponentStatus = New-Object psobject
				Add-Member -InputObject $objComponentStatus -MemberType NoteProperty -Name SiteCode -Value $CompStatus.SiteCode
				Add-Member -InputObject $objComponentStatus -MemberType NoteProperty -Name MachineName -Value $CompStatus.MachineName
				Add-Member -InputObject $objComponentStatus -MemberType NoteProperty -Name ComponentName -Value $CompStatus.ComponentName
				Add-Member -InputObject $objComponentStatus -MemberType NoteProperty -Name Errors -Value $CompStatus.Errors
				Add-Member -InputObject $objComponentStatus -MemberType NoteProperty -Name Warnings -Value $CompStatus.Warnings
				Add-Member -InputObject $objComponentStatus -MemberType NoteProperty -Name Infos -Value $CompStatus.infos
				Add-Member -InputObject $objComponentStatus -MemberType NoteProperty -Name State -Value $strState
				Add-Member -InputObject $objComponentStatus -MemberType NoteProperty -Name Status -Value $(Translate-StatusCode $CompStatus.status)
				$arrComponentSummarizer += $objComponentStatus
			}
		}
	}
	Remove-Variable arrCompoentsWithIssues
	Return ,$arrComponentSummarizer
} 

$thisScript = Split-Path $myInvocation.MyCommand.Path -Leaf
$scriptRoot = Split-Path (Resolve-Path $myInvocation.MyCommand.Path)

$outputFileName = "SCCM_Health_Check_$strDate.txt"
$output = Join-Path $scriptRoot $outputFileName
$diruse = Join-Path $scriptRoot "diruse.exe" -Resolve
$sh = New-Object -comobject "wscript.shell"

if (Test-Path $output) {Remove-Item $output -Force}

$ConfigXML = Join-Path $scriptRoot "Health-Check.XML"
$xml = [xml](get-content $configXML)

$T1PSS = $xml.Configuration.PrimarySiteServer.Name	#Tier 1 (top tier) primary site server
$iPingRetryWait = $xml.Configuration.Ping.Retry.RetryWait.Value
$iPingRetryTimes = $xml.Configuration.Ping.Retry.NumberOfPings.Value
$BackupDaysToCheck = $xml.Configuration.Backup.DaysToCheck
$PSRemoting = $xml.Configuration.PSRemoting.Value
$DNSCheck = $xml.Configuration.DNSCheck.Value
$SQLLogsCheck = $xml.Configuration.SQLLogsCheck.Value
$EmailOutput = $xml.Configuration.EmailOutput
[int]$inboxThreshold = $xml.Configuration.SCCMInbox.Threshold
$SkippedSites = @()
$SkippedSites += $xml.Configuration.Skip.Site
$arrSkippedSites = New-Object System.Collections.ArrayList
foreach ($item in $SkippedSites) {$arrSkippedSites.Add(($item.ToUpper())) | Out-Null}
Write-Host "The following sites will be skipped:" -ForegroundColor Green
Write-Host $arrSkippedSites -ForegroundColor Green

Remove-Variable SkippedSites

$StartDate = $date.AddDays(-$BackupDaysToCheck)

$objSite = Get-WmiObject -ComputerName $T1PSS -Namespace root\sms -query "Select * from SMS_ProviderLocation WHERE ProviderForLocalSite = True"
$CentralSiteCode= $objSite.SiteCode
$CentralSiteProvider = $objSite.Machine
$CentralSiteProviderDate = Get-RemoteDateTime $CentralSiteProvider
$TallyInterval = Get-TallyInterval $CentralSiteProviderDate $BackupDaysToCheck

Write-Host "Central Site Code: $CentralSiteCode" -ForegroundColor Green
Write-Host "Central Site Provider: $CentralSiteProvider" -ForegroundColor Green
Write-Host "Getting all Primary Sites..." -ForegroundColor Green
$arrPrimarySites = Get-PrimarySites $CentralSiteCode $CentralSiteProvider $arrSkippedSites
Write-Host "Getting all site servers..." -ForegroundColor Green
$arrAllSiteServers = Get-AllSiteServers $CentralSiteCode $CentralSiteProvider $arrSkippedSites

##Print title
Out-File -FilePath $output -InputObject  "SCCM Health Check Report  - $strDate:" -Append
Out-File -FilePath $output -InputObject  "----------------------------------" -Append
Out-File -FilePath $output -InputObject  "" -Append

##Ping Check
Write-Host "--Ping Checking all site systems..." -ForegroundColor Green
$arrFailedToPing = @()
$arrSuccessfulPing = @()
$arrIncorrectDNS = @()
Foreach ($siteServer in $arrAllSiteServers)
{
	if (!(Ping-check $siteServer $iPingRetryWait $iPingRetryTimes))
	{
		$arrFailedToPing += $siteServer
	} else {
		$arrSuccessfulPing += $siteServer
	}
}
Out-File -FilePath $output -InputObject  "Servers failed ping test:" -Append
Out-File -FilePath $output -InputObject  "" -Append

$Global:strEmailBody = $Global:strEmailBody + @"
<h3>The following servers failed ping test:</h3>
"@
If ($arrFailedToPing.count -gt 0)
{
$arrFailedToPing | Out-File $output -Append
$Global:strEmailBody = $Global:strEmailBody + @"
<ul>
"@
foreach ($item in $arrFailedToPing)
{
$Global:strEmailBody = $Global:strEmailBody + @"
<li>$item</li>

"@
}
$Global:strEmailBody = $Global:strEmailBody + @"
</ul>
<hr>

"@
	
} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>
"@
	Out-File -FilePath $output -InputObject  "None" -Append
}
Out-File -FilePath $output -InputObject  "----------------------------------" -Append
Out-File -FilePath $output -InputObject  "" -Append

##DNS Check
If ($DNSCheck -ieq "enabled")
{
$DNSDll = Join-Path $scriptRoot "JHSoftware.DnsClient.dll" -Resolve
[System.Reflection.Assembly]::LoadFile("$DNSDll") | Out-Null
$DNSSuffix = $xml.Configuration.DNSCheck.Suffix
$arrExemptionDevices = New-Object system.Collections.ArrayList
$DNSExemption = $xml.Configuration.DNSCheck.Exemption
if ($DNSExemption -ne $null)
{
	Foreach ($device in $DNSExemption.device)
	{
		$objExemption = New-Object psobject
		Add-Member -InputObject $objExemption -MemberType NoteProperty -Name Name -Value $device.name
		Add-Member -InputObject $objExemption -MemberType NoteProperty -Name DNSSuffix -Value $device.DNSSuffix
		Add-Member -InputObject $objExemption -MemberType NoteProperty -Name NoPTRRecord -Value $device.NoPTRRecord
		[Void]$arrExemptionDevices.Add($objExemption)
		Remove-Variable objExemption
	}
}

Write-Host "--Checking DNS configurations for all site systems..." -ForegroundColor Green
Foreach ($siteServer in $arrSuccessfulPing)
{
	Write-Host "  -Checking DNS configurations for $siteServer..." -ForegroundColor Green
	$objDNSCheck = Validate-DNSRecord $siteServer $DNSSuffix $arrExemptionDevices
	$iValidDNS = $objDNSCheck."Overall Check Result"

	if ($iValidDNS -ne 0)
	{
		$arrIncorrectDNS += $objDNSCheck
	}
	Remove-Variable objDNSCheck
}



Out-File -FilePath $output -InputObject  "Servers With Incorrect DNS Configuration:" -Append
Out-File -FilePath $output -InputObject  "" -Append

$Global:strEmailBody = $Global:strEmailBody + @"
<h3>The following servers failed DNS configuration test:</h3>
"@
If ($arrIncorrectDNS.count -gt 0)
{
$arrIncorrectDNS | Format-Table "Server Name", "Server Name matches FQDN from Computer WMI", "FQDN from Computer WMI", "FQDN from SCCM matches DNS A Record", "IP Address From Forward Lookup", "Multiple Host Records", "A Records Exist in Other Domains", "DNS A Records from ALL Domains", "Host Name From Forward Lookup", "PTR Record matches FQDN from SCCM", "Host Name From Reverse Lookup" -AutoSize | Out-File $output -Append
$Global:strEmailBody = $Global:strEmailBody + @"
$($arrIncorrectDNS | Select-Object "Server Name", "Server Name matches FQDN from Computer WMI", "FQDN from Computer WMI", "FQDN from SCCM matches DNS A Record", "IP Address From Forward Lookup", "Multiple Host Records", "A Records Exist in Other Domains", "DNS A Records from ALL Domains", "Host Name From Forward Lookup", "PTR Record matches FQDN from SCCM", "Host Name From Reverse Lookup" | ConvertTo-HTML -fragment)
<hr>

"@
} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>
"@
	Out-File -FilePath $output -InputObject  "None" -Append
}
Out-File -FilePath $output -InputObject  "----------------------------------" -Append
Out-File -FilePath $output -InputObject  "" -Append
}

##Sites Status Checks
#Overall site status
Write-Host "--Checking site status..." -ForegroundColor Green
$SiteWithIssues = @()
$SiteWithIssues += Check-SummarizerSiteStatusError $CentralSiteCode $CentralSiteProvider $arrSkippedSites

Out-File -FilePath $output -InputObject  "Sites with issues" -Append
$Global:strEmailBody = $Global:strEmailBody + @"
<h3>Sites with issues:</h3>
"@
If ($SiteWithIssues.count -gt 0)
{
	$SiteWithIssues | Format-Table * -AutoSize | Out-File $output -Append
$Global:strEmailBody = $Global:strEmailBody + @"
$($SiteWithIssues | ConvertTo-HTML -fragment)
<hr>

"@

} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>

"@
	Out-File -FilePath $output -InputObject  "None" -Append
}

Out-File -FilePath $output -InputObject  "----------------------------------" -Append
Out-File -FilePath $output -InputObject  "" -Append

#site systems with issues
Write-Host "--Checking site systems status..." -ForegroundColor Green
$SiteSystemsWithIssues = @()
$SiteSystemsWithIssues += Check-SiteSystemSummarizerError $CentralSiteCode $CentralSiteProvider $arrSkippedSites
Out-File -FilePath $output -InputObject "Site Systems with issues" -Append
$Global:strEmailBody = $Global:strEmailBody + @"
<h3>Site Systems with issues:</h3>
"@
If ($SiteSystemsWithIssues.count -gt 0)
{
	$SiteSystemsWithIssues | Format-Table * -AutoSize | Out-File $output -Append
$Global:strEmailBody = $Global:strEmailBody + @"
$($SiteSystemsWithIssues | ConvertTo-HTML -fragment)
<hr>

"@
} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>

"@
	Out-File -FilePath $output -InputObject  "None" -Append
}
Out-File -FilePath $output -InputObject  "----------------------------------" -Append
Out-File -FilePath $output -InputObject  "" -Append

#Components with issues
Write-Host "--Checking SCCM components status..." -ForegroundColor Green
$ComponentsWithIssues = @()
$ComponentsWithIssues += Check-ComponentSummarizerError $CentralSiteCode $CentralSiteProvider $TallyInterval $arrSkippedSites
Out-File -FilePath $output -InputObject "Components with issues" -Append
$Global:strEmailBody = $Global:strEmailBody + @"
<h3>Components with issues:</h3>
"@
If ($ComponentsWithIssues.count -gt 0)
{
	$ComponentsWithIssues | Format-Table * -AutoSize | Out-File $output -Append
$Global:strEmailBody = $Global:strEmailBody + @"
$($ComponentsWithIssues | ConvertTo-HTML -fragment)
<hr>

"@
} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>

"@
	Out-File -FilePath $output -InputObject  "None" -Append
}
Out-File -FilePath $output -InputObject  "----------------------------------" -Append
Out-File -FilePath $output -InputObject  "" -Append


##Packages Check
#Package Distribution with issues
Write-Host "--Checking SCCM package distributions..." -ForegroundColor Green
Out-File -FilePath $output -InputObject "Package Distributions with issues" -Append
Out-File -FilePath $output -InputObject "" -Append
$arrPkgDistWithIssues = Get-PackagesWithIssues $CentralSiteCode $CentralSiteProvider $arrSkippedSites
$Global:strEmailBody = $Global:strEmailBody + @"
<h3>Package Distributions with issues:</h3>
"@
if ($arrPkgDistWithIssues.count -gt 0)
{
	$arrPkgDistWithIssues | Format-table * -AutoSize | Out-File $output -Append
$Global:strEmailBody = $Global:strEmailBody + @"
$($arrPkgDistWithIssues | ConvertTo-HTML -fragment)
<hr>

"@
} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>

"@
	Out-File -FilePath $output -InputObject "None" -Append
}
Out-File -FilePath $output -InputObject  "----------------------------------" -Append

#Check All active package distributions
Write-Host "--Checking All active package distributions..." -ForegroundColor Green
Out-File -FilePath $output -InputObject "Current Active Package Distributions" -Append
Out-File -FilePath $output -InputObject "" -Append
$arrCurrentPkgDist = Get-ActivePackageDistributions $CentralSiteCode $CentralSiteProvider $arrSkippedSites
$Global:strEmailBody = $Global:strEmailBody + @"
<h3>Current Active Packge Distributions:</h3>
"@
if ($arrCurrentPkgDist.count -gt 0)
{
	"Total`: $($arrCurrentPkgDist.count)" | Out-File $output -Append
	$arrCurrentPkgDist | Format-table * -AutoSize | Out-File $output -Append
$Global:strEmailBody = $Global:strEmailBody + @"
<b>Total`: $($arrCurrentPkgDist.count)</b>
$($arrCurrentPkgDist | ConvertTo-HTML -fragment)
<hr>

"@
} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>

"@
	Out-File -FilePath $output -InputObject "None" -Append
}
Out-File -FilePath $output -InputObject  "----------------------------------" -Append

#Checking Packages in PXE shares
Write-Host "--Checking SCCM packages in PXE shares..." -ForegroundColor Green
Out-File -FilePath $output -InputObject "Non-Boot Image packages in PXE shares" -Append
Out-File -FilePath $output -InputObject "" -Append
$arrNormalPkgsInPXE = Get-NormalPackagesInPXEShare $CentralSiteCode $CentralSiteProvider $arrSkippedSites
$Global:strEmailBody = $Global:strEmailBody + @"
<h3>Non-Boot Image packages in PXE shares:</h3>
"@
if ($arrNormalPkgsInPXE.count -gt 0)
{
	$arrNormalPkgsInPXE | Format-table * -AutoSize | Out-File $output -Append
$Global:strEmailBody = $Global:strEmailBody + @"
$($arrNormalPkgsInPXE | ConvertTo-HTML -fragment)
<hr>

"@
} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>

"@
	Out-File -FilePath $output -InputObject "None" -Append
}
Out-File -FilePath $output -InputObject  "----------------------------------" -Append

##Inboxes checks
Write-Host "--Checking inboxes..." -ForegroundColor Green
$arrInboxSummary = @()
$arrInboxWithIssues = @()
#$arrTotalCount = @()

Foreach ($site in $arrPrimarySites)
{
	
	Write-Host "   Checking $($Site.Sitecode)..." -ForegroundColor Green
	$localTime = get-RemoteDateTime $($site.Servername)
	Out-File -FilePath $output -InputObject " $($site.sitecode) inboxes sizes on $($site.Servername) at local time $localtime" -Append
	if ($PSRemoting -ieq "enabled")
	{
		#USE Get-ChildItem and PowerShell Remoting to retreive inboxes usage information.
		$arrInboxesSizes = @()

		$PSRemoteSession = New-PSSession -ComputerName $($site.Servername)

		$SCCMInboxesDir = Join-path ((Get-WmiObject Win32_share -ComputerName $site.ServerName | Where-Object {$_.Path -eq $site.InstallDir}).path) "inboxes"
		Write-Host "    * inboxes location: $SCCMInboxesDir on $($site.Servername)" -ForegroundColor Green
		Invoke-Command -Session $PSRemoteSession -Scriptblock {
			param ($SCCMInboxesDir, $siteCode, $siteServer)
			$arrInboxDetails = @()
			if (Test-Path $SCCMInboxesDir)
			{
				$bValidInboxPath = $true
				$objTotal = Get-ChildItem $SCCMInboxesDir -Recurse | Where-Object {$_.PSIsContainer -eq $false} | Measure-Object -Property length -Sum
				$TotalNumber = $objTotal.count
				$TotalSize = "{0:N2}" -f ($objTotal.sum / 1MB)
				$objSiteInboxTotal = New-Object psobject
				Add-Member -InputObject $objSiteInboxTotal -MemberType NoteProperty -Name "Site Code" -Value $siteCode
				Add-Member -InputObject $objSiteInboxTotal -MemberType NoteProperty -Name "Site Server" -Value $siteServer
				Add-Member -InputObject $objSiteInboxTotal -MemberType NoteProperty -Name "Inbox Folder" -Value $SCCMInboxesDir
				Add-Member -InputObject $objSiteInboxTotal -MemberType NoteProperty -Name "Total Number of Files" -Value $TotalNumber
				Add-Member -InputObject $objSiteInboxTotal -MemberType NoteProperty -Name "Total Size" -Value $TotalSize
				$arrInboxesSizes = @()
				Foreach ($inbox in (Get-ChildItem $SCCMInboxesDir -Recurse | Where-Object {$_.PSIsContainer -eq $true}))
				{
					#we are only interested in the bottom level folders, not interested in top level sub folders such as inboxes\auth
					#if ((Get-ChildItem $inbox.FullName | Where-Object {$_.PSIsContainer -eq $true}) -ne $null)
					#{
						$colChildItems = Get-ChildItem $inbox.FullName | Where-Object {$_.PSIsContainer -eq $false} | Measure-Object -property length -sum
						if ($($colChildItems.count) -lt 1) {$InboxFileCount = 0} else {$InboxFileCount = $colChildItems.count}
						if ($InboxFileCount -gt 0)
						{
							$objInbox = New-Object psobject
							Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Site Code" -Value $siteCode
							Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Server Name" -Value $siteServer
							Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Inbox Location" -Value $inbox.FullName
							Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Files in Inbox" -Value $InboxFileCount
							Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Inbox Size" -Value $("{0:N2}" -f ($colChildItems.sum / 1MB) + " MB")
							Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Total Files in All Inboxes" -Value $TotalNumber
							Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Total Size" -Value "$TotalSize MB"
							$arrInboxDetails += $objInbox
							Remove-Variable objInbox
						}
						Remove-Variable InboxFileCount
					#}
				}
				Write-Host "   -Total number of item in $siteCode inbox is $TotalNumber" -ForegroundColor Green
				Write-Host "   -Total size in $siteCode inbox is $TotalSize MB" -ForegroundColor Green
				Remove-Variable TotalSize, TotalNumber
				$arrInboxDetails = $arrInboxDetails | Sort-Object "Files in Inbox" -Descending
			} else {
				$bValidInboxPath = $false
				
				$objInboxSummary = New-Object psobject
				Add-Member -InputObject $objInboxSummary -MemberType NoteProperty -Name SiteCode -Value $Site.Sitecode
				Add-Member -InputObject $objInboxSummary -MemberType NoteProperty -Name ServerName -Value $site.Servername
				Add-Member -InputObject $objInboxSummary -MemberType NoteProperty -Name InboxLocation -Value $SCCMInboxesDir
				Add-Member -InputObject $objInboxSummary -MemberType NoteProperty -Name TotalNumber -Value "Unknown"
				Add-Member -InputObject $objInboxSummary -MemberType NoteProperty -Name TotalSize -Value "Unknown"
			}
		} -Args $SCCMInboxesDir, $site.SiteCode, $site.ServerName
			$bValidInboxPath = Invoke-Command -Session $PSRemoteSession -ScriptBlock {$bValidInboxPath}
			if ($bValidInboxPath)
			{
				$arrInboxesSizes = Invoke-Command -Session $PSRemoteSession -ScriptBlock {$arrInboxDetails}
				$objSiteInboxTotal = Invoke-Command -Session $PSRemoteSession -ScriptBlock {$objSiteInboxTotal}
				Foreach ($item in $arrInboxesSizes)
				{
					[int]$InboxFileCount = $item."Files in Inbox"
					if ($InboxFileCount -ge $inboxThreshold)
					{
							$arrInboxSummary += $item
					}
					Remove-Variable InboxFileCount
				}
				Out-File -FilePath $output -InputObject "Inbox information for $($site.sitecode)`:" -Append
				$objSiteInboxTotal | Format-Table "Site Code", "Site Server", "Inbox Folder", "Total Number of Files", "Total Size" -AutoSize |Out-File $output -Append
				Out-File -FilePath $output -InputObject "" -Append
				Out-File -FilePath $output -InputObject "Non-Empty Inboxes for $($site.sitecode)`:" -Append
				$arrInboxesSizes | Format-Table "Site Code", "Server Name", "Inbox Location", "Files in Inbox", "Inbox Size" -AutoSize | Out-File $output -Append
				Out-File -FilePath $output -InputObject "-------------------------------" -Append
			} else {
				Out-File -FilePath $output -InputObject "$SCCMInboxesDir not accessible. please check!" -Append
				$objInboxSummary = Invoke-Command -Session $PSRemoteSession -ScriptBlock {$objInboxSummary}
				$arrInboxWithIssues += $objInboxSummary
			}
			
			Remove-PSSession $PSRemoteSession


	} else {
		#Use DIRUSE.EXE to retrieve inbox usage information
		$arrInboxDetails = @()
		$SCCMInboxesDir = Join-Path "\\$($site.Servername)" (Join-path (Get-WmiObject Win32_share -ComputerName $site.ServerName | Where-Object {$_.Path -eq $site.InstallDir}).Name "inboxes")
		if (Test-Path $SCCMInboxesDir)
		{
			$inboxUsage = cmd /c $diruse /s /m $SCCMInboxesDir
			#$inboxUsage | Out-File -FilePath $output -Append
			$TotalSize = ($inboxUsage[$inboxUsage.Count-1].trim().replace("  ",";").split(";"))[0]
			$TotalNumber = [int]($inboxUsage[$inboxUsage.Count-1].trim().replace("  ",";").split(";"))[1]
			
			$objSiteInboxTotal = New-Object psobject
			Add-Member -InputObject $objSiteInboxTotal -MemberType NoteProperty -Name "Site Code" -Value $Site.Sitecode
			Add-Member -InputObject $objSiteInboxTotal -MemberType NoteProperty -Name "Inbox Folder" -Value $SCCMInboxesDir
			Add-Member -InputObject $objSiteInboxTotal -MemberType NoteProperty -Name "Total Number of Files" -Value $TotalNumber
			Add-Member -InputObject $objSiteInboxTotal -MemberType NoteProperty -Name "Total Size" -Value $TotalSize
			#$arrTotalCount += $objSiteInboxTotal
			
			
			For ($i=2; $i -lt ($inboxUsage.count-3); $i++)
			{
				$inboxValue = @()
				foreach ($item in $inboxUsage[$i].split(" "))
				{
					
					if ($item.trim().length -gt 0 -and $item -notmatch "SUB-TOTAL:")
					{
						$inboxValue += $item
					}
				}
				$InboxSize = $inboxValue[0]
				[int]$InboxFileCount = $inboxValue[1]
				$InboxLocation = $inboxValue[2]
				if ($InboxFileCount -gt 0)
				{
					$objInbox = New-Object psobject
					Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Site Code" -Value $Site.Sitecode
					Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Server Name" -Value $site.Servername
					Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Inbox Location" -Value $InboxLocation
					Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Files in Inbox" -Value $InboxFileCount
					Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Inbox Size" -Value "$InboxSize MB"
					Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Total Files in All Inboxes" -Value $TotalNumber
					Add-Member -InputObject $objInbox -MemberType NoteProperty -Name "Total Size" -Value "$TotalSize MB"
					$arrInboxDetails += $objInbox
					if ($InboxFileCount -ge $inboxThreshold)
					{
						$arrInboxSummary += $objInbox
					}
					Remove-Variable objInbox
				}
				Remove-Variable InboxSize, InboxFileCount, InboxLocation
			}
			Write-Host "   -Total number of item in $($site.sitecode) inbox is $TotalNumber" -ForegroundColor Green
			Remove-Variable TotalSize, TotalNumber
			$arrInboxDetails = $arrInboxDetails | Sort-Object "Files in Inbox" -Descending
			Out-File -FilePath $output -InputObject "Inbox information for $($site.sitecode)`:" -Append
			$objSiteInboxTotal | Format-Table * -AutoSize |Out-File $output -Append
			Out-File -FilePath $output -InputObject "" -Append
			Out-File -FilePath $output -InputObject "Non-Empty Inboxes for $($site.sitecode)`:" -Append
			$arrInboxDetails | Format-Table "Site Code", "Server Name", "Inbox Location", "Files in Inbox", "Inbox Size" -AutoSize | Out-File $output -Append
			Out-File -FilePath $output -InputObject "-------------------------------" -Append
			Remove-Variable objSiteInboxTotal, arrInboxDetails
		} else {
			Out-File -FilePath $output -InputObject "$SCCMInboxesDir not accessible. please check!" -Append
			$objInboxSummary = New-Object psobject
			Add-Member -InputObject $objInboxSummary -MemberType NoteProperty -Name SiteCode -Value $Site.Sitecode
			Add-Member -InputObject $objInboxSummary -MemberType NoteProperty -Name ServerName -Value $site.Servername
			Add-Member -InputObject $objInboxSummary -MemberType NoteProperty -Name InboxLocation -Value $SCCMInboxesDir
			Add-Member -InputObject $objInboxSummary -MemberType NoteProperty -Name TotalNumber -Value "Unknown"
			Add-Member -InputObject $objInboxSummary -MemberType NoteProperty -Name TotalSize -Value "Unknown"
			$arrInboxWithIssues += $objInboxSummary
		}
	}
	Out-File -FilePath $output -InputObject "-------------------------------" -Append
	Out-File -FilePath $output -InputObject "" -Append

	Remove-Variable SCCMInboxesDir
}

$Global:strEmailBody = $Global:strEmailBody + @"
<h3>Primary Sites Inboxes that are over the threshold of $inboxThreshold :</h3>
"@

if ($arrInboxSummary.count -gt 0)
{
$Global:strEmailBody = $Global:strEmailBody + @"
$($arrInboxSummary | Select-object "Site Code","Server Name","Inbox Location","Files in Inbox","Inbox Size","Total Files in All Inboxes","Total Size" | ConvertTo-HTML -fragment)
<hr>

"@
} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>
"@
}

$Global:strEmailBody = $Global:strEmailBody + @"
<h3>Primary Sites Inboxes that are not contactable:</h3>
"@

if ($arrInboxWithIssues.count -gt 0)
{
$Global:strEmailBody = $Global:strEmailBody + @"
$($arrInboxWithIssues | ConvertTo-HTML -fragment)
<hr>

"@
} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>
"@
}

##Site backup Checks
Write-Host "--Checking SCCM site backups..." -ForegroundColor Green
Out-File -FilePath $output -InputObject "Backup Status Checks" -Append
Out-File -FilePath $output -InputObject "Sites With Successful Backups" -Append
#$BackupLogEntries = Check-SCCMBackups $arrPrimarySites $BackupDaysToCheck
$BackupLogEntries = Check-SCCMBackups $CentralSiteCode $CentralSiteProvider $arrPrimarySites $BackupDaysToCheck
If ($BackupLogEntries.count -gt 0)
{
	$BackupLogEntries | Format-Table * -AutoSize | Out-File $output -Append
} else {
	Out-File -FilePath $output -InputObject "None" -Append
}

Out-File -FilePath $output -InputObject "Sites Without successful Backups" -Append
$Global:strEmailBody = $Global:strEmailBody + @"
<h3>Sites without successful backups:</h3>

"@

If ($Global:arrFailedBackupSite.count -gt 0)
{
	$Global:arrFailedBackupSite | Format-Table * -AutoSize | Out-File $output -Append
$Global:strEmailBody = $Global:strEmailBody + @"
$($Global:arrFailedBackupSite | ConvertTo-HTML -fragment)
<hr>

"@
} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>

"@
	Out-File -FilePath $output -InputObject "None" -Append
}
Out-File -FilePath $output -InputObject  "----------------------------------" -Append
Out-File -FilePath $output -InputObject  "" -Append

##SQL log checks
If ($SQLLogsCheck -ieq "enabled")
{
	$arrSQLAgentLogCount = @()
	$arrSQLServerLogCount = @()
	$arrSQLNTLogCount = @()

	Write-Host "--Checking SQL logs for errors..." -ForegroundColor Green
	$arrSQLServers = Get-ALLSCCMSQLServers $CentralSiteCode $CentralSiteProvider $arrSkippedSites
	Out-File -FilePath $output -InputObject "--Checking SQL error logs" -Append
	Foreach ($SQLServer in $arrSQLServers)
	{
		$SQLInstance = $SQLServer.ServerRemoteName
		#Firstly Check SQL logs
		$LocalSiteServer = Get-SiteServer $CentralSiteCode $CentralSiteProvider $SQLServer.SiteCode
		$SQLServiceName = Get-SQLServiceName $LocalSiteServer
		Out-File -FilePath $output -InputObject "SQL Server error logs from $SQLInstance" -Append
		$objSQLServerService = Get-WmiObject win32_service -Filter "Name='$SQLServiceName'" -ComputerName $SQLInstance
		if ($objSQLServerService.State -imatch "Running")
		{
			$arrSQLServerLogs = Get-SQLLog $SQLInstance
			if ($arrSQLServerLogs.count -gt 0)
			{
				$arrSQLServerLogs | Format-List Logdate, ProcessInfo, Text | Out-File $output -Append
				$objSQLServerLogCount = New-Object psobject
				Add-Member -InputObject $objSQLServerLogCount -membertype noteproperty -name "Server Name" -value $SQLInstance
				Add-Member -InputObject $objSQLServerLogCount -membertype noteproperty -name "SQL Server Log Count" -value $arrSQLServerLogs.count
				$arrSQLServerLogCount += $objSQLServerLogCount
				Remove-Variable objSQLServerLogCount, arrSQLServerLogs
			} else {
				Out-File -FilePath $output -InputObject  "None" -Append
			}
		} else {
			Out-File -FilePath $output -InputObject  "SQL Server on $SQLInstance is not running!" -Append
		}
		Out-File -FilePath $output -InputObject  "----------------------------------" -Append
		Out-File -FilePath $output -InputObject  "" -Append
		
		#secondly check SQL agent logs
		Out-File -FilePath $output -InputObject "SQL Server Agent error logs from $SQLInstance" -Append
		$SQLAgentServiceDisplayName = "SQL Server Agent `($SQLServiceName`)"
		$objSQLAgentService = Get-WmiObject win32_service -Filter "DisplayName='$SQLAgentServiceDisplayName'" -ComputerName $SQLInstance
		if ($objSQLAgentService.State -imatch "Running")
		{
			$arrSQLAgentLogs = Get-SQLAgentLog $SQLInstance
			if ($arrSQLAgentLogs.count -gt 0)
			{
				$arrSQLAgentLogs | Format-List Logdate, LogLevel, Text | Out-File $output -Append
				$objSQLAgentLogCount = New-Object psobject
				Add-Member -InputObject $objSQLAgentLogCount -membertype noteproperty -name "Server Name" -value $SQLInstance
				Add-Member -InputObject $objSQLAgentLogCount -membertype noteproperty -name "SQL Agent Log Count" -value $arrSQLAgentLogs.count
				$arrSQLAgentLogCount += $objSQLAgentLogCount
				Remove-Variable objSQLAgentLogCount, arrSQLAgentLogs
			} else {
				Out-File -FilePath $output -InputObject  "None" -Append
			}
		} else {
			Out-File -FilePath $output -InputObject  "SQL Server Agent on $SQLInstance is not running!" -Append
		}
		Out-File -FilePath $output -InputObject  "----------------------------------" -Append
		Out-File -FilePath $output -InputObject  "" -Append
			
		#finally Check Windows Application event log for SQL related messages
		Write-Host "   Checking SQL related errors from NT Event log on $SQLInstance" -ForegroundColor Green
		#$arrSQLEventLogEntries = @()
		Out-File -FilePath $output -InputObject "SQL related warning and error Windows application event logs from $($SQLServer.ServerRemoteName)" -Append
		$StartDate = (Get-Date).AddDays(-$BackupDaysToCheck)
		#$arrSQLEventLogEntries += get-eventlog application -ComputerName $($SQLServer.ServerRemoteName) -Source "*SQL*" -EntryType Error -After $StartDate
			$arrSQLEventLogEntries = get-winevent -FilterHashtable @{logname="application";starttime=$startDate;level=1,2,3;providername="*SQL*"} -ComputerName $($SQLServer.ServerRemoteName)	
		If ($arrSQLEventLogEntries -ne $null)
		{
			$arrSQLEventLogEntries | Format-List Message,Id,ProviderName,MachineName,TimeCreated | Out-File $output -Append
			if ($arrSQLEventLogEntries.count -eq $null)
			{
				$iCount = 1
			} else {
				$iCount = $arrSQLEventLogEntries.count
			}
			$objSQLNTLogCount = New-Object psobject
			Add-Member -InputObject $objSQLNTLogCount -membertype noteproperty -name "Server Name" -value $SQLInstance
			Add-Member -InputObject $objSQLNTLogCount -membertype noteproperty -name "SQL NT Log Count" -value $iCount
			$arrSQLNTLogCount += $objSQLNTLogCount
			Remove-Variable objSQLNTLogCount, arrSQLEventLogEntries, iCount
		} else {
			Out-File -FilePath $output -InputObject  "None" -Append
			Out-File -FilePath $output -InputObject  "" -Append
		}
		
		Out-File -FilePath $output -InputObject  "----------------------------------" -Append
		Out-File -FilePath $output -InputObject  "" -Append
	}

$Global:strEmailBody = $Global:strEmailBody + @"
<h3>SQL Server Error Log Count:</h3>
"@
if ($arrSQLServerLogCount.count -gt 0)
{
$Global:strEmailBody = $Global:strEmailBody + @"
$($arrSQLServerLogCount | ConvertTo-HTML -fragment)
<hr>

"@
} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>

"@
}

$Global:strEmailBody = $Global:strEmailBody + @"
<h3>SQL Agent Error Log Count:</h3>
"@
if ($arrSQLAgentLogCount.count -gt 0)
{
$Global:strEmailBody = $Global:strEmailBody + @"
$($arrSQLAgentLogCount | ConvertTo-HTML -fragment)
<hr>

"@
} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>

"@
}

$Global:strEmailBody = $Global:strEmailBody + @"
<h3>Count for SQL related logs from OS Application Event Log:</h3>
"@
if ($arrSQLNTLogCount.count -gt 0)
{
$Global:strEmailBody = $Global:strEmailBody + @"
$($arrSQLNTLogCount | ConvertTo-HTML -fragment)
<hr>

"@
} else {
$Global:strEmailBody = $Global:strEmailBody + @"
<p>None</p>
<hr>

"@
}
}

$Global:strEmailBody = $Global:strEmailBody + @"
<h3>Detailed Health Check report attached...</h3>
</body>
</html>
"@

Write-Host "Done!" -ForegroundColor Green
Out-File -FilePath $output -InputObject  "$((get-date).tostring()) - Health Check script completed." -Append

If ($EmailOutput -ieq "yes")
{
	$EmailMethod = $xml.Configuration.EmailMethod.Value
	##Email out the output
	#firstly, zip the output
	$ziplib = Join-Path $scriptRoot "ICSharpCode.SharpZipLib.dll"
	[System.Reflection.Assembly]::LoadFrom("$ziplib")
	$outputBaseName = (Get-ChildItem $output).BaseName
	$outputZipName = "$outputBaseName.zip"
	$outputZipPath = Join-Path $scriptRoot $outputZipName
	$objZip = New-Object ICSharpCode.SharpZipLib.Zip.FastZip
	$objZip.CreateZip($outputZipPath,$scriptRoot,$true,"$outputFileName")
	#remove the original txt file since it's already zipped up.
	Remove-Item $output -Force
	Write-Host "--Emailing Health Check result.." -ForegroundColor Green
	$SMTPServer = $xml.Configuration.SMTP.ServerName
	$SMTPPort = $xml.Configuration.SMTP.Port
	$SenderName = $xml.Configuration.SMTP.SenderName
	$SenderAddress = $xml.Configuration.SMTP.SenderAddress
	$RecipientAddress = $xml.Configuration.SMTP.RecipientAddress
	
	$strOrgName = $xml.Configuration.SMTP.OrganizationName
	Write-Host "  -The following email settings are used:" -ForegroundColor Yellow
	Write-Host "  -SMTP Server:			$SMTPServer" -ForegroundColor Yellow
	Write-Host "  -SMTP Port:			$SMTPPort" -ForegroundColor Yellow
	Write-Host "  -Sender Name:			$SenderName" -ForegroundColor Yellow
	Write-Host "  -Sender Address:		$SenderAddress" -ForegroundColor Yellow
	Write-Host "  -Recipient Address:	$RecipientAddress" -ForegroundColor Yellow
	$strSubject = "$strOrgName SCCM Health Check - $Date"
	if ($EmailMethod -ieq "cdo")
	{
		$Sender = "`"$SenderName`" `<$SenderAddress`>"
		If ($RecipientAddress.Gettype().BaseType.Name -eq "Array")
		{
			$RecipientAddress = ([string]$RecipientAddress).replace(" ", ", ")
		}
		$msg = new-Object -comobject "CDO.Message";
		$msg.Configuration.Fields.Item("http://schemas.microsoft.com/cdo/configuration/sendusing") = 2
		$msg.Configuration.Fields.Item("http://schemas.microsoft.com/cdo/configuration/smtpserver") = $SMTPServer
		$msg.Configuration.Fields.item("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = 2
		$msg.Configuration.Fields.Item("http://schemas.microsoft.com/cdo/configuration/smtpserverport") = 25
		$msg.Configuration.Fields.Update()
		$msg.From = $Sender
		$msg.To = $RecipientAddress
		$msg.Subject = $strSubject
		$msg.HTMLBody = $Global:strEmailBody
		$msg.AddAttachment($outputZipPath)
		$msg.Send()
		Remove-Variable msg
	} elseif ($EmailMethod -ieq "dotnet")
	{
		$MailMessage = New-Object System.Net.Mail.MailMessage
		$MailMessage.IsBodyHtml = $true
		$SMTPClient = New-Object System.Net.Mail.smtpClient

		$SMTPClient.host = $SMTPServer
		$SMTPClient.port = $SMTPPort
		
		$strBody = "Health Check result attached."

		$Sender = New-Object System.Net.Mail.MailAddress($SenderAddress, $SenderName)

		If ($RecipientAddress.Gettype().BaseType.Name -eq "Array")
		{
			Foreach ($item in $RecipientAddress)
			{
				$Recipient = New-Object System.Net.Mail.MailAddress($item)
				$MailMessage.To.Add($item)
			}
		} else {
			$Recipient = New-Object System.Net.Mail.MailAddress($RecipientAddress)
			$MailMessage.To.Add($Recipient)
		}

		$MailMessage.Subject = $strSubject
		$MailMessage.Sender = $Sender
		$MailMessage.From = $Sender
		$MailMessage.Subject = $strSubject
		$MailMessage.Body = $Global:strEmailBody
		$MailMessage.attachments.add($outputZipPath)
		$SMTPClient.Send($MailMessage)
		$MailMessage.Dispose()
	}
} else {
	Write-Host "--The Health Check result will not be emailed out. Please check manually." -ForegroundColor Green
}
##Clean up
#Remove-Item $output -Force
#if ($Error.Count -eq 0)
#{
#	$Host.SetShouldExit(0)
#} else {
#	$Host.SetShouldExit(1)
#}
#	
