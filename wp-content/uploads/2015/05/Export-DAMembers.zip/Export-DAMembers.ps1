<# 
 .SYNOPSIS
  Get monitoring objects that are members of a Distributed Application in OpsMgr and export to a CSV file.

 .DESCRIPTION
  Get monitoring objects that are members of a Distributed Application in OpsMgr using OpsMgr SDK and export to a CSV file. By default, this function only retries objects one level down. Users can use -Recursive parameter to retrieve all objects within the DA hierarchy. 

 .PARAMETER -SDK
  OpsMgr Management Server name

 .PARAMETER -UserName
  Alternative user name to connect to the management group (optional).

 .PARAMETER -Password
  Alternative password to connect to the management group (optional).

 .PARAMETER -DAFullName
  Full Name for the Distributed Application.

 .PARAMETER -DADisplayName
  Alternatively, specify the Distributed Application display name. Please keep in mind the display name is not unique. if there are more than 1 DAs having the same display name, the script will fail.

 .PARAMETER -Recursive
  Set this parameter to true when retrieving all objects. WARNING: depending on the size of the DA, this could take a very long time.

 .PARAMETER -ExportProperties
  Use this parameter to specify only a subset of properties to be exported to CSV. This parameter is an array. 

 .PARAMETER -Path
  The path of the export CSV file.

 .EXAMPLE
  # Connect to OpsMgr management group via management server "OpsMgrMS01" and export the members of the ConfigMgr DA:
   Management Server: "OpsMgrMS01"
   Username: "domain\SCOM.Admin"
   Password "password1234"
   DA Full Name: "Microsoft.SystemCenter2012.ConfigurationManagement"

  $Password = ConvertTo-SecureString -AsPlainText "password1234" -force
  .\Export-OMDAMembers.ps1 -SDK "OpsMgrMS01" -Username "domain\SCOM.Admin" -Password $Password -DAFullName "Microsoft.SystemCenter2012.ConfigurationManagement" -Path C:\Temp\ConfigMgrDA.csv

 .EXAMPLE
   # Connect to OpsMgr management group via management server "OpsMgrMS01" and then get members of the ConfigMgr DA:
   Management Server: "OpsMgrMS01"
   DA Display Name: "ConfigMgr"
   Get all members in the hierarchy (recursive lookup)
   Only get the Display Name and Id properties
   Verbose output
  
  $SDKConnection = Get-AutomationConnection -Name OpsMgrSDK_TYANG
  Get-OMDAMembers -SDK "OpsMgrMS01" -DADisplayName "ConfigMgr" -Recursive $true -ExportProperties ("DisplayName, "Id") -Path C:\Temp\ConfigMgrDA.csv -verbose
#>

# Export-DAMembers.ps1
# Author: Tao Yang
# Export all members of a SCOM Distributed Application
[CmdletBinding()]
PARAM (
	[Parameter(Mandatory=$true,HelpMessage='Please enter the Management Server name')]
	[Alias('DAS','Server','s')][System.String]$SDK,

	[Parameter(Mandatory=$false,HelpMessage='Please enter the user name to connect to the OpsMgr management group')]
	[Alias('u')][System.String]$Username = $null,

	[Parameter(Mandatory=$false,HelpMessage='Please enter the password to connect to the OpsMgr management group')]
	[Alias('p')][SecureString]$Password = $null,

    [Parameter(ParameterSetName='SearchFullName',Mandatory=$true,HelpMessage='Please enter Distributed Application Full name')]
	[Alias('Name')][System.String]$DAFullName,

	[Parameter(ParameterSetName='SearchDisplayName',Mandatory=$true,HelpMessage='Please enter Distributed Application Display Name')]
	[Alias('DisplayName')][System.String]$DADisplayName,

    [Parameter(Mandatory=$false,HelpMessage='Use Recursive lookup')][System.Boolean]$Recursive=$false,

    [Parameter(Mandatory=$false,HelpMessage='Specify the Monitoring Object properties to be exported')][Alias('Properties')][System.Array]$ExportProperties,

    [Parameter(Mandatory=$true,HelpMessage='Please specify the export file path')]
	[System.String]$Path
)

#region Functions
Function Import-OpsMgrSDK
{
<# 
	.Synopsis
	Load OpsMgr 2012 SDK DLLs

	.Description
	Load OpsMgr 2012 SDK DLLs from either the Global Assembly Cache or from the DLLs located in OpsMgrSDK PS module directory. It will use GAC if the DLLs are already loaded in GAC. If all the DLLs have been loaded, a boolean value $true will be returned, otherwise, a boolean value of $false is returned if any there are any errors occurred.

	.Example
	# Load the OpsMgr SDK DLLs
	Import-SDK

#>
	#OpsMgr 2012 R2 SDK DLLs
	$DLLPath = $ScriptRoot
	$arrDLLs = @()
	$arrDLLs += 'Microsoft.EnterpriseManagement.Core.dll'
	$arrDLLs += 'Microsoft.EnterpriseManagement.OperationsManager.dll'
	$arrDLLs += 'Microsoft.EnterpriseManagement.Runtime.dll'
	$DLLVersion = '7.0.5000.0'
	$PublicKeyToken='31bf3856ad364e35'

	#Load SDKs
	$bSDKLoaded = $true
	Foreach ($DLL in $arrDLLs)
	{
		$AssemblyName = $DLL.TrimEnd('.dll')
		#try load from GAC first
		Try {
			Write-Verbose "Trying to load $AssemblyName from GAC..."
			[Void][System.Reflection.Assembly]::Load("$AssemblyName, Version=$DLLVersion, Culture=neutral, PublicKeyToken=$PublicKeyToken")
		} Catch {
			Write-Verbose "Unable to load $AssemblyName from GAC. Trying PowerShell script root folder..."
			#Can't load from GAC, now try PS module folder
			Try {
				$DLLFilePath = Join-Path $DLLPath $DLL
				[Void][System.Reflection.Assembly]::LoadFrom($DLLFilePath)
			} Catch {
				Write-Verbose "Unable to load $DLL from either GAC or the OpsMgrExtended Powershell Module base folder. Please verify if the SDK DLLs exist in at least one location!"
				$bSDKLoaded = $false
			}
		}
	}
	$bSDKLoaded
}
Function Connect-OMManagementGroup
{
<# 
	.SYNOPSIS
	Connect to OpsMgr Management Group using SDK

	.DESCRIPTION
	Connect to OpsMgr Management Group Data Access Service using SDK

	.PARAMETER -SDK
	Management Server name.

	.PARAMETER -UserName
	Alternative user name to connect to the management group (optional).

	.PARAMETER -Password
	Alternative password to connect to the management group (optional).

	.PARAMETER -DLLPath
	Optionally, specify an alternative path to the OpsMgr SDK DLLs if they have not been installed in GAC.

	.EXAMPLE
	# Connect to OpsMgr management group via management server "OpsMgrMS01"
	Connect-OMManagementGroup -SDK "OpsMgrMS01"

	.EXAMPLE
	# Connect to OpsMgr management group via management server "OpsMgrMS01" using different credential
	$Password = ConvertTo-SecureString -AsPlainText "password1234" -force
	$MG = Connect-OMManagementGroup -SDK "OpsMgrMS01" -Username "domain\SCOM.Admin" -Password $Password

	.EXAMPLE
	# Connect to OpsMgr management group via management server "OpsMgrMS01" using current user's credential
	$MG = Connect-OMManagementGroup -SDK "OpsMgrMS01"
	OR
	$MG = Connect-OMManagementGroup -Server "OPSMGRMS01"
#>
	[CmdletBinding()]
	PARAM (
		[Parameter(Mandatory=$true,HelpMessage='Please enter the Management Server name')][Alias('DAS','Server','s')][String]$SDK,
		[Parameter(Mandatory=$false,HelpMessage='Please enter the user name to connect to the OpsMgr management group')][Alias('u')][String]$Username = $null,
		[Parameter(Mandatory=$false,HelpMessage='Please enter the password to connect to the OpsMgr management group')][Alias('p')][SecureString]$Password = $null
	)
	#Check User name and password parameter
	If ($Username)
	{
		If (!$Password)
		{
			Write-Error "Password for user name $Username must be specified!"
		}
	}

	#Try Loadings SDK DLLs in case they haven't been loaded already
	$bSDKLoaded = Import-OpsMgrSDK

	#Connect to the management group
	if ($bSDKLoaded)
	{
		$MGConnSetting = New-Object Microsoft.EnterpriseManagement.ManagementGroupConnectionSettings($SDK)
		If ($Username -and $Password)
		{
			$MGConnSetting.UserName = $Username
			$MGConnSetting.Password = $Password
		}
		$MG = New-Object Microsoft.EnterpriseManagement.ManagementGroup($MGConnSetting)
	}
	$MG
}

Function Get-OMDAMembers
{
<# 
 .Synopsis
  Get monitoring objects that are members of a Distributed Application in OpsMgr.

 .Description
  Get monitoring objects that are members of a Distributed Application in OpsMgr using OpsMgr SDK. By default, this function only retries objects one level down. Users can use -Recursive parameter to retrieve all objects within the DA hierarchy. 

 .Parameter -SDKConnection
  OpsMgr SDK Connection object (SMA connection or hash table).

 .Parameter -SDK
  Management Server name

 .Parameter -UserName
  Alternative user name to connect to the management group (optional).

 .Parameter -Password
  Alternative password to connect to the management group (optional).

 .Parameter -DAFullName
  Full Name for the Distributed Application.

 .Parameter -DADisplayName
  Alternatively, specify the Distributed Application display name. Please keep in mind the display name is not unique. if there are more than 1 DAs having the same display name, the script will fail.

 .Parameter -Recursive
  Set this parameter to true when retrieving all objects. WARNING: depending on the size of the DA, this could take a very long time.

 .Example
  # Connect to OpsMgr management group via management server "OpsMgrMS01" and then get members of the ConfigMgr DA:
   Management Server: "OpsMgrMS01"
   Username: "domain\SCOM.Admin"
   Password "password1234"
   DA Full Name: "Microsoft.SystemCenter2012.ConfigurationManagement"

  $Password = ConvertTo-SecureString -AsPlainText "password1234" -force
  Get-OMDAMembers -SDK "OpsMgrMS01" -Username "domain\SCOM.Admin" -Password $Password -DAFullName "Microsoft.SystemCenter2012.ConfigurationManagement"

 .Example
   # Connect to OpsMgr management group via management server "OpsMgrMS01" and then get members of the ConfigMgr DA:
   OpsMgrSDK Connection (Used in SMA): "OpsMgrSDK_TYANG"
   DA Display Name: "ConfigMgr"
   Get all members in the hierarchy (recursive lookup)
  
  $SDKConnection = Get-AutomationConnection -Name OpsMgrSDK_TYANG
  Get-OMDAMembers -SDKConnection $SDKConnection -DADisplayName "ConfigMgr" -Recursive $true
#>
    [CmdletBinding()]
    PARAM (
		[Parameter(Mandatory=$false,HelpMessage='Please enter the Management Server name')]
		[Alias('DAS','Server','s')][System.String]$SDK,

		[Parameter(Mandatory=$false,HelpMessage='Please enter the user name to connect to the OpsMgr management group')]
		[Alias('u')][System.String]$Username = $null,

		[Parameter(Mandatory=$false,HelpMessage='Please enter the password to connect to the OpsMgr management group')]
		[Alias('p')][SecureString]$Password = $null,

        [Parameter(ParameterSetName='SearchFullName',Mandatory=$true,HelpMessage='Please enter Distributed Application Full name')]
		[Alias('Name')][System.String]$DAFullName,

		[Parameter(ParameterSetName='SearchDisplayName',Mandatory=$true,HelpMessage='Please enter Distributed Application Display Name')]
		[Alias('DisplayName')][System.String]$DADisplayName,

        [Parameter(Mandatory=$false,HelpMessage='Use Recursive lookup')][System.Boolean]$Recursive=$false
    )
    #Connect to MG
	If ($SDKConnection)
	{
		Write-Verbose "Connecting to Management Group via SDK $($SDKConnection.ComputerName)`..."
		$MG = Connect-OMManagementGroup -SDKConnection $SDKConnection
		$SDK = $SDKConnection.ComputerName
		$Username = $SDKConnection.UserName
		$Password= ConvertTo-SecureString -AsPlainText $SDKConnection.Password -force
	} else {
		Write-Verbose "Connecting to Management Group via SDK $SDK`..."
		If ($Username -and $Password)
		{
			$MG = Connect-OMManagementGroup -SDK $SDK -UserName $Username -Password $Password
		} else {
			$MG = Connect-OMManagementGroup -SDK $SDK
		}
	}

    #Get the DA Monitoring Class
	Write-Verbose "Getting monitoring class for Distributed Applications (`"System.Service`")."
	$strMCQuery = "Name = 'System.Service'"
	$mcCriteria = New-Object Microsoft.EnterpriseManagement.Configuration.MonitoringClassCriteria($strMCQuery)
	$MonitoringClass = $MG.GetMonitoringClasses($mcCriteria)[0]
	If ($DAFullName)
	{
		Write-Verbose "Getting the Distributed Application using full name '$DAFullName'."
		$DACriteria = New-Object Microsoft.EnterpriseManagement.Monitoring.MonitoringObjectGenericCriteria("FullName = '$DAFullName'")
		$DA = $MG.GetMonitoringObjects($DACriteria, $MonitoringClass)[0]
	} elseif ($DADisplayName) {
		Write-Verbose "Getting the Distributed Application using displayn name '$DADisplayName'."
		$DACriteria = New-Object Microsoft.EnterpriseManagement.Monitoring.MonitoringObjectGenericCriteria("DisplayName = '$DADisplayName'")
		$DA = $MG.GetMonitoringObjects($DACriteria, $MonitoringClass)
	}

	If ($DA.Count -gt 1)
	{
		#The Displayname specified is not unique, multiple DA found.
		$DAMembers = $NULL
		Write-Error "Found multiple Distributed Application with display name '$DADisplayName'. Unable to continue."
	} else {
        $DA = $DA[0]
		if ($Recursive)
		{
			Write-Verbose "Getting the members for Distributed Application with TraversalDepth: Recursive."
			$DAmembers = $DA.GetRelatedMonitoringObjects([Microsoft.EnterpriseManagement.Common.TraversalDepth]::Recursive)
		} else {
			Write-Verbose "Getting the members for Distributed Application with TraversalDepth: OneLevel."
			$DAmembers = $DA.GetRelatedMonitoringObjects([Microsoft.EnterpriseManagement.Common.TraversalDepth]::OneLevel)
		}
	}
	#Create an arraylist to store DA members and DA itself.
	$arrMonitoringObjects = New-Object System.Collections.ArrayList
	#Firstly add the DA itself
	[void]$arrMonitoringObjects.Add($DA)
	#Then add each member
	Foreach ($Member in $DAMembers)
	{
		[Void]$arrMonitoringObjects.Add($Member)
	}
	#Return the Arraylist
	$arrMonitoringObjects
}
#endregion

$thisscript = $MyInvocation.MyCommand.path
$ScriptRoot = Split-Path(Resolve-Path $thisscript)

If ($DAFullName)
{
    $DAMembers = Get-OMDAMembers -DAFullName $DAFullName -SDK $SDK -Username $Username -Password $Password -Recursive $Recursive
} elseif ($DADisplayName) {
    $DAMembers = Get-OMDAMembers -DADisplayName $DADisplayName -SDK "OpsMgrMS01" -Username $Username -Password $Password -Recursive $Recursive
}
$iTotal = $DAMembers.count
Write-Verbose "Number of monitoring objects found: $iTotal"
#Export to CSV
If ($iTotal -ge 1)
{
    Write-Verbose "Exporting result to CSV file '$Path'"
    If ($ExportProperties -and $ExportProperties.count -ge 1)
    {
        $strProperties =$ExportProperties -join ", "
        Write-Verbose "Exporting only these properties: $strProperties"
        $DAMembers | Select-Object $ExportProperties | Export-CSV -Path $Path -NoTypeInformation
    } else {
        $DAMembers | Export-CSV -Path $Path -NoTypeInformation
    }
    
} else {
    Write-Error "Found nothing!"
}