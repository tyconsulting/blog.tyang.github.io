Function Import-SMSDK
{
<# 
 .Synopsis
  Load System Center Service Manager 2012 R2 SDK DLLs

 .Description
  Load System Center Service Manager 2012 R2 SDK DLLs from either the Global Assembly Cache or from the DLLs located in SMSDK PS module directory. It will use GAC if the DLLs are already loaded in GAC.

 .Example
  # Load System Center Service Manager 2012 R2 SDK DLLs
  Import-SMSDK

#>
    #SCSM 2012 R2 SDK DLLs
    $DLLPath = (Get-Module SMSDK).ModuleBase
    $arrDLLs = @()
    $arrDLLs += 'Microsoft.EnterpriseManagement.Core.dll'
    $arrDLLs += 'Microsoft.EnterpriseManagement.Packaging.dll'
    $arrDLLs += 'Microsoft.EnterpriseManagement.ServiceManager.dll'
    $AssemblyVersion = '7.0.5000.0'
    $PublicKeyToken='31bf3856ad364e35'

    #Load SDKs
    $bSDKLoaded = $true
    Foreach ($DLL in $arrDLLs)
    {
        $AssemblyName = $DLL.TrimEnd('.dll')
        #try load from GAC first
        Try {
            Write-Verbose "Trying to load $AssemblyName from GAC..."
            [Void][System.Reflection.Assembly]::Load("$AssemblyName, Version=$AssemblyVersion, Culture=neutral, PublicKeyToken=$PublicKeyToken")
        } Catch {
            Write-Verbose "Unable to load $AssemblyName from GAC. Trying PowerShell module base folder..."
            #Can't load from GAC, now try PS module folder
            Try {
                $DLLFilePath = Join-Path $DLLPath $DLL
                [Void][System.Reflection.Assembly]::LoadFrom($DLLFilePath)
            } Catch {
                Write-Verbose "Unable to load $DLL from either GAC or the SMSDK Powershell Module base folder. Please verify if the SDK DLLs exist in at least one location!"
                $bSDKLoaded = $false
            }
        }
    }
    $bSDKLoaded
}

Function Connect-SMManagementGroup
{
<# 
 .Synopsis
  Connect to SCSM Management Group using SDK

 .Description
  Connect to SCSM Management Group Data Access Service using SDK

 .Parameter -SDK
  Management Server name.

 .Parameter -UserName
  Alternative user name to connect to the management group (optional).

 .Parameter -Password
  Alternative password to connect to the management group (optional).

 .Example
  # Connect to OpsMgr management group via management server "SCSMMS01" using different credential
  $Password = ConvertTo-SecureString -AsPlainText "password1234" -force
  $MG = Connect-OMManagementGroup -SDK "SCSMMS01" -Username "domain\SCSM.Admin" -Password $Password

 .Example
  # Connect to OpsMgr management group via management server "SCSMMS01" using current user's credential
  $MG = Connect-OMManagementGroup -SDK "SCSMMS01"
  OR
  $MG = Connect-OMManagementGroup -Server "SCSMMS01"
#>
    [CmdletBinding()]
    PARAM (
		[Parameter(Mandatory=$true,HelpMessage='Please enter the Management Server name')][Alias('Server','s')][String]$SDK,
        [Parameter(Mandatory=$false,HelpMessage='Please enter the user name to connect to the Service manager management group')][Alias('u')][String]$Username = $null,
        [Parameter(Mandatory=$false,HelpMessage='Please enter the password to connect to the Service manager management group')][Alias('p')][SecureString]$Password = $null
    )

    #Check User name and password parameter
    If ($Username)
    {
        If (!$Password)
        {
            Write-Error "Password for user name $Username must be specified!"
        }
    }

    #Try Loadings SDK DLLs in case they haven't been loaded already
    $bSDKLoaded = Import-SMSDK

    #Connect to the management group
    if ($bSDKLoaded)
    {
        $MGConnSetting = New-Object Microsoft.EnterpriseManagement.EnterpriseManagementConnectionSettings($SDK)
        If ($Username -and $Password)
        {
            $MGConnSetting.UserName = $Username
            $MGConnSetting.Password = $Password
        }
        $MG = New-Object Microsoft.EnterpriseManagement.EnterpriseManagementGroup($MGConnSetting)
    }
    $MG
}