﻿#========================================================================================================
# AUTHOR:		Tao Yang 
# DATE:			27/07/2010
# Version:		1.0
# COMMENT:		A function to check Powershell execution policy on aremote machine
# Usage:		Get-RemoteExecutionPolicy <machine name>
#========================================================================================================

function Get-RemoteExecutionPolicy ($MachineName)
{
$regKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $MachineName)
$PSRegKey= $regKey.OpenSubKey("SOFTWARE\\Microsoft\\Powershell\\1\\ShellIds\\Microsoft.PowerShell")
$strPolicy = ($PSRegKey.getvalue("ExecutionPolicy")).tostring()

Return $strPolicy
}