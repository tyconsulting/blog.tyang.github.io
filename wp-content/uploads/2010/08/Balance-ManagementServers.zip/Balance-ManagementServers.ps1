﻿#=========================================================================================================================
# AUTHOR:	Tao Yang 
# DATE:		10/08/2010
# Name:		Balance-ManagementServers.ps1
# Version:	1.0
# COMMENT:	Balancing SCOM management servers so they have similar number of agents
#=========================================================================================================================
$erroractionpreference = "SilentlyContinue"

##Initiate SCOM PSSnapin
#Get the FQDN of the local computer (where the script is run)...
#Since this script is running on RMS server, the RMS server FQDN can be retrieved from WMI

$objCompSys = Get-WmiObject win32_computersystem
$RMS = $objCompSys.name+"."+$objCompSys.domain

Write-Host "Connecting to RMS $RMS" -ForegroundColor Yellow
#adding SCOM PSSnapin
if ((Get-PSSnapin | where-Object { $_.Name -eq 'Microsoft.EnterpriseManagement.OperationsManager.Client' }) -eq $null) 
{
	Add-PSSnapin Microsoft.EnterpriseManagement.OperationsManager.Client -ErrorAction SilentlyContinue -ErrorVariable Err
}
if ((Get-PSDrive | where-Object { $_.Name -eq 'Monitoring' }) -eq $null)
{
	New-PSDrive -Name:Monitoring -PSProvider:OperationsManagerMonitoring -Root:\ -ErrorAction SilentlyContinue -ErrorVariable Err | Out-Null
}

#Connect to RMS
Set-Location "OperationsManagerMonitoring::"
new-managementGroupConnection -ConnectionString:$RMS | Out-Null
Set-Location Monitoring:\$RMS

#specify management servers
$Global:arrManagementServers = New-Object System.Collections.ArrayList
$Global:arrManagementServers.add((Get-ManagementServer | Where-Object {$_.Name -imatch "<FQDN Management Server #1>"}))
$Global:arrManagementServers.add((Get-ManagementServer | Where-Object {$_.Name -imatch "<FQDN Management Server #2>"}))
#Keep adding more management servers by repeating the previous line.

Function Get-FailoverMS ($PrimaryMS)
{
	$arrFailOverMSs = $Global:arrManagementServers
	$arrFailOverMSs.Remove($TargetMS)
	Return $arrFailOverMSs
}

Write-Host "Retrieving SCOM Agents from affected management servers..." -ForegroundColor Yellow
$arrAgents = @()
Foreach ($MS in $Global:arrManagementServers) { 
	$arrAgents += $MS | Get-Agent
}
$iTotalAgents = $arrAgents.count
Write-Host "Totally $iTotalAgents found!" -ForegroundColor Yellow

$AveragePerMS = [System.Math]::Round($arrAgents.count / $Global:arrManagementServers.count)
Write-Host "In average, approx. $AveragePerMS agents should be assigned to each Management server" -ForegroundColor Yellow

$arrMSLowerThanAverage = New-Object System.Collections.ArrayList
$arrMSHigherThanAverage = New-Object System.Collections.ArrayList
Foreach ($MS in $Global:arrManagementServers) {
	$AgentCount = ($MS | Get-Agent).count
	if ($AgentCount -lt ($AveragePerMS -1)) {
		$arrMSLowerThanAverage.add($MS)
	} elseif ($AgentCount -gt ($AveragePerMS +1)) {
		$arrMSHigherThanAverage.add($MS)
	}
}

Foreach ($MS in $arrMSHigherThanAverage)
{
	$iDifference = ($MS | Get-Agent).count - ($AveragePerMS +1)
	$arrTemp = @()
	$arrTemp +=$MS | Get-Agent
	For ($i=0; $i -lt $iDifference; $i++)
	{	
		$TargetMS = Get-Random -InputObject $arrMSLowerThanAverage
		$arrFailOverMSs = Get-failoverMS $TargetMS
		$strAgentName = $arrTemp[$i].Name
		$strTargetMS = $TargetMS.Name
		$strFailOverMS = $null
		Foreach ($MS in $arrFailOverMSs)
		{ $strFailOverMS = $strFailOverMS + $MS.name + '; '}
		Write-Host "Setting $strAgentName to Primary Managment Server $strTargetMS and Failover server(s) to $strFailOverMS..." -ForegroundColor Yellow
		Set-ManagementServer -AgentManagedComputer $arrTemp[$i] -PrimaryManagementServer $TargetMS -FailoverServer $arrFailOverMSs | Out-Null
		if (!(($TargetMS | Get-Agent).count -lt ($AveragePerMS -1))) {$arrMSLowerThanAverage.Remove($TargetMS)}
		Remove-Variable arrFailOverMSs
	}
	For ($i = $iDifference; $i -le ($arrTemp.count -1); $i ++)
	{
		$arrFailOverMSs = Get-failoverMS $MS
		$strAgentName = $arrTemp[$i].Name
		$strTargetMS = $TargetMS.Name
		$strFailOverMS = $null
		Foreach ($MS in $arrFailOverMSs)
		{ $strFailOverMS = $strFailOverMS + $MS.name + '; '}
		Write-Host "Setting Failover servers for $strAgentName to $strFailOverMS..." -ForegroundColor Yellow
		Set-ManagementServer -AgentManagedComputer $arrTemp[$i] -PrimaryManagementServer $MS -FailoverServer $arrFailOverMSs | Out-Null
	}
	Remove-Variable arrTemp
}

Write-Host "Done!" -ForegroundColor Green
