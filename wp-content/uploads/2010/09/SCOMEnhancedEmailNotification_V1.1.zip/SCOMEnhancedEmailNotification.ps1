#=====================================================================================================
# AUTHOR:	Tao Yang 
# DATE:		30/09/2010
# Name:		SCOMEnhancedEmailNotification.PS1
# Version:	1.1
# COMMENT:	SCOM Enhanced Email notification which includes detailed alert information
# Update:	30/09/2010	- Removed GetNetbiosName function
#						- Reformatted HTML email body
#						- Added error handling for $rule.GetKnowledgeArticle() as sometimes there is no knowledge article.
# Usage:	.\SCOMEnhancedEmailNotification.ps1 -alertID xxxxx -Recipients @('John Smith;john.smith@xxx.com','Bill Gates;billgates@xxxx.com','Osama Bin Laden;Osama.BinLaden@whitehouse.gov')
#=====================================================================================================

#In OpsMgr R1, the parameter passed in is "'$Data/Context/DataItem/AlertId$'" (single quote inside double quote)
#In OpsMgr R2, the parameter passed in is "$Data/Context/DataItem/AlertId$" (double quote)
#Quotation marks are required otherwise it would not treat it as a string.
param([string]$alertID,[string[]]$Recipients)
$error.clear()
$erroractionpreference = "SilentlyContinue"
$thisScript = $myInvocation.MyCommand.Path
$scriptRoot = Split-Path(Resolve-Path $thisScript)
$errorLogFile = Join-Path $scriptRoot "error.log"
if (Test-Path $errorLogFile) {Remove-Item $errorLogFile -Force}

##Below variables need to be set according to your SCOM environment
#Resolution State value for "Notified" - This needs to be manually created in SCOM console
$NotifiedResState = "85"
##any other resolution state created in SCOM need to be added to this function
function getResStateName($resStateNumber)
{
	switch($resStateNumber)
	{
		"0" { $resStateName = "New" }
		"85" { $resStateName = "Notified" }
		"255" { $resStateName = "Closed" }
	}
	$resStateName
}
#SMTP server Address
$strSMTP = "SMTPServer.yourcomapny.com"

#SMTP Port
$iPort = 25

#SMTP Sender (return address)
$Sender = New-Object System.Net.Mail.MailAddress("OpsMgr@yourcomapny.com", "OpsMgr Notification")

#If error occured while excuting the script, the recipient for error notification email.
$ErrRecipient = New-Object System.Net.Mail.MailAddress("SCOM.Administrator@yourcomapny.com", "Your Name")
######################

$alertID = $alertID.toString()

#remove "{" and "}" around the $alertID if exist
if ($alertID.substring(0,1) -match "{")
{
	$alertID = $alertID.substring(1, ( $alertID.length -1 ))
}
if ($alertID.substring(($alertID.length -1), 1) -match "}")
{
	$alertID = $alertID.substring(0, ( $alertID.length -1 ))
}

#Set Culture Info
$cultureInfo = [System.Globalization.CultureInfo]'en-US'

#function GetNetBiosName($MonitoringObjDisplayName, $PrincipalName)
#{
#	$MonitoringObjDisplayName = $MonitoringObjDisplayName.tostring()
#	$PrincipalName = $PrincipalName.tostring()
#	$arrInvalidChars = @("/","\","[","]",'"',":",";","|","<",">","+","=",",","?","*"," ","_")
#	$arrAgents = @()
#	$arrAgents +=(Get-agent | select-object principalName)
#	$arrAgents +=(Get-managementserver | Select-Object principalName)
#	
#	Foreach ($char in $arrInvalidChars)
#	{
#		if ($MonitoringObjDisplayName.contains($char))
#		{
#			$MonitoringObjDisplayName = $MonitoringObjDisplayName.replace($char,".")
#		}
#		
#		if ($PrincipalName.contains($char))
#		{
#			$PrincipalName = $PrincipalName.replace($char,".")
#		}
#	}
#	
#	if ($MonitoringObjDisplayName.contains("."))
#	{
#		$MonitoringObjDisplayName = ($MonitoringObjDisplayName.split("."))[0]
#	}
#	
#	if ($PrincipalName.contains("."))
#	{
#		$PrincipalName = ($PrincipalName.split("."))[0]
#	}
#	
#	$NetBiosName = $null
#	if ($arrAgents | Where-Object {$_.PrincipalName -imatch $MonitoringObjDisplayName})
#	{
#		$NetBiosName = $MonitoringObjDisplayName
#	} elseif ($arrAgents | Where-Object {$_.PrincipalName -imatch $PrincipalName})
#	{
#		$NetBiosName = $PrincipalName
#	}
#
#	Return $NetBiosName
#}


function fnMamlToHTML($MAMLText)
{
	$HTMLText = "";
	$HTMLText = $MAMLText -replace ('xmlns:maml="http://schemas.microsoft.com/maml/2004/10"');
	$HTMLText = $HTMLText -replace ("maml:para", "p");
	$HTMLText = $HTMLText -replace ("maml:");
	$HTMLText = $HTMLText -replace ("</section>");
	$HTMLText = $HTMLText -replace ("<section>");
	$HTMLText = $HTMLText -replace ("<section >");
	$HTMLText = $HTMLText -replace ("<title>", "<h3>");
	$HTMLText = $HTMLText -replace ("</title>", "</h3>");
	$HTMLText = $HTMLText -replace ("<listitem>", "<li>");
	$HTMLText = $HTMLText -replace ("</listitem>", "</li>");
	$HTMLText;
}

function fnTrimHTML($HTMLText)
{
	$TrimedText = "";
	$TrimedText = $HTMLText -replace ("&lt;", "<")
	$TrimedText = $TrimedText -replace ("&gt;", ">")
	$TrimedText = $TrimedText -replace ("<html>")
	$TrimedText = $TrimedText -replace ("<HTML>")
	$TrimedText = $TrimedText -replace ("</html>")
	$TrimedText = $TrimedText -replace ("</HTML>")
	$TrimedText = $TrimedText -replace ("<body>")
	$TrimedText = $TrimedText -replace ("<BODY>")
	$TrimedText = $TrimedText -replace ("</body>")
	$TrimedText = $TrimedText -replace ("</BODY>")
	$TrimedText = $TrimedText -replace ("<h1>", "<h3>")
	$TrimedText = $TrimedText -replace ("</h1>", "</h3>")
	$TrimedText = $TrimedText -replace ("<h2>", "<h3>")
	$TrimedText = $TrimedText -replace ("</h2>", "</h3>")
	$TrimedText = $TrimedText -replace ("<H1>", "<h3>")
	$TrimedText = $TrimedText -replace ("</H1>", "</h3>")
	$TrimedText = $TrimedText -replace ("<H2>", "<h3>")
	$TrimedText = $TrimedText -replace ("</H2>", "</h3>")
	$TrimedText;
}

##Initiate SCOM PSSnapin
#Get the FQDN of the local computer (where the script is run)...
#Since this script is running on RMS server, the RMS server FQDN can be retrieved from WMI
$objCompSys = Get-WmiObject win32_computersystem
$RMS = $objCompSys.name+"."+$objCompSys.domain

#adding SCOM PSSnapin
if ((Get-PSSnapin | where-Object { $_.Name -eq 'Microsoft.EnterpriseManagement.OperationsManager.Client' }) -eq $null) 
{
	Add-PSSnapin Microsoft.EnterpriseManagement.OperationsManager.Client -ErrorAction SilentlyContinue -ErrorVariable Err
}
if ((Get-PSDrive | where-Object { $_.Name -eq 'Monitoring' }) -eq $null)
{
	New-PSDrive -Name:Monitoring -PSProvider:OperationsManagerMonitoring -Root:\ -ErrorAction SilentlyContinue -ErrorVariable Err | Out-Null
}

#Connect to RMS
Set-Location "OperationsManagerMonitoring::"
new-managementGroupConnection -ConnectionString:$RMS | Out-Null
Set-Location Monitoring:\$RMS

#Get Web Console URL
$arrDefaultSettings = Get-DefaultSetting
Foreach ($setting in $arrDefaultSettings)
{
	if ($setting.name -eq "NotificationServer\WebAddresses\WebConsole")
	{
		$WebConsoleBaseURL = $setting.value
	}
}

##Get recipients names and email addresses from input array
$arrRecipients = @()
Foreach ($Recipient in $Recipients)
{
	$objRecipient = New-Object psobject
	$strRecipientName = ($Recipient.split(";"))[0]
	$strEmail = ($Recipient.split(";"))[1]
	Add-Member -InputObject $objRecipient -MemberType NoteProperty -Name Name -Value $strRecipientName
	Add-Member -InputObject $objRecipient -MemberType NoteProperty -Name Email -Value $strEmail
	$arrRecipients += $objRecipient
	Remove-Variable objRecipient
}

##locate the specific alert
$alert = Get-Alert -Id $alertID

$strResolutionState = ($alert.resolutionstate).ToString()
if ($strResolutionState -eq "255")
{ exit }
$localtimeRaised = ($alert.timeraised).tolocaltime()
$severity = $alert.Severity.ToString()
$severitycolor="3300CC"	#Blue
if ($severity.ToLower() -eq "error")
	{
		$severity = "Critical"
		$severitycolor = "FF0000"	#Red
	} elseif ($severity.ToLower() -eq "warning")
	{
		$severitycolor = "FFF00"	#Yellow
	}
$monitoringObjectId = $alert.monitoringobjectID.tostring()
$pathName = $alert.MonitoringObjectPath
$ruleID = $alert.MonitoringRuleId.Tostring()
$problemID = $alert.ProblemId
$bIsMonitorAlert = $alert.IsMonitorAlert

$strTimeRaised = $localtimeraised.ToString()
#Write-Host "Alert $alertID processed."

##locate the alert associated rule
$articleContent = $null
if (!$error)	#no point retrieving the monitoring rule when there's error processing the alert
{
	#if failed to get knowledge article, remove the error from $error because not every rule and monitor will have knowledge articles.
	if ($bIsMonitorAlert -eq $false)
	{
		$rule = Get-Rule -Id $ruleID
		$article = $rule.GetKnowledgeArticle($cultureInfo)
		if ($? -eq $false)
		{
			$error.Remove($Error[0])
			$article = "None"
		}	
		
		$RuleName = $rule.DisplayName
		$RuleDescription = $rule.Description
		if ($RuleDescription.Length -lt 1) {$RuleDescription = "None"}
	}
	elseif ($bIsMonitorAlert -eq $true)
	{
		$monitor = Get-Monitor -Id $ruleID
		$article = $monitor.GetKnowledgeArticle($cultureInfo)
		if ($? -eq $false)
		{
			$Error.Remove($Error[0])
			$article = "None"
		}
		$MonitorName = $monitor.DisplayName
		$MonitorDescription = $monitor.Description
		if ($MonitorDescription.Length -lt 1) {$MonitorDescription = "None"}
	}
	
	if ($article -ne "None")	#some rules don't have any knowledge articles
	{
		#Retrieve and format article content
		$MamlText = $null
		$HtmlText = $null
			
		if ($article.MamlContent -ne $null)
		{
			$MamlText = $article.MamlContent
			$articleContent = fnMamlToHtml($MamlText)
		}
			
		if ($article.HtmlContent -ne $null)
		{
			$HtmlText = $article.HtmlContent
			$articleContent = fnTrimHTML($HtmlText)
		}
	}
		
}
if ($articleContent -eq $null)
{
	$articleContent = "No resolutions were found for this alert."
}

##retrieve NetBios computer name
#if ($alert.NetBiosComputername -eq $null)
#{
#	#if NetBiosComputername is null in alert, call getNetBiosName function from function lib to retrieve it.
#	$strAgentName = GetNetBiosName $alert.MonitoringObjectDisplayName $alert.PrincipalName
#}
#else
#{
#	$strAgentName = $alert.NetBiosComputername
#}

$AlertSource = $alert.MonitoringObjectDisplayName
$alertPrincipalName=$alert.principalName
$strAlertName = $alert.Name
$strSubject = "SCOM $severity Alert on $strAgentName : $strAlertName"
$strErrSubject = "Error emailing SCOM Notification for Alert ID $alertID"
$webConsoleURL = $WebConsoleBaseURL+"?DisplayMode=Pivot&AlertID=%7b$AlertID%7d"
$strDesc = $alert.Description
$strResStateName = getResStateName($strResolutionState)
$psCmd = $psCmd = "get-alert -Id `"$alertID`" | format-list *"

$strNote = "**Note: The severity of this alert is <b>$severity</b>.**"


$strBody = @"
<html>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<body>
<p><b>Severity:<Font color='$SeverityColor'> $severity</Font></b>
<p><b>Source:</b> $AlertSource
<p><b>Path:</b> $pathName
<p><b>Principal Name:</b> $alertPrincipalName
<p>
<p><b>Alert Name:</b> $strAlertName
<p><b>Alert Resolution State:</b> $strResStateName
<p><h3>Alert Description:</h3>
<p>$StrDesc
"@
if ($bIsMonitorAlert -eq $true) {
$strBody = $strBody + @"
<p><h3>Alert Monitor Name:</h3> $MonitorName
<p><h3>Alert Monitor Description:</h3> $MonitorDescription

"@
}elseif ($bIsMonitorAlert -eq $false) {
$strBody = $strBody + @"
<p><h3>Alert Rule Name:</h3> $RuleName
<p><h3>Alert Rule Description:</h3> $RuleDescription

"@
}
$strBody = $strBody + @"
<p><b>Time Raised:</b> $strTimeRaised
<p>
<p><b>Alert ID:</b> $alertID
<p>
<p>**Use below command to view the full details of this alert in SCOM Powershell console:
<p>$psCmd
<p>
<p><h3>SCOM Link:</h3>
<p><a href = $webConsoleURL>$webConsoleURL</a>
<p>
<p><h3>Knowledge Article:</h3>
<hr>
<p> $articleContent
<hr>
<p>
</body></html>
"@

$strErrBody = @"
<html><body>
<p>Error occurred when excuting $thisScript located at $RMS for alert ID $alertID.
<p>
<p>Alert Resolution State: $strResStateName
<p>**Note:Error will occur if the script tries to process an alert with Resolution State other than <b>New</b>.
<p>
<p>$error
<p>
<p><b>**Use below command to view the full details of this alert in SCOM Powershell console:</b>
<p>$psCmd
<p>
<p> SCOM link:<a href = $webConsoleURL > $webConsoleURL </a>
</body></html> 

"@

$MailMessage = New-Object System.Net.Mail.MailMessage
$MailMessage.IsBodyHtml = $true
$SMTPClient = New-Object System.Net.Mail.smtpClient
$SMTPClient.host =  $strSMTP
$SMTPClient.port = $iPort


$MailMessage.Sender = $Sender
$MailMessage.From = $Sender
if ($error.count -eq "0")
{
	$MailMessage.Subject = $strSubject
	Foreach ($item in $arrRecipients)
	{
		$to = New-Object System.Net.Mail.MailAddress($item.email, $item.name)
		$MailMessage.To.add($to)
		Remove-Variable to
	}
	$MailMessage.Body = $strBody
}
else
{
	$MailMessage.Subject = $strErrSubject
	$MailMessage.To.add($ErrRecipient)
	$MailMessage.Body = $strErrBody
}
$SMTPClient.Send($MailMessage)

Write-Host $error
##Make sure the script is closed
if ($error.count -eq "0")
{
	if ($alert.ResolutionState -eq "0")
	{ 
		$alert.ResolutionState = $NotifiedResState
		$alert.Update("")
	}
	#$host.setShouldExit(0)
}
else
{
	$Error | Out-File $errorLogFile
	#$error.clear()
	#$host.setShouldExit(1)
}