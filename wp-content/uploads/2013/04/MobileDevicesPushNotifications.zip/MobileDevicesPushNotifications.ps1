Param($os,$apikey,$alertname,$alertsource,$alertseverity,$alertTimeRaised,$alertdescription) 

# Enter the name of the application the notification originates from. 
$application = "OM2012"

# Enter The event that occured. Depending on your application, this might be a summary, subject or a brief explanation.
$event = "OM2012 Alert"

Switch ($alertseverity)
{
	"2" {$strSeverity = "Critical"}
	"1" {$strSeverity = "Warning"}
	"0" {$strSeverity = "Information"}
}

# The full body of the notification. 
$description = @"
AlertName: $alertname
Source: $alertsource
Severity: $strSeverity
TimeRaised: $alertTimeRaised
Description: $alertDescription
"@

#description maximum length is 10000, truncate it if it's over
If ($description.length -gt 10000)
{
	$description = $description.substring(0,10000)
}
#You can enable the write-eventlog for logging purposes.
#write-eventlog -LogName Application -source MSIInstaller -EventId 999 -entrytype Information -Message $description

# An optional value representing the priority of the notification.
$priority = "-2"

# Specifies the responsetype you want. You can currently choose between JSON or XML (default)
$type = "json"
$os = $os.tolower()
Switch ($os)
{
	"android" {$uri = "http://notifymyandroid.com/publicapi/notify?event=$event&priority=$priority&application=$application&description=$description&apikey=$apikey&type=$type"}
	"windows" {$uri = "http://notifymywindowsphone.com/publicapi/notify?event=$event&priority=$priority&application=$application&description=$description&apikey=$apikey&type=$type"}
	"ios" {$uri = "http://api.prowlapp.com/publicapi/add?event=$event&priority=$priority&application=$application&description=$description&apikey=$apikey&type=$type"}
}

#Invoke-WebRequest -Uri $uri
$response = [System.Net.WebRequest]::Create($uri)
$response.GetResponse()