#====================================================================
# AUTHOR:		Tao Yang
# Script Name:	CheckAllConnectorServicesStatus.ps1
# DATE:			28/05/2014
# Version:		1.0
# Comment:		Check status for all Alert Update Connector services
#====================================================================

#region functionlib
Function Load-SDK()
{
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.EnterpriseManagement.OperationsManager.Common") | Out-Null 
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.EnterpriseManagement.OperationsManager") | Out-Null 
}

Function Get-AUCService($strComputer)
{
	$TheService = Get-WmiObject  -ComputerName  $strComputer -Query "Select * From Win32_Service Where Name = 'Alert Update Connector'"
	$TheService
}
#endregion

#MOMScript API
$oAPI = New-Object -ComObject "MOM.ScriptAPI"

#Property Bag
$oBag = $oAPI.CreatePropertyBag()

#Connect to MG
Load-SDK
$MGConnSetting = New-Object Microsoft.EnterpriseManagement.ManagementGroupConnectionSettings($env:COMPUTERNAME)
$MG = New-Object Microsoft.EnterpriseManagement.ManagementGroup($MGConnSetting)

$strClassSearchCriteria = "Name='AlertUpdateConnector.Connector'"
$ClassSearchCriteria = New-Object  Microsoft.EnterpriseManagement.Configuration.MonitoringClassCriteria($strClassSearchCriteria)
$ColConnectorClass = $MG.GetMonitoringClasses($ClassSearchCriteria)
If ($ColConnectorClass.Count -gt 1)
{
	#Multiple classes found with the same name 'AlertUpdateConnector.Connector'
	$oAPI.LogScriptEvent("CheckAllConnectorServicesStatus.ps1", 8000, 1, "Multiple classes found with the same name 'AlertUpdateConnector.Connector'")
	Exit 1
} else {
	$ConnectorClass = $ColConnectorClass[0]
}

#Get Alert Update Connector Instance
$ColConnectorInstances = $MG.GetMonitoringObjects($ConnectorClass)
If ($ColConnectorInstances.Count -gt 1)
{
	#Multiple Alert Update Connector instances found.
	$oAPI.LogScriptEvent("CheckAllConnectorServicesStatus.ps1", 8000, 1, "Multiple Alert Update Connector instances found. There should only be one (1) instance.")
	Exit 2
} else {
	$objConnector = $ColConnectorInstances[0]
}

#Get all Alert Update Connector Services
$colAUCServices = $objConnector.GetRelatedMonitoringObjects() | Where-Object {$_.Name -ieq "Alert Update Connector"}
$AUCServicesCount = $colAUCServices.Count

#Only 1 instance of Alert Update Connector service should be running
$iDesiredDisabledCount = $AUCServicesCount - 1

#Identify number of running and disabled AUC services
$iRunningCount = 0
$iActualDisabledCount = 0

Foreach ($AUCService in $colAUCServices)
{
	$HostingComputer = $AUCService.Path
	$AUCService = Get-AUCService $HostingComputer
	If ($AUCService.Started)
	{
		$iRunningCount++
	}

	IF ($AUCService.StartMode -ieq "Disabled")
	{
		$iActualDisabledCount++
	}
}

$oBag.AddValue("AUCServicesCount", $AUCServicesCount)
$oBag.AddValue("RunningCount", $iRunningCount)
$oBag.AddValue("ActualDisabledCount", $iActualDisabledCount)
$oBag.AddValue("DesiredDisabledCount", $iDesiredDisabledCount)
#$oAPI.Return($oBag)
$oBag