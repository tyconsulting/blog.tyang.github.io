#==========================================================================
# AUTHOR:		Tao Yang
# Script Name:	StartOneAUCServiceRecovery.ps1
# DATE:			28/05/2014
# Version:		1.0
# Comment:		Recovery task for AUCServices.Monitor - Start One Instance
#==========================================================================
Param([int]$RunningCount)
#region functionlib
Function Load-SDK()
{
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.EnterpriseManagement.OperationsManager.Common") | Out-Null 
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.EnterpriseManagement.OperationsManager") | Out-Null 
}

Function Get-AUCService($strComputer)
{
	$TheService = Get-WmiObject  -ComputerName  $strComputer -Query "Select * From Win32_Service Where Name = 'Alert Update Connector'"
	$TheService
}

Function Ping-Check($computer, $iPingRetryWait, $iPingRetryTimes)
{
	$bPing = $false
	$ping = New-Object Net.NetworkInformation.Ping
    #ping with timeout setting of 1 second
	$PingResult = $ping.send($computer, 1000)
	if ($PingResult.Status.Tostring().ToLower() -eq "success")
	{
		$bPing = $true
	} else {
		#if first attemp failed, wait for number of seconds that's defined in XML file and try again
		Start-Sleep $iPingRetryWait
		#attemp to ping few more times (defined in XML file)
		For ($i=1; $i -le $iPingRetryTimes; $i++)
		{
			$PingResult = $ping.send($computer)
			if ($PingResult.Status.Tostring().ToLower() -eq "success")
			{
				$bPing = $true
			}
		}
		
	}
	return $bPing
}
#endregion

Write-Host "Current Running instances: $RunningCount"

#Connect to MG
Load-SDK
Write-Host "Connecting to management group and retrieve all instances of Alert Update Connector services."
$MGConnSetting = New-Object Microsoft.EnterpriseManagement.ManagementGroupConnectionSettings($env:COMPUTERNAME)
$MG = New-Object Microsoft.EnterpriseManagement.ManagementGroup($MGConnSetting)

$strClassSearchCriteria = "Name='AlertUpdateConnector.Connector'"
$ClassSearchCriteria = New-Object  Microsoft.EnterpriseManagement.Configuration.MonitoringClassCriteria($strClassSearchCriteria)
$ColConnectorClass = $MG.GetMonitoringClasses($ClassSearchCriteria)
If ($ColConnectorClass.Count -gt 1)
{
	#Multiple classes found with the same name 'AlertUpdateConnector.Connector'
	Write-Error  "Multiple classes found with the same name 'AlertUpdateConnector.Connector'"
	Exit 1
} else {
	$ConnectorClass = $ColConnectorClass[0]
}

#Get Alert Update Connector Instance
$ColConnectorInstances = $MG.GetMonitoringObjects($ConnectorClass)
If ($ColConnectorInstances.Count -gt 1)
{
	#Multiple Alert Update Connector instances found.
	Write-Error "Multiple Alert Update Connector instances found. There should only be one (1) instance."
	Exit 2
} else {
	$objConnector = $ColConnectorInstances[0]
}

#Get all Alert Update Connector Services
$colAUCServices = $objConnector.GetRelatedMonitoringObjects() | Where-Object {$_.Name -ieq "Alert Update Connector"}
$AUCServicesCount = $colAUCServices.Count
Write-Host "$AUCServicesCount instance(s) of Alert Update Connector Service(s) detected."
$arrAll = New-Object System.Collections.ArrayList
$arrDisbled = New-Object System.Collections.ArrayList
$arrAuto = New-Object System.Collections.ArrayList
$arrManual = New-Object System.Collections.ArrayList

Foreach ($AUCService in $colAUCServices)
{
	$HostingComputer = $AUCService.Path
	#Make sure it's pingable
	Write-Host "Tring to ping $HostingComputer`..."
	If (Ping-Check $HostingComputer 1 2)
	{
		$AUCService = Get-AUCService $HostingComputer
		IF ($AUCService.StartMode -ieq "Disabled")
		{
			[void]$arrAll.Add($AUCService)
			[void]$arrDisbled.Add($AUCService)
			Write-Host "The start mode of the Alert Update Connector Service on $HostingComputer is set to Disabled."
		} elseif ($AUCService.StartMode -ieq "Auto")
		{
			[void]$arrAll.Add($AUCService)
			[void]$arrAuto.Add($AUCService)
			Write-Host "The start mode of the Alert Update Connector Service on $HostingComputer is set to Automatic."
		} elseif ($AUCService.StartMode -ieq "Manual")
		{
			[void]$arrAll.Add($AUCService)
			[void]$arrManual.Add($AUCService)
			Write-Host "The start mode of the Alert Update Connector Service on $HostingComputer is set to Manual."
		}
	} else {
		Write-Host "$HostingComputer is offline."
	}
	Write-Host ""
}

#try starting 1 instance
$bStarted = $false

#try the automatic ones first
Foreach ($item in $arrAuto)
{
	if (!$bStarted)
	{
		Try
		{
			Write-Host "Trying to start Alert Update Connector Service on $($item.SystemName)."
			$startService = $item.StartService()
			$startService
			if ($startService.ReturnValue -eq 0)
			{
				$bStarted = $true
				$RunningHost = $item.SystemName
				Write-Host "Alert Update Service started on $RunningHost."
			}
		} Catch {
			$bStarted = $false
		}
	}
}

#then try the manual ones
Foreach ($item in $arrManual)
{
	if (!$bStarted)
	{
		Try
		{			
			$startService = $item.StartService()
			if ($startService.ReturnValue -eq 0)
			{
				$bStarted = $true
				$RunningHost = $item.SystemName
				Write-Host "Alert Update Service started on $RunningHost."
				Write-Host "Changing Start mode of the Alert Update Service on $($item.SystemName) to Automatic."
				$SetService = $item.ChangeStartMode("Automatic")
				if ($SetService.ReturnValue -eq 0)
				{
					Write-Host "The Start mode of the Alert Update Service on $($item.SystemName) has benn changed from Manual to Automatic."
				}
			}
		} Catch {
			$bStarted = $false
		}
	}
}

#Lastly try disabled
Foreach ($item in $arrDisbled )
{
	if (!$bStarted)
	{
		Try
		{			
			#Enabling the service
			$SetService = $item.ChangeStartMode("Automatic")
			if ($SetService.ReturnValue -eq 0)
			{
				Write-Host "The Start mode of the Alert Update Service on $($item.SystemName) has benn changed from Disabled to Automatic."
				#Start the service once been enabled
				$startService = $item.StartService()
				if ($startService.ReturnValue -eq 0)
				{
					$bStarted = $true
					$RunningHost = $item.SystemName
					Write-Host "Alert Update Service started on $RunningHost."
				}
			}

		} Catch {
			$bStarted = $false
		}
	}
}


If ($bStarted)
{
	Write-Host "Alert Update Service Started on $RunningHost`, disabling other instances..."
	Foreach ($item in $arrAll)
	{
		if ($item.SystemName -ne $RunningHost -and $item.StartMode -ne "Disabled")
		{
			Write-Host "Disabling Alert Update Connector Service on $($item.SystemName)."
			$SetService = $item.ChangeStartMode("Disabled")
			if ($SetService.ReturnValue -eq 0)
			{
				Write-Host "The Alert Update Service on $($item.SystemName) has benn disabled."
			}
		} 
	}
}
Write-Host "Done"