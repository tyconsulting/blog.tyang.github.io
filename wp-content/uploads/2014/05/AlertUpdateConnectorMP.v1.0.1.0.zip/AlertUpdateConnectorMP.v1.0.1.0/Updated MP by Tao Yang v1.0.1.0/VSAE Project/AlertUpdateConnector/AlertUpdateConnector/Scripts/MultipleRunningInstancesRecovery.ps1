#==================================================================================
# AUTHOR:		Tao Yang
# Script Name:	MultipleRunningInstancesRecovery.ps1
# DATE:			29/05/2014
# Version:		1.0
# Comment:		Recovery task for AUCServices.Monitor - Multiple Instances Running
#==================================================================================
Param([int]$RunningCount)
#region functionlib
Function Load-SDK()
{
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.EnterpriseManagement.OperationsManager.Common") | Out-Null 
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.EnterpriseManagement.OperationsManager") | Out-Null 
}

Function Get-AUCService($strComputer)
{
	$TheService = Get-WmiObject  -ComputerName  $strComputer -Query "Select * From Win32_Service Where Name = 'Alert Update Connector'"
	$TheService
}

Function Ping-Check($computer, $iPingRetryWait, $iPingRetryTimes)
{
	$bPing = $false
	$ping = New-Object Net.NetworkInformation.Ping
    #ping with timeout setting of 1 second
	$PingResult = $ping.send($computer, 1000)
	if ($PingResult.Status.Tostring().ToLower() -eq "success")
	{
		$bPing = $true
	} else {
		#if first attemp failed, wait for number of seconds that's defined in XML file and try again
		Start-Sleep $iPingRetryWait
		#attemp to ping few more times (defined in XML file)
		For ($i=1; $i -le $iPingRetryTimes; $i++)
		{
			$PingResult = $ping.send($computer)
			if ($PingResult.Status.Tostring().ToLower() -eq "success")
			{
				$bPing = $true
			}
		}
		
	}
	return $bPing
}
#endregion

Write-Host "Current Running instances: $RunningCount".
$iToBeDisabled = $RunningCount - 1
Write-Host "$iToBeDisabled instance(s) will be stopped and dsiabled."

#Connect to MG
Load-SDK
Write-Host "Connecting to management group and retrieve all instances of Alert Update Connector services."
$MGConnSetting = New-Object Microsoft.EnterpriseManagement.ManagementGroupConnectionSettings($env:COMPUTERNAME)
$MG = New-Object Microsoft.EnterpriseManagement.ManagementGroup($MGConnSetting)

$strClassSearchCriteria = "Name='AlertUpdateConnector.Connector'"
$ClassSearchCriteria = New-Object  Microsoft.EnterpriseManagement.Configuration.MonitoringClassCriteria($strClassSearchCriteria)
$ColConnectorClass = $MG.GetMonitoringClasses($ClassSearchCriteria)
If ($ColConnectorClass.Count -gt 1)
{
	#Multiple classes found with the same name 'AlertUpdateConnector.Connector'
	Write-Error  "Multiple classes found with the same name 'AlertUpdateConnector.Connector'"
	Exit 1
} else {
	$ConnectorClass = $ColConnectorClass[0]
}

#Get Alert Update Connector Instance
$ColConnectorInstances = $MG.GetMonitoringObjects($ConnectorClass)
If ($ColConnectorInstances.Count -gt 1)
{
	#Multiple Alert Update Connector instances found.
	Write-Error "Multiple Alert Update Connector instances found. There should only be one (1) instance."
	Exit 2
} else {
	$objConnector = $ColConnectorInstances[0]
}

#Get all Alert Update Connector Services
$colAUCServices = $objConnector.GetRelatedMonitoringObjects() | Where-Object {$_.Name -ieq "Alert Update Connector"}
$AUCServicesCount = $colAUCServices.Count
Write-Host "$AUCServicesCount instance(s) of Alert Update Connector Service(s) detected."
$arrRunning = New-Object System.Collections.ArrayList


Foreach ($AUCService in $colAUCServices)
{
	$HostingComputer = $AUCService.Path
	#Make sure it's pingable
	Write-Host "Tring to ping $HostingComputer`..."
	If (Ping-Check $HostingComputer 1 2)
	{
		$AUCService = Get-AUCService $HostingComputer
		IF ($AUCService.State -ieq "Running")
		{
			[void]$arrRunning.Add($AUCService)
			Write-Host "The Alert Update Connector Service is running on $HostingComputer`."
		}
	} else {
		Write-Host "$HostingComputer is offline."
	}
	Write-Host ""
}

#try stop and disable all but 1

For ($i=0; $i -lt $arrRunning.count - 1; $i++)
{
	$HostName = $arrRunning[$i].SystemName
	Write-Host "Stopping and disabling Alert Update Connector service on $HostName`..."
	#Stop First
	$StopResult = $arrRunning[$i].StopService()
	If ($StopResult.ReturnValue -eq 0)
	{
		Write-Host "Stopped on $HostName."
	} else {
		Write-Error "Unable to stop the service on $HostName."
	}

	#Then disable it
	$DisableResult = $arrRunning[$i].ChangeStartMode("Disabled")
	If ($DisableResult.ReturnValue -eq 0)
	{
		Write-Host "Disabled on $HostName."
	} else {
		Write-Error "Unable to disable the service on $HostName."
	}
	Write-Host ""
}


Write-Host "Done"