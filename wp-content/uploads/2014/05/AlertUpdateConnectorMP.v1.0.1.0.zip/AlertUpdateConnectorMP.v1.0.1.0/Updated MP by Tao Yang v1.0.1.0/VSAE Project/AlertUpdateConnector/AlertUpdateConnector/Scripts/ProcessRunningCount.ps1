param([int]$RunningCount)
$api = new-object -comObject 'MOM.ScriptAPI'
$bag = $api.CreatePropertyBag()
$bag.AddValue('RunningCount', $RunningCount)
$bag