<# 
 .Synopsis
  Script to clean up obsolete references from unsealed MPs

 .Description
  This script connects to OpsMgr management group via SDK and detects obsolete management pack references in each unsealed management pack.

 .Parameter ManagementServer
  Specify the OpsMgr management server which the script connects to.

 .Parameter BackupBeforeModify
  Backup the unsealed management pack before making changes.

 .Parameter BackupLocation
  Specify the management pack backup location. This is a required parameter when -BackupBeforeModify switch is specified.

 .Parameter IncrementVersion
  When specified, the revision number of the MP version will be increased by 1. i.e. MP version 1.0.0.0 would be changed to 1.0.0.1.
  
 .Parameter -WhatIf
  Test run the script without making any changes to the OpsMgr environment.

 .Example
   Connect to management server MS01, back up to C:\Temp and increase the managemnet pack version number
   
   .\MPReferencesCleanUp.ps1 -ManagementServer "MS01" -BackupBeforeModify "C:\Temp" -IncrementVersion
   
   OR
   
   .\MPReferencesCleanUp.ps1 -SDK "MS01" -BackupBeforeModify "C:\Temp" -IncrementVersion
 .Example
   Test run to examine the possible result.
   
   .\MPReferencesCleanUp.ps1 -ManagementServer "MS01" -BackupBeforeModify "C:\Temp" -IncrementVersion -WhatIf
   
   OR
   
   .\MPReferencesCleanUp.ps1 -SDK "MS01" -BackupBeforeModify -BackupLocation "C:\Temp" -IncrementVersion -WhatIf

.NOTES
The list of common management packs is stored in the CommonMPs.xml file located in the same directory of this script. You may modify it manually to suit your environments.
#>

#==============================================================================
# Script Name:    	MPReferencesCleanUp.ps1
# DATE:           	24/06/2014
# Version:        	1.2
# COMMENT:			- Script to clean up obsolete references from unsealed MPs
#==============================================================================
Param (
	[Parameter(Mandatory=$true)][Alias("SDK")][string]$ManagementServer,
	[Parameter(Mandatory=$false)][switch]$BackupBeforeModify,
	[Parameter(Mandatory=$false)][string]$BackupLocation,
	[Parameter(Mandatory=$false)][switch]$IncrementVersion,
	[Parameter(Mandatory=$false)][Switch]$WhatIf
)

#Region FunctionLibs
function Load-SDK()
{
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.EnterpriseManagement.OperationsManager.Common") | Out-Null
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.EnterpriseManagement.OperationsManager") | Out-Null
}

Function Get-ObsoleteReferences ([XML]$MPXML,[System.Collections.ArrayList]$arrCommonMPs)
{
	$arrObSoleteRefs = New-Object System.Collections.ArrayList
	$Refs = $MPXML.ManagementPack.Manifest.References.Reference
	Foreach ($Ref in $Refs)
	{
		$RefMPID = $Ref.ID
		$Alias = $Ref.Alias
		$strRef = "$Alias`!"
		If (!($MPXML.Innerxml.contains($strRef)))
		{
			#The alias is obsolete
			#Ignore Common MPs
			If (!($arrCommonMPs.contains($RefMPID)))
			{
				#Referecing MP is not a common MP
				[Void]$arrObSoleteRefs.Add($Ref)
			}

		}
	}
	,$arrObSoleteRefs
}

Function Get-MpXmlString ($MP)
{
    $MPStringBuilder = New-Object System.Text.StringBuilder
    $MPXmlWriter = New-Object Microsoft.EnterpriseManagement.Configuration.IO.ManagementPackXmlWriter([System.Xml.XmlWriter]::Create($MPStringBuilder))
    [Void]$MPXmlWriter.WriteManagementPack($MP)
    $MPXML = [XML]$MPStringBuilder.ToString()
    $MPXML
}

Function Increase-Version ([String]$CurrentVersion)
{
	$vIncrement = $CurrentVersion.Split('.')
    $vIncrement[$vIncrement.Length - 1] = ([system.int32]::Parse($vIncrement[$vIncrement.Length - 1]) + 1).ToString()
    $NewVersion = ([string]::Join(".", $vIncrement))
	$NewVersion
}
#EndRegion

#region Main

#Define a list of common referencing MPs that will be exempted from deletion
#Read list of common management packs from CommonMPs.xml
$thisScript = Split-Path $myInvocation.MyCommand.Path -Leaf
$scriptRoot = Split-Path (Resolve-Path $myInvocation.MyCommand.Path)
$CommonMPsFile = Join-Path $scriptRoot "CommonMPs.xml"


If (!(Test-Path $CommonMPsFile))
{
    Write-Error "$CommonMPsFile does not exist. Script aborted."
    Exit 1
}

$CommonMPsXML = [xml](Get-Content $CommonMPsFile)

#Define an arraylist to store common MPs
$arrCommonMPs = New-Object System.Collections.ArrayList
Foreach ($item in $CommonMPsXML.Configuration.CommonMPs.CommonMP)
{
[Void]$arrCommonMPs.Add($item)
}

#Connect to SCOM management group
Load-SDK
$MGConnSetting = New-Object Microsoft.EnterpriseManagement.ManagementGroupConnectionSettings($ManagementServer)
$MG = New-Object Microsoft.EnterpriseManagement.ManagementGroup($MGConnSetting)

#Create ManagementPackXMLWriter object if backup is required
If ($BackupBeforeModify)
{
	If (Test-Path $BackupLocation)
	{
		$date = Get-Date
		$BackupSubDir = "$($date.day)-$($date.month)-$($date.year) $($date.hour)`.$($date.minute)`.$($date.second)"
		$BackupDir = Join-Path $BackupLocation $BackupSubDir
	} else {
		Write-Error "Invalid Backup Location specified."
		Exit 2
	}
}

#Get all unsealed MPs
Write-Host "Getting Unsealed management packs..."
$strMPquery = "Sealed = 'false'"
$mpCriteria = New-Object  Microsoft.EnterpriseManagement.Configuration.ManagementPackCriteria($strMPquery)
$arrMPs = $MG.GetManagementPacks($mpCriteria)
Write-Host "Total number of unsealed management packs: $($arrMPs.count)"
Write-Host ""
$iTotalUpdated = 0
Foreach ($MP in $arrMPs)
{
	Write-Host "Checking MP: '$($MP.Name)'..." -ForegroundColor Green
	#Firstly, get the XML
	#$MPXML = Get-MPXML $MP.Name
	$MPXML = Get-MpXmlString $MP
	#Then get obsolete references (if there are any)
	$arrRefToDelete = Get-ObsoleteReferences $MPXML $arrCommonMPs
	
	If ($arrRefToDelete.count -gt 0)
	{
		
        Write-Host " - Number of obsolete references found: $($arrRefToDelete.count)" -ForegroundColor Yellow
		
		#Pre-Update MP verify
		Write-Host " - Verifying MP before updating it." -ForegroundColor Green
		Try
		{
			$bPreUpdateVerified = $MP.Verify()
		}Catch {
			$bPreUpdateVerified = $false
			Write-Host "   - MP verify failed. No changes will be made to this management pack. The MP Verify Error:" -ForegroundColor Red
			Write-Host $Error[0] -ForegroundColor Red
			Write-Host ""
		}
		
		If ($BackupBeforeModify -and $bPreUpdateVerified -ne $false)
		{
			If (!$WhatIf)
			{
				#Create Backup Dir if it's not present
                if (!(Test-path $BackupDir))
                {
                    New-Item -type directory -Path $BackupDir | Out-Null
                }

                #Create mpwriter if it's not created
                If (!$mpwriter)
                {
                    $mpWriter = new-object Microsoft.EnterpriseManagement.Configuration.IO.ManagementPackXmlWriter($BackupDir)
                }

                Write-Host " - Backing up $($MP.Name) to $BackupDir before modifying it."
				$mpWriter.WriteManagementPack($MP) | Out-Null
			} else {
				Write-Host " - $($MP.Name) would have been backed up to $BackupDir before modifying it."
			}
		}
		Foreach ($item in $arrRefToDelete)
		{	
			If (!$WhatIf -and $bPreUpdateVerified -ne $false)
			{
				Write-Host "  - Deleting reference '$($item.Alias)' `($($item.ID)`)"
				$MP.References.remove($item.Alias) | out-Null

			} else {
				if ($bPreUpdateVerified -ne $false)
				{
					Write-Host "  - The reference '$($item.Alias)' `($($item.ID)`) would have been deleted."
				} else {
					Write-Host "  - Pleae try manually remove the reference '$($item.Alias)' `($($item.ID)`)." -ForegroundColor Yellow
				}
			}
		}
		
		#calculate the new version number if $IncrementVersion switch is specified
		if ($IncrementVersion)
		{
			$CurrentVersion = $MP.Version.Tostring()
			$NewVersion = Increase-Version $CurrentVersion
		}
		
		If ($bPreUpdateVerified -ne $false)
		{
			If (!$WhatIf )
			{
				If ($IncrementVersion)
				{
					Write-Host "  - Updating MP Version from $CurrentVersion to $NewVersion"
					$MP.Version = $NewVersion
				}
				
				Try
				{
					$bPostUpdateVerified = $MP.Verify()
				}Catch {
					$bPostUpdateVerified = $false
				}

				#accept changes if MP is verified. otherwise reject changes
				If ($bPostUpdateVerified -eq $false)
				{
					Write-Host " - MP Verify failed. Reject changes." -ForegroundColor Red
					$MP.RejectChanges()
				} else {
					Write-Host " - MP Verified. Accepting changes."
					$MP.AcceptChanges()

				}
			} else {
				If ($IncrementVersion)
				{
					Write-Host "  - The MP version would have been updated from $CurrentVersion to $NewVersion."
				}
			}
		}
		if ($bPreUpdateVerified -ne $false)
		{
			$iTotalUpdated ++
		}
	}
	Write-Host ""
}

If ($WhatIf){
    Write-host "Total number of unsealed management packs would have been updated: $iTotalUpdated" -ForegroundColor Green
} else {
    Write-host "Total number of unsealed management packs have been updated: $iTotalUpdated" -ForegroundColor Green
}

Write-Host "Done" -ForegroundColor Green
#endregion