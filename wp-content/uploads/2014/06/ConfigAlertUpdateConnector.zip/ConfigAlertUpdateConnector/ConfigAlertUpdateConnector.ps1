#=======================================================================================
# AUTHOR:	Tao Yang 
# DATE:		07/04/2014
# Name:		ConfigAlertUpdateConnector.PS1
# Version:	1.0
# COMMENT:	Script to generate SCOM 2012 Alert Update Connector's configuration xml file
#=======================================================================================
#region initiation
$thisScript = $myInvocation.MyCommand.Path
$scriptRoot = Split-Path(Resolve-Path $thisScript)
#$ScriptRoot = $pwd
$ConfigXMLPath = Join-Path $scriptRoot "ConfigAlertUpdateConnector.xml"

#endregion

#region Function Library
function Load-SDK ([string]$sdkDir)
{
	[System.Reflection.Assembly]::LoadFrom("$sdkDir\Microsoft.EnterpriseManagement.OperationsManager.Common.dll") | Out-Null
	[System.Reflection.Assembly]::LoadFrom("$sdkDir\Microsoft.EnterpriseManagement.OperationsManager.dll") | Out-Null
}

function Get-CurrentUser
{
    $me = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    Return $me
}

Function Get-AlertWorkflows ($MG, $strMCDNSearch, $strMCNameSearch)
{
    #Get GenerateAlert WriteAction module
    $HealthMPId = [guid]"0abff86f-a35e-b08f-da0e-ff051ab2840c" #this is unique
    $HealthMP = $MG.GetManagementPack($HealthMPId)
    $AlertWA = $HealthMP.GetModuleType("System.Health.GenerateAlert")
    $AlertWAId = $AlertWA.Id
    
    $arrAlertWorkflows = New-Object System.Collections.ArrayList
    #firstly get all monitoring classes
    #Populate Search criteria
    If ($strMCDNSearch.length -gt 0 -and $strMCNameSearch.length -gt 0)
    {
        #Both display name and ID have to match
        $strMCCriteria = "DisplayName LIKE '`%$strMCDNSearch`%' AND Name LIKE '`%$strMCNameSearch`%'"
    } elseif ($strMCDNSearch.length -gt 0)
    {
        #ID search string not specified, only searching base on DisplayName
        $strMCCriteria = "DisplayName LIKE '`%$strMCDNSearch`%'"
    }elseIf ($strMCNameSearch.length -gt 0)
    {
        #DisplayName search string not specified, only searching base on ID
        $strMCCriteria = "Name LIKE '`%$strMCNameSearch`%'"
    }
     Write-Host "  - Monitoring Class Search Criteria: `"$strMCCriteria`""
    $ClassCriteria = New-Object Microsoft.EnterpriseManagement.Configuration.MonitoringClassCriteria($strMCCriteria)
    $MonitoringClasses = $MG.GetMonitoringClasses($ClassCriteria)
    Write-Host " - Number of Monitoring Class Found: $($MonitoringClasses.count)" -ForegroundColor Green

    Foreach ($MC in $MonitoringClasses)
    {
        $MCId = $MC.Id
        $MCName = $MC.Name
        Write-Host "   - Monitoring Class Name: $MCName"
        
        #Get alert generating monitors first
        $strMonitorCriteria = "TargetMonitoringClassId = '$MCId' AND AlertOnState IS NOT NULL"
        $MonitorCriteria = New-Object Microsoft.EnterpriseManagement.Configuration.MonitorCriteria($strMonitorCriteria)
        $Monitors = $MG.getmonitors($MonitorCriteria)
        Write-Host "     - Monitor count: $($monitors.count)"
        Foreach ($Monitor in $Monitors)
        {
            #not all the properties need to be returned.
            #But information about the monitoring class needs to be returned.
            #Creating a custom psobject for the monitor
            $objWF = New-Object psobject
            Add-Member -InputObject $objWF -MemberType NoteProperty -Name "Name" -Value $monitor.Name
            Add-Member -InputObject $objWF -MemberType NoteProperty -Name "DisplayName" -Value $monitor.DisplayName
            Add-Member -InputObject $objWF -MemberType NoteProperty -Name "Id" -Value $monitor.Id
            Add-Member -InputObject $objWF -MemberType NoteProperty -Name "Type" -Value "Monitor"
            Add-Member -InputObject $objWF -MemberType NoteProperty -Name "XmlTag" -Value $monitor.XmlTag
            Add-Member -InputObject $objWF -MemberType NoteProperty -Name "Enabled" -Value $monitor.Enabled
            Add-Member -InputObject $objWF -MemberType NoteProperty -Name "MonitoringClassId" -Value $MC.Id
            Add-Member -InputObject $objWF -MemberType NoteProperty -Name "MonitoringClassName" -Value $MC.Name
            Add-Member -InputObject $objWF -MemberType NoteProperty -Name "MonitoringClassDisplayName" -Value $MC.DisplayName

            #Add to arraylist
            [void]$arrAlertWorkflows.Add($objWF)
        }

        #Then get alert generating rules
        $strRuleCriteria = "TargetMonitoringClassId = '$MCId'"
        $RuleCriteria = New-Object Microsoft.EnterpriseManagement.Configuration.MonitoringRuleCriteria($strRuleCriteria)
        $Rules = $MG.GetMonitoringRules($RuleCriteria)
        $iAlertRuleCount = 0
        Foreach ($rule in $Rules)
        {
            #Unfortunately, we cannot use a member module name/id in MonitoringRUleCriteria.
            #So we have to manually filter out the rules with GenerateAlert Write Action Module
            #Check if it has a GenerateAlert WriteAction module
            $bAlertRule = $false
            Foreach ($WAModule in $Rule.WriteActionCollection)
            {
                if ($WAModule.TypeId.Id -eq $AlertWAId)
                {
                    #this rule generates alert
                    $bAlertRule = $true
                } else {
                    #need to detect if it's using a customized WA which the GenerateAlert WA is a member of
                    $WAId = $WAModule.TypeId.Id
                    $WASource = $MG.GetMonitoringModuleType($WAId)
                    #Check each write action member modules in the customized write action module...
                    Foreach ($item in $WASource.WriteActionCollection)
                    {
                        $itemId = $item.TypeId.Id
                        If ($ItemId -eq $AlertWAId)
                        {
                            $bAlertRule = $true
                        }
                    }
                }
            }

            if ($bAlertRule)
            {
                $iAlertRuleCount = $iAlertRuleCount + 1
                #not all the properties need to be returned.
                #But information about the monitoring class needs to be returned.
                #Creating a custom psobject for the monitor
                $objWF = New-Object psobject
                Add-Member -InputObject $objWF -MemberType NoteProperty -Name "Name" -Value $rule.Name
                Add-Member -InputObject $objWF -MemberType NoteProperty -Name "DisplayName" -Value $rule.DisplayName
                Add-Member -InputObject $objWF -MemberType NoteProperty -Name "Id" -Value $rule.Id
                Add-Member -InputObject $objWF -MemberType NoteProperty -Name "Type" -Value "Rule"
                Add-Member -InputObject $objWF -MemberType NoteProperty -Name "XmlTag" -Value $rule.XmlTag
                Add-Member -InputObject $objWF -MemberType NoteProperty -Name "Enabled" -Value $rule.Enabled
                Add-Member -InputObject $objWF -MemberType NoteProperty -Name "MonitoringClassId" -Value $MC.Id
                Add-Member -InputObject $objWF -MemberType NoteProperty -Name "MonitoringClassName" -Value $MC.Name
                Add-Member -InputObject $objWF -MemberType NoteProperty -Name "MonitoringClassDisplayName" -Value $MC.DisplayName

                #Add to arraylist
                [void]$arrAlertWorkflows.Add($objWF)
            }

        }
        Write-Host "     - Rule count: $iAlertRuleCount"
    }

    $arrAlertWorkflows
}

Function Archive-OldOutPut ($ScriptRoot, $OutPutXMLPath)
{
    If (Test-Path $OutPutXMLPath)
    {
        #Rename and copy to archive folder
        $ArchiveDir = Join-Path $ScriptRoot "Archive"
        #Create an Archive folder if doesn't exist
        If (!(Test-path $ArchiveDir))
        {
            New-Item -ItemType Directory -Path $ArchiveDir | Out-Null
        }
        $TimeStamp = (Get-Date).ToFileTime()
        $NewName = (Split-Path $OutPutXMLPath -Leaf).split(".")[0] + " - " + $TimeStamp + ".xml"
        
        $RenamedFile = Join-Path $ArchiveDir $NewName
        Move-Item -Path $OutPutXMLPath -Destination "$RenamedFile"
    }
}
#endregion

#region Read XML
$ConfigXML = [xml](get-content $ConfigXMLPath)
$SDKComputer = $ConfigXML.Configuration.SDKComputer
$strGlobalResolutionState = $ConfigXML.Configuration.GlobalResolutionState
$strExcludeResolutionState = $ConfigXML.Configuration.ExcludeResolutionState
$arrAlertUpdateRules = $ConfigXML.Configuration.AlertUpdateRules.AlertUpdateRule
#endregion

#region Main
#Load SDK
Load-SDK $ScriptRoot

#Get current user's user name
$me = Get-CurrentUser

#Create an ArrayList to store all processed workflows
$arrWorkflows = New-Object System.Collections.ArrayList

#Connect to Management Group
$MGConnSetting = New-Object Microsoft.EnterpriseManagement.ManagementGroupConnectionSettings($SDKComputer)
$MG = New-Object Microsoft.EnterpriseManagement.ManagementGroup($MGConnSetting)

#Preparing output XML
$OutPutXMLPath = Join-Path $ScriptRoot $ConfigXML.Configuration.OutputXML
#Archive previous output
If (Test-Path $OutPutXMLPath)
{
    Archive-OldOutPut $ScriptRoot $OutPutXMLPath
}

#Create XML writer
$XmlWriter = New-Object System.Xml.XmlTextWriter($OutPutXMLPath,$null)

#Define XML Formatting
$xmlWriter.Formatting = 'Indented'
$xmlWriter.Indentation = 1
$XmlWriter.IndentChar = "`t"

#Write XML start element "ConnectorConfig"
$xmlWriter.WriteStartDocument()
$XmlWriter.WriteStartElement("ConnectorConfig")
$xmlWriter.WriteAttributeString("GlobalResolutionState", $strGlobalResolutionState)
$xmlWriter.WriteAttributeString("ExcludeResolutionState", $strExcludeResolutionState)

#Write XML Element "AlertSources"
$XmlWriter.WriteStartElement("AlertSources")
#Process Alert groups
Foreach ($item in $arrAlertUpdateRules)
{
    #Class Display Name Search String
    $strClsDNSearch = $item.ClassSearchPhrase.DisplayName

    #Class ID SearchString
    $strClsNameSearch =$item.ClassSearchPhrase.Name

    Write-Host "Searching class: DisplayName = `'$strClsDNSearch`', Name = `'$strClsNameSearch`'..." -ForegroundColor Green
    
    #Get any exceptions - if there are any
    If ($item.Exceptions)
    {
        $arrExceptions = $item.Exceptions.Workflow
         Write-Host " - Exceptions found..." -ForegroundColor Yellow
    } else {
        $arrExceptions = $null
    }
    #Get alert generating workflows
    Write-Host " - Searching Alert Generating Workflows..."
    $AlertWFs = Get-AlertWorkflows $MG $strClsDNSearch $strClsNameSearch
    Write-Host " - Processing Workflows..."
    Foreach ($Workflow in $AlertWFs)
    {
        $WFDisplayName = $Workflow.DisplayName
        $strWFId = $Workflow.Id.Tostring()
        $strWFType = $workflow.Type
        Write-Host "Processing $strWFType`: $WFDisplayName`($strWFId`)" -ForegroundColor Green
        #only proceed if the workflow has not been previously processed
        If (!$arrWorkflows.contains($strWFId))
        {
            #workflow has not been processed, add to the arraylist and then continue
            [void]$arrWorkflows.Add($strWFId)

            #Keep track of what properties have been defined
            $arrDefinedProperties = New-Object System.Collections.ArrayList

            $strComment = "$strWFType`: $WFDisplayName`($($Workflow.Name)`) - Class: $($Workflow.MonitoringClassDisplayname)`($($workflow.MonitoringClassName)`)"
            $XmlWriter.WriteComment($strComment)
            $XmlWriter.WriteStartElement("AlertSource")
            $xmlWriter.WriteAttributeString("Id", $strWFId)
            $xmlWriter.WriteAttributeString("Type", "$strWFType")
            $xmlWriter.WriteAttributeString("UserName", $me)
            $XmlWriter.WriteStartElement("PropertiesToModify")

            #Check if there are exceptions apply to this monitor
            If ($arrExceptions)
            {
                $arrVariations = New-Object system.collections.arraylist
                Foreach ($Exception in $arrExceptions)
                {
                    if ($WFDisplayName -imatch $Exception.Name)
                    {
                        #The exception applies
                        Write-Host "  - Exception applies to $strWFType`: $WFDisplayName `($($workflow.Id)`)" -ForegroundColor Yellow
                        [void]$arrVariations.Add($Exception)
                    }
                }
            } else {
                $arrVariations = $null
            }
        
            Foreach ($objProperty in $item.PropertiesToModify.Property)
            {
            
                $PName = $objProperty.Name
                #Property value (Default value at this stage)
                $PNewValue = $objProperty.NewValue
                $pGroupIdFilter = $objProperty.GroupIdFilter

                #Write-Host "Default Value: $PName, $PNewValue, $pGroupIdFilter"
                #Process exceptions if there are any
                if ($arrVariations.count -gt 0)
                {
                    Foreach ($Variation in $arrVariations)
                    {
                        Foreach ($PropertyVariation in $variation.PropertiesToModify.Property)
                        {
                            $bDupException = $false
                            if ($PName -ieq $($PropertyVariation.Name))
                            {
                                $PNewValue = $PropertyVariation.NewValue
                                $pGroupIdFilter = $PropertyVariation.GroupIdFilter

                            }

                             Foreach ($DefinedProperty in $arrDefinedProperties)
                            {
                                if ($($DefinedProperty.Name) -ieq $PName -and $($DefinedProperty.GroupIdFilter) -ieq $pGroupIdFilter)
                                {
                                    #The property with the same scope already defined. this looks like a duplicate exception
                                    #Write-host "    - Duplicate exception detected. Property Name: $($DefinedProperty.Name), GroupIDFilter: $($DefinedProperty.GroupIdFilter)" -ForegroundColor Red
                                    #Write-Host "       - $($DefinedProperty.Name)" -ForegroundColor Red
                                    #Write-Host "       - $($DefinedProperty.NewValue)" -ForegroundColor Red
                                    #Write-Host "       - $($DefinedProperty.GroupIdFilter)" -ForegroundColor Red
                                    $bDupException = $true
                                }
                            }

                            if (!$bDupException)
                            {
                                [void]$arrDefinedProperties.Add($objProperty)
                                [void]$arrDefinedProperties.Add($PropertyVariation)

                                #Write-host "    - Write to XML" -ForegroundColor Green
                                #Write-Host "       - $PName" -ForegroundColor Green
                                #Write-Host "       - $PNewValue" -ForegroundColor Green
                                #Write-Host "       - $pGroupIdFilter" -ForegroundColor Green
                                $XmlWriter.WriteStartElement("Property")
                                $xmlWriter.WriteAttributeString("Name", $PName)
                                $xmlWriter.WriteAttributeString("NewValue", $PNewValue)
                                $xmlWriter.WriteAttributeString("GroupIdFilter", $pGroupIdFilter)
                                #Close "Property" Node
                                $XmlWriter.WriteEndElement()
                            }                                

                        }
                    }
                } else {
                    #No exceptions apply
                    $XmlWriter.WriteStartElement("Property")
                    $xmlWriter.WriteAttributeString("Name", $PName)
                    $xmlWriter.WriteAttributeString("NewValue", $PNewValue)
                    $xmlWriter.WriteAttributeString("GroupIdFilter", $pGroupIdFilter)
                    #Close "Property" Node
                    $XmlWriter.WriteEndElement()
                }

            }
            #Close "PropertiesToModify" Node
            $XmlWriter.WriteEndElement()
        
            #Close "AlertSource"
            $XmlWriter.WriteEndElement()
        } else {
            #Write-Host "  - Duplicate $strWFType found:" -ForegroundColor Red
            #Write-Host "  - $strWFType Id: $strWFId"
            #Write-Host "  - $strWFType Name: $($workflow.name)"
            #Write-Host "  - $strWFType Display Name: $WFDisplayName"
        }
    }

    Write-Host ""
}

#Close "AlertSources"
$XmlWriter.WriteEndElement()

#Finalise "ConnectorConfig"
$XmlWriter.WriteEndElement()

#Write XML to file
$xmlWriter.WriteEndDocument()
$XmlWriter.Flush()
$XmlWriter.Close()
#endregion