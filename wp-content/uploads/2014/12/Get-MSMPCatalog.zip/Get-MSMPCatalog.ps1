Workflow Get-MSMPCatalog
{
#====================================================================================
# AUTHOR:  Tao Yang 
# DATE:    01/12/2014
# Version: 1.0
# Comment: Download Microsoft SCOM management packs information from Microsoft MP Catalog
#====================================================================================

#Get the full MP list
$arrMPs = inlinescript
{
    #variables
    $MPCatalogURL = "https://www.microsoft.com/mpdownload/ManagementPackCatalogWebService.asmx"
    $SOAPAction = "http://microsoft.com/webservices/FindManagementPacks"
$MPSoap = [xml]@'
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <soap:Body>
    <FindManagementPacks xmlns="http://microsoft.com/webservices/">
      <criteria>
        <ManagementPackNamePattern>%</ManagementPackNamePattern>
        <VendorNamePattern>%Microsoft%</VendorNamePattern>
        <ReleasedOnOrAfter>2000-01-01T00:00:00</ReleasedOnOrAfter>
      </criteria>
      <productInfo>
        <ProductName>Operations Manager</ProductName>
        <ProductVersion>7.0.9538.0</ProductVersion>
      </productInfo>
      <threeLetterLanguageCode>ENU</threeLetterLanguageCode>
    </FindManagementPacks>
  </soap:Body>
</soap:Envelope>
'@
    write-verbose "Send SOAP Request: $MPCatalogURL" 
    $soapWebRequest = [System.Net.WebRequest]::Create($MPCatalogURL) 
    $soapWebRequest.Headers.Add("SOAPAction","`"$SOAPAction`"")
    $soapWebRequest.ContentType = "text/xml;charset=`"utf-8`"" 
    $soapWebRequest.Accept = "text/xml" 
    $soapWebRequest.Method = "POST" 
    write-verbose "Send Request Stream" 
    $requestStream = $soapWebRequest.GetRequestStream() 
    $MPSoap.Save($requestStream) 
    $requestStream.Close() 
    write-verbose "Get Response." 
    $resp = $soapWebRequest.GetResponse() 
    $responseStream = $resp.GetResponseStream() 
    $soapReader = [System.IO.StreamReader]($responseStream) 
    $RetXml = [Xml] $soapReader.ReadToEnd() 
    $responseStream.Close() 
    write-verbose "Response Received."


    #process the result
    $arrMPs = New-Object System.Collections.ArrayList
    $arrCatelogItems = $RetXml.Envelope.Body.FindManagementPacksResponse.FindManagementPacksResult.CatalogItem | Sort-Object SystemName
    Foreach ($item in $arrCatelogItems)
    {
        if ($item.Categories.int.count -gt 1)
        {
            $Categories = [System.String]::Join(",", $($item.Categories.int))
        } else {
            $Categories = $item.Categories.int
        }
        If ($item.IsManagementPack -ieq "TRUE")
        {
            $objMP = New-Object PSObject -Property @{
                CatalogItemId = $item.CatalogItemId
                DisplayName = $item.DisplayName
                SystemName = $item.SystemName
                PublicKey = $item.PublicKey
                VersionIndependentGuid = $item.identity.VersionIndependentGuid
                Version = $item.identity.Version
                Vendor = "Microsoft"
                DownloadLink = $item.DownloadLink
                ReleaseDate = $item.ReleaseDate
                Categories = $Categories
            }
            [void]$arrMPs.Add($objMP)
        }
    }
    $arrMPs
}
    Write-Verbose "Total Number of Management Packs in Microsoft's MP Catelog: $($arrMPs.count)"
    $arrMPs
}