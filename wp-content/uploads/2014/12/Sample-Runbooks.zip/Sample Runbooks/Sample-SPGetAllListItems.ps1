Workflow Sample-SPGetAllListItems
{
	Param(
    [Parameter(Mandatory=$true,HelpMessage='Please specify the SharePoint SMA Connection name')][Alias('Connection','c')][string]$SPConnection,
    [Parameter(Mandatory=$true)][String]$ListName
    )

	$htConn = Get-AutomationConnection -Name $SPConnection
    Write-verbose "SharePoint Site URL: $($htconn.SharePointSiteURL)"
	$ListItems = InlineScript
    {
        Import-Module SharePointSDK
        $ListItems = 
        Get-SPListItem `
            -ListName $USING:ListName `
            -SPConnection $USING:htConn
        ,$ListItems
    }
    $ItemsCount = $ListItems.count
    Write-Output "List Items count: $ItemsCount."
    Foreach ($Item in $ListItems)
    {
        Write-Output $Item
    }
}