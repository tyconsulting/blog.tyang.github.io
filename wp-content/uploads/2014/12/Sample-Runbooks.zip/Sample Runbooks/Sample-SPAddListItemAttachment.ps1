Workflow Sample-SPAddListItemAttachment
{
	Param(
    [Parameter(Mandatory=$true,HelpMessage='Please specify the SharePoint SMA Connection name')][Alias('Connection','c')][string]$SPConnection,
    [Parameter(Mandatory=$true)][String]$NewUserListName,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the List Item ID')][Alias('Id')][int]$ListItemId,
    [Parameter(Mandatory=$true)][String]$FilePath,
	[Parameter(Mandatory=$false)][String]$RenamedFileName
    )

	$htConn = Get-AutomationConnection -Name $SPConnection
    Write-Output "SharePoint Site URL: $($htconn.SharePointSiteURL)"

	#First sample: attach the file directly to the list item
	Write-Verbose "1st sample: Directly attaching file `"$FilePath`"."
	$AttachFile = InlineScript
	{
		Import-Module SharePointSDK
		$bFileAttached = Add-SPListItemAttachment -SPConnection $USING:htConn -ListName $USING:NewUserListName -ListItemID $USING:ListItemId -FilePath $USING:FilePath
		$bFileAttached
	}
	Write-Output "`"$FilePath`" attached: $AttachFile"

	#Second sample: read a binary file, write to list item as an attachment with a renamed file name.
	Write-Verbose "2nd sample: Read `"$FilePath`" into byte array and save to list item as a renamed file `"$RenamedFileName`"."
	$RenamedAttachment = InlineScript
	{
		Import-Module SharePointSDK
		[Byte[]]$bytes = [System.IO.File]::ReadAllBytes($USING:FilePath)
		$bRenamedFileAttached = Add-SPListItemAttachment -SPConnection $USING:htConn -ListName $USING:NewUserListName -ListItemID $USING:ListItemId -ContentByteArray $bytes -FileName $USING:RenamedFileName
		$bRenamedFileAttached
	}
	Write-Output "Renamed file `"$RenamedFileName`" saved to list item: $RenamedAttachment"
}