Workflow Sample-SPUPdateListItem
{
	Param(
    [Parameter(Mandatory=$true,HelpMessage='Please specify the SharePoint SMA Connection name')][Alias('Connection','c')][string]$SPConnection,
    [Parameter(Mandatory=$true)][String]$NewUserListName,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the List Item ID')][Alias('Id')][int]$ListItemId,
	[Parameter(Mandatory=$false)][Alias('t')][string]$Title,
    [Parameter(Mandatory=$false)][String]$FirstName,
	[Parameter(Mandatory=$false)][String]$LastName,
	[Parameter(Mandatory=$false)][ValidateSet('Male', 'Female')][String]$Gender,
	[Parameter(Mandatory=$false)][String]$UserName
    )

	$htConn = Get-AutomationConnection -Name $SPConnection
    Write-Output "SharePoint Site URL: $($htconn.SharePointSiteURL)"

    #Get List Fields
    $ListFields = InlineScript
    {
        Import-Module SharePointSDK
        $ListFields = Get-SPListFields -SPConnection $USING:htConn -ListName $USING:NewUserListName -verbose
        ,$ListFields
    }
    $TitleField = ($ListFields | Where-Object {$_.Title -ieq 'Title' -and $_.ReadOnlyField -eq $false}).InternalName
    $FirstNameField = ($ListFields | Where-Object {$_.Title -ieq 'First Name' -and $_.ReadOnlyField -eq $false}).InternalName
    $LastNameField = ($ListFields | Where-Object {$_.Title -ieq 'Last Name' -and $_.ReadOnlyField -eq $false}).InternalName
    $GenderField = ($ListFields | Where-Object {$_.Title -ieq 'Gender' -and $_.ReadOnlyField -eq $false}).InternalName
    $UserNameField = ($ListFields | Where-Object {$_.Title -ieq 'User Name' -and $_.ReadOnlyField -eq $false}).InternalName
    
	#Work out which fields to update
	$UpdateDetails = InlineScript
	{
		$UpdateDetails = @{}
		If ($USING:Title)
		{
			$UpdateDetails.Add($USING:TitleField, $USING:Title)
		}
		If ($USING:FirstName)
		{
			$UpdateDetails.Add($USING:FirstNameField, $USING:FirstName)
		}
		If ($USING:LastName)
		{
			$UpdateDetails.Add($USING:LastNameField, $USING:LastName)
		}
		If ($USING:Gender)
		{
			$UpdateDetails.Add($USING:GenderField, $USING:Gender)
		}
		If ($USING:UserName)
		{
			$UpdateDetails.Add($USING:UserNameField, $USING:UserName)
		}
		$UpdateDetails
	}
	#Update a list item
    $UpdateListItem = InlineScript
    {
        Import-Module SharePointSDK    
        $UpdateListItem = Update-SPListItem -ListFieldsValues $USING:UpdateDetails -ListItemID $USING:ListItemID -ListName $USING:NewUserListName -SPConnection $USING:htConn 
        $UpdateListItem
    }
    Write-Output "List Item (ID: $ListItemId) updated: $UpdateListItem."
}