Workflow Sample-SPAddListItem
{
	Param(
    [Parameter(Mandatory=$true,HelpMessage='Please specify the SharePoint SMA Connection name')][Alias('Connection','c')][string]$SPConnection,
    [Parameter(Mandatory=$true)][String]$NewUserListName,
	[Parameter(Mandatory=$true)][Alias('t')][string]$Title,
    [Parameter(Mandatory=$true)][String]$FirstName,
	[Parameter(Mandatory=$true)][String]$LastName,
	[Parameter(Mandatory=$true)][ValidateSet('Male', 'Female')][String]$Gender,
	[Parameter(Mandatory=$true)][String]$UserName,
	[Parameter(Mandatory=$true)][String]$TextAttachmentContent,
	[Parameter(Mandatory=$true)][String]$AttachmentFileName
    )
	$htConn = Get-AutomationConnection -Name $SPConnection
    Write-Output "URL: $($htconn.SharePointSiteURL)"

	Write-Verbose "Creating New User for $FirstName $LastName."

    #Get List Fields
    $ListFields = InlineScript
    {
        Import-Module SharePointSDK
        $ListFields = Get-SPListFields -SPConnection $USING:htConn -ListName $USING:NewUserListName -verbose
        ,$ListFields
    }
    $TitleField = ($ListFields | Where-Object {$_.Title -ieq 'Title' -and $_.ReadOnlyField -eq $false}).InternalName
    $FirstNameField = ($ListFields | Where-Object {$_.Title -ieq 'First Name' -and $_.ReadOnlyField -eq $false}).InternalName
    $LastNameField = ($ListFields | Where-Object {$_.Title -ieq 'Last Name' -and $_.ReadOnlyField -eq $false}).InternalName
    $GenderField = ($ListFields | Where-Object {$_.Title -ieq 'Gender' -and $_.ReadOnlyField -eq $false}).InternalName
    $UserNameField = ($ListFields | Where-Object {$_.Title -ieq 'User Name' -and $_.ReadOnlyField -eq $false}).InternalName
	
	Write-Verbose "Title Field: $TitleField"
	Write-Verbose "First Name Field: $FirstNameField"
	Write-Verbose "Last Name Field: $LastNameField"
	Write-Verbose "Gender Field: $GenderField"
	Write-Verbose "User Name Field: $UserNameField"

	$AddUser = inlinescript
    {
        Import-Module SharePointSDK
        $UserDetails = @{
            $USING:TitleField = $USING:Title
            $USING:FirstNameField = $USING:FirstName
            $USING:LastNameField = $USING:LastName
            $USING:GenderField = $USING:Gender
            $USING:UserNameField = $USING:UserName
        }
        $AddUser = Add-SPListItem -ListFieldsValues $UserDetails -ListName $USING:NewUserListName -SPConnection $USING:htConn
        $AddUser 
    }
    If ($AddUser)
    {
        Write-Output "User Request for $FirstName $LastName is completed. List Item ID: $AddUser."
		Write-Verbose "Creating a text file attachment"
		$NewAttachment = InlineScript
		{
			Import-Module SharePointSDK
			[Byte[]]$Bytes=[System.Text.Encoding]::Default.GetBytes($USING:TextAttachmentContent)
			$AddTextFile = Add-SPListItemAttachment -SPConnection $USING:htConn -ListName $USING:NewUserListName -ListItemID $USING:AddUser -ContentByteArray $Bytes -FileName $USING:AttachmentFileName
			$AddTextFile
		}
		if ($NewAttachment)
		{
			Write-Verbose "Attachment $AttachmentFileName created."
		}
    } else {
        Write-Error "Unable to create user account for $FirstName $LastName."
    }
	Write-Output "Done."
}