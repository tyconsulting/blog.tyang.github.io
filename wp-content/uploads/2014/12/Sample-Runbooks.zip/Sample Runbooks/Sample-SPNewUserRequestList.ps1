Workflow Sample-SPNewUserRequestList
{
	Param(
    [Parameter(Mandatory=$true,HelpMessage='Please specify the SharePoint SMA Connection name')][Alias('Connection','c')][string]$SPConnection,
    [Parameter(Mandatory=$true)][String]$ListName
    )

	$htConn = Get-AutomationConnection -Name $SPConnection
    Write-Output "SharePoint Site URL: $($htConn.SharePointSiteURL)"

	$NewList = InlineScript
	{
		Import-Module SharePointSDK
		$Credential = New-SPCredential -SPConnection $USING:htConn
		$SiteUrl = $USING:htConn.SharePointSiteURL

		#Make sure the SharePoint Client SDK Runtime DLLs are loaded
		$ImportDLL = Import-SharePointClientSDK

		#Bind to site collection
		$Context = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
		$Context.Credentials = $Credential
		
		#Make sure the list is not previously created
		$bExistingList = $true
		Try
		{
			$ExistingList = $Context.Web.Lists.GetByTitle($ListName)
			$Context.Load($ExistingList)
			$Context.ExecuteQuery()
		} Catch {
			$bExistingList = $false
		}
		If ($bExistingList)
		{
			throw "the list `"$ListName`" already exists."
			return
		}
		
		#Create list using custom template
		Write-Verbose "Creating a generic list with name `"$ListName`"."
		$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
		$ListInfo.Title = $USING:ListName
		$ListInfo.TemplateType = [Microsoft.SharePoint.Client.ListTemplateType]::GenericList
		$List = $Context.Web.Lists.Add($ListInfo)
		$List.Description = "New Users Requests"
		$List.Update()
		$Context.ExecuteQuery()
		
		#Get Fields collection
		$colFields = $List.Fields
		$Context.Load($colFields)
		$context.ExecuteQuery()

		#Add fields
		Write-Verbose "Adding required fields to the list"
		$FNFieldSchema = '<Field Type="Text" DisplayName="First Name" Name="FirstName" Required="TRUE"/>'
		$LNFieldSchema = '<Field Type="Text" DisplayName="Last Name" Name="LastName" Required="TRUE"/>'
		$GenderFieldSchema = '<Field Type="Choice" DisplayName="Gender" Name="Gender" Format="RadioButtons" Required="TRUE"><CHOICES><CHOICE>Male</CHOICE><CHOICE>Female</CHOICE></CHOICES></Field>'
		$UNFieldSchema = '<Field Type="Text" DisplayName="User Name" Name="UserName" Required="TRUE"/>'
		Try
		{
			$colFields.AddFieldAsXml($FNFieldSchema, $true, [Microsoft.SharePoint.Client.AddFieldOptions]::AddFieldCheckDisplayName) | Out-Null
			$colFields.AddFieldAsXml($LNFieldSchema, $true, [Microsoft.SharePoint.Client.AddFieldOptions]::AddFieldCheckDisplayName) | Out-Null
			$colFields.AddFieldAsXml($GenderFieldSchema, $true, [Microsoft.SharePoint.Client.AddFieldOptions]::AddFieldCheckDisplayName) | Out-Null
			$colFields.AddFieldAsXml($UNFieldSchema, $true, [Microsoft.SharePoint.Client.AddFieldOptions]::AddFieldCheckDisplayName) | Out-Null
			$Context.ExecuteQuery()
		} Catch {
			Throw "List `"$ListName`" cannot be created."
		}
	}
	Write-Output "Done"
}