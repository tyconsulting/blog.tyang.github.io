workflow Sample-SPGetListFields
{
	Param(
    [Parameter(Mandatory=$true,HelpMessage='Please specify the SharePoint SMA Connection name')][Alias('Connection','c')][string]$SPConnection,
    [Parameter(Mandatory=$true)][String]$ListName
    )

	$htConn = Get-AutomationConnection -Name $SPConnection
    Write-Output "SharePoint Site URL: $($htconn.SharePointSiteURL)"
	#Get List Fields
    $ListFields = InlineScript
    {
        Import-Module SharePointSDK
        $ListFields = Get-SPListFields -SPConnection $USING:htConn -ListName $USING:ListName -verbose
        ,$ListFields
    }
    $FieldsCount = $ListFields.Count
    Write-Output "List Fields Count: $FieldsCount."
    Foreach ($Field in $ListFields)
    {
        Write-Output "$($Field.InternalName)`: $($Field.Title)"
    }
}