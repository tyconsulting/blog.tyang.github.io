Workflow Sample-SPDeleteListItem
{
	Param(
    [Parameter(Mandatory=$true,HelpMessage='Please specify the SharePoint SMA Connection name')][Alias('Connection','c')][string]$SPConnection,
    [Parameter(Mandatory=$true)][String]$ListName,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the List Item ID')][Alias('Id')][int]$ListItemId
    )

	$htConn = Get-AutomationConnection -Name $SPConnection
    Write-Output "SharePoint Site URL: $($htconn.SharePointSiteURL)"
	$DeleteListItem = InlineScript
    {
        Import-Module SharePointSDK
        $DeleteListItem = Remove-SPListItem -ListItemID $USING:ListItemID -ListName $USING:ListName -SPConnection $USING:htConn 
        $DeleteListItem
    }
	Write-Output "List Item (ID: $ListItemId) deleted: $DeleteListItem"
}