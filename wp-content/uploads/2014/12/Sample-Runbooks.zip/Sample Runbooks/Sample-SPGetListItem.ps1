Workflow Sample-SPGetListItem
{
	Param(
    [Parameter(Mandatory=$true,HelpMessage='Please specify the SharePoint SMA Connection name')][Alias('Connection','c')][string]$SPConnection,
    [Parameter(Mandatory=$true)][String]$ListName,
	[Parameter(Mandatory=$true)][Int]$ListItemID
    )

	$htConn = Get-AutomationConnection -Name $SPConnection
    Write-verbose "SharePoint Site URL: $($htconn.SharePointSiteURL)"
	$ListItem = InlineScript
    {
        Import-Module SharePointSDK
        $ListItem = Get-SPListItem -SPConnection $USING:htConn -ListName $USING:ListName -ListItemID $USING:ListItemID
        $ListItem
    }
   If ($ListItem)
    {
        Write-Output "List Item details:"
		Write-Output $ListItem
    } else {
		Write-Output "List Item with ID $ListItemID not found."
	}
}