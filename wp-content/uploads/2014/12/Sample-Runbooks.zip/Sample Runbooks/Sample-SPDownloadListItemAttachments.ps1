Workflow Sample-SPDownloadListItemAttachments
{
	Param(
    [Parameter(Mandatory=$true,HelpMessage='Please specify the SharePoint SMA Connection name')][Alias('Connection','c')][string]$SPConnection,
    [Parameter(Mandatory=$true)][String]$NewUserListName,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the List Item ID')][Alias('Id')][int]$ListItemId,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the destination folder of where attachments will be saved to')][Alias('Destination')][string]$DestinationFolder
    )

	$htConn = Get-AutomationConnection -Name $SPConnection
    Write-Output "SharePoint Site URL: $($htconn.SharePointSiteURL)"

	Write-Verbose "Deleting `"$FileName`" from List Item (ID: $ListItemId)."
	$DownloadCount = InlineScript
	{
		Import-Module SharePointSDK
		$DownloadCount = Get-SPListItemAttachments -SPConnection $USING:htConn -ListName $USING:NewUserListName -ListItemID $USING:ListItemId -DestinationFolder $USING:DestinationFolder
		$DownloadCount
	}
	Write-Output "Number of files downloaded: $DownloadCount"
}