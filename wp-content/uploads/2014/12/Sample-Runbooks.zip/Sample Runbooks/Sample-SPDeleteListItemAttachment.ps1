Workflow Sample-SPDeleteListItemAttachment
{
	Param(
    [Parameter(Mandatory=$true,HelpMessage='Please specify the SharePoint SMA Connection name')][Alias('Connection','c')][string]$SPConnection,
    [Parameter(Mandatory=$true)][String]$NewUserListName,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the List Item ID')][Alias('Id')][int]$ListItemId,
    [Parameter(Mandatory=$false)][String]$FileName
    )

	$htConn = Get-AutomationConnection -Name $SPConnection
    Write-Output "SharePoint Site URL: $($htconn.SharePointSiteURL)"

	Write-Verbose "Deleting `"$FileName`" from List Item (ID: $ListItemId)."
	$DeleteFile = InlineScript
	{
		Import-Module SharePointSDK
		$bFileDeleted = Remove-SPListItemAttachment -SPConnection $USING:htConn -ListName $USING:NewUserListName -ListItemID $USING:ListItemId -FileName $USING:FileName
		$bFileDeleted
	}
	Write-Output "Number of files deleted: $DeleteFile"
}