Workflow Populate-OnPremMPCatalog
{
    Param(
    [Parameter(Mandatory=$true)][String]$SharepointSiteURL,
    [Parameter(Mandatory=$true)][String]$SavedCredentialName,
    [Parameter(Mandatory=$true)][String]$ListName,
    [Parameter(Mandatory=$false)][Boolean]$NotifyByEmail = $false,
    [Parameter(Mandatory=$false)][String]$ContactName
    )

    # Get the credential to authenticate to the SharePoint List with
    $credential = Get-AutomationPSCredential -Name $SavedCredentialName

    # combined uri

    #SharePoint 2013
    $ListItemsUri = [System.String]::Format("{0}/_api/web/lists/getbytitle('{1}')/items?`$top=5000",$SharepointSiteURL, $ListName)
    $ListUri = [System.String]::Format("{0}/_api/web/lists/getbytitle('{1}')",$SharepointSiteURL, $ListName)

    #Get ListItemEntityTypeFullName
    $List = Invoke-RestMethod -uri $ListUri -credential $Credential
    $ListItemEntityTypeFullName = $list.entry.content.properties.ListItemEntityTypeFullName

    #Translating Field display names (title) to the internal names
    
    $htFieldNames = inlinescript {
        $arrDisplayNames = @('System Name', 'Categories', 'Catalog Item Id', 'MP Version', 'Public Key', 'Version Independent GUID', 'Download Link', 'Release Date')
        $htFieldNames = @{}
        Foreach ($item in $arrDisplayNames)
        {
            $FieldFilter = "Title eq '$item'"
            $ListFieldUri = "$USING:ListUri`/Fields?`$Filter=$FieldFilter"
            $ListField = Invoke-RestMethod -Uri $ListFieldUri -Credential $USING:credential
            $InternalName = $ListField.Content.properties.InternalName
            if ($InternalName.count -gt 1)
            {
                $InternalName = $InternalName[0]
            }
            $FieldInternalName = $InternalName
            $htFieldNames.Add($item, $FieldInternalName)
        }
        $htFieldNames
    }
    Write-verbose "SharePoint List Field Names: $htFieldNames"
    
    #Retrieve all MPs from Microsoft catalog
    $arrMPs = Get-MSMPCatalog
    Write-Output "Number of MPs currently in the Microsoft Catalog: $($arrMPs.count)."
    #Add MP to the on-prem catalog
    $arrCatalogItemIDs = inlinescript
    {
        $arrCatalogItemIDs = New-Object System.Collections.ArrayList
        
        $CatalogItemIDField = $USING:htFieldNames.'Catalog Item ID'
        $listItems = Invoke-RestMethod -Uri $Using:ListItemsUri -Credential $Using:credential
        foreach($li in $listItems)
        {
            $CatalogItemID = [string]$li.content.properties.$CatalogItemIDField
            [void]$arrCatalogItemIDs.Add($CatalogItemID)
        }
        $arrCatalogItemIDs
    }
    Write-Output "Number of MPs currently in the On-Prem catalog: $($arrCatalogItemIDs.count)"
    Write-Verbose "Start looping through all the MPs retrieved from Microsoft to find existing ones"
    #$arrMPsToAdd = inlinescript
    #{ 
        $arrMpsToAdd = @()
        Foreach ($MP in $arrMPs)
        {
            if (!($arrCatalogItemIDs.contains($MP.CatalogItemId)))
            {
                if ($MP.CatalogItemId.length -gt 0)
                {
                    $arrMPsToAdd += $MP
                    Write-Verbose "$($MP.SystemName), $($MP.CatalogItemId)"
                }
            }
        }
        #$arrMPsToAdd
    #}
    Write-Output "Number of MPs to be added to the On-Prem catalog: $($arrMPsToAdd.count)"

    #Adding MPs to the On-Prem catalog
    $arrAddedMPs = @()

    $ContextInfoUri = "$SharepointSiteURL`/_api/contextinfo"
    $RequestDigest = (Invoke-RestMethod -Method Post -Uri $ContextInfoUri -Credential $credential).GetContextWebInformation.FormDigestValue
    Foreach ($MP in $arrMPsToAdd)
    {
        $bodyString = "$($htFieldNames.'System Name')`: '$($MP.SystemName)', $($htFieldNames.'Categories')`: '$($MP.Categories)', $($htFieldNames.'Catalog Item Id')`: '$($MP.CatalogItemId)', $($htFieldNames.'MP Version')`: '$($MP.Version)', $($htFieldNames.'Public Key')`: '$($MP.PublicKey)', $($htFieldNames.'Version Independent GUID')`: '$($MP.VersionIndependentGuid)', $($htFieldNames.'Download Link')`: '$($MP.DownloadLink)', $($htFieldNames.'Release Date')`: '$($MP.ReleaseDate)'"
        #Write-Verbose $bodyString
        $body = "{ '__metadata': { 'type': '$ListItemEntityTypeFullName' }, $bodyString}"
        Write-Verbose $body
        $headers =@{
         accept = "application/json;odata=verbose"
         "X-RequestDigest" = $RequestDigest
         "If-Match" = "*"
        }
        Try {
            $AddMP = Invoke-RestMethod -Method POST -Uri $ListItemsUri -Body $body -ContentType "application/json;odata=verbose" -Headers $headers -Credential $credential
            $arrAddedMPs += "$($MP.SystemName)- Version: $($MP.Version), Release Date: $($MP.ReleaseDate)"
        } Catch {
            Write-Error "Unable to insert MP $($MP.SystemName)`(Version: $($MP.version), Catalog Item ID: $($MP.CatalogItemId)`) into the On-Prem MP catalog."
            Write-Error "REST request body: $body"
        }
    }
    
    #Send Email Notification if new MPs are added to the catalog
    #Using Customised SMA Email integration module(http://blog.tyang.org/2014/10/31/simplified-way-send-emails-mobile-push-notifications-sma/)
    if ($NotifyByEmail -and $arrAddedMPs.count -gt 0)
    {
        if (!$ContactName)
        {
            Write-Error "Contact name for receiving the notification email is not specified."
        } else {
            Write-Verbose "Getting SMA Address Book entry for $ContactName"
	        $Contact = Get-AutomationConnection -Name $ContactName
	
	        #Get SMTP settings
	        Write-Verbose "Getting SMTP configuration"
	        $SMTPSettings = Get-AutomationConnection -Name GmailSMTP

            #Email message
            Write-Verbose 'Sending email'
            $strAddedMPs = [string]::Join("`n", $arrAddedMPs)
            $Subject = "Additional Management Packs have been added to On-Prem MP Catalog"
            $Message = "$($arrAddedMPs.count) Management Pack(s) added to the On-Prem Catalog." + "`n" + $strAddedMPs
	        Send-Email -SMTPSettings $SMTPSettings -To $Contact.Email -Subject $Subject -Body $Message -HTMLBody $false
        }
    }
    Write-Output "Done. $($arrAddedMPs.count) Management Pack(s) added to the On-Prem Catalog."
}