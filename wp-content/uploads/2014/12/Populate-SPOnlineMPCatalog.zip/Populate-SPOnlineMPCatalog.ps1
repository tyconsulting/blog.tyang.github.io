Workflow Populate-SPOnlineMPCatalog
{
    Param(
    [Parameter(Mandatory=$true,HelpMessage='Please specify the SharePointOnline SMA Connection name')][Alias('Connection','c')][string]$SPOConnection,
    [Parameter(Mandatory=$true)][String]$ListName,
    [Parameter(Mandatory=$false)][Boolean]$NotifyByEmail = $false,
    [Parameter(Mandatory=$false)][String]$ContactName
    )

    # Get the credential to authenticate to the SharePoint List with
    $htConn = Get-AutomationConnection -Name $SPOConnection
    $SharepointSiteURL = $htConn.SharePointSiteURL
    
    #Translating Field display names (title) to the internal names
    $ListFields = InlineScript
    {
        Import-Module SharePointOnline
        $ListFields = Get-SPOListFields -SPOConnection $USING:htConn -ListName $USING:ListName
        $ListFields
    } 
    $SystemNameField = ($ListFields | Where-Object {$_.Title -ieq 'System Name' -and $_.ReadOnlyField -eq $false}).InternalName
    $CategoriesField = ($ListFields | Where-Object {$_.Title -ieq 'Categories' -and $_.ReadOnlyField -eq $false}).InternalName
    $CatalogItemIDField = ($ListFields | Where-Object {$_.Title -ieq 'Catalog Item ID' -and $_.ReadOnlyField -eq $false}).InternalName
    $MPVersionField = ($ListFields | Where-Object {$_.Title -ieq 'MP Version' -and $_.ReadOnlyField -eq $false}).InternalName
    $PublicKeyField = ($ListFields | Where-Object {$_.Title -ieq 'Public Key' -and $_.ReadOnlyField -eq $false}).InternalName
    $VersionIndependentGUIDField = ($ListFields | Where-Object {$_.Title -ieq 'Version Independent GUID' -and $_.ReadOnlyField -eq $false}).InternalName
    $DownloadLinkeField = ($ListFields | Where-Object {$_.Title -ieq 'Download Link' -and $_.ReadOnlyField -eq $false}).InternalName
    $ReleaseDateField = ($ListFields | Where-Object {$_.Title -ieq 'Release Date' -and $_.ReadOnlyField -eq $false}).InternalName

    #Retrieve all MPs from Microsoft catalog
    $arrMPs = Get-MSMPCatalog
    Write-Output "Number of MPs currently in the Microsoft Catalog: $($arrMPs.count)."
    
    #Get existing items from the SharePoint Online MP catalog
    $ExistingListItems = InlineScript
    {
        Import-Module SharePointOnline
        $ExistingListItems = Get-SPOListItems -SPOConnection $USING:htConn -ListName $USING:ListName
        $ExistingListItems
    }

    #Add Catalog Item IDs of the existing Items to an arraylist
    $arrCatalogItemIDs = InlineScript
    {
        $arrCatalogItemIDs = New-Object System.Collections.ArrayList
        foreach($li in $USING:ExistingListItems)
        {
            [void]$arrCatalogItemIDs.Add($li.$USING:CatalogItemIDField)
        }
        $arrCatalogItemIDs
    }
    Write-Output "Number of MPs currently in the SharePoint catalog: $($arrCatalogItemIDs.count)"

    #Determine which MPs to add to the SharePoint MP catalog
    Write-Verbose "Start looping through all the MPs retrieved from Microsoft to find existing ones"
    $arrMpsToAdd = @()
    Foreach ($MP in $arrMPs)
    {
        if (!($arrCatalogItemIDs.contains($MP.CatalogItemId)))
        {
            if ($MP.CatalogItemId.length -gt 0)
            {
                $arrMPsToAdd += $MP
            }
        }
    }
    Write-Output "Number of MPs to be added to the SharePoint Online catalog: $($arrMPsToAdd.count)"

    #Adding MPs to the SharePoint catalog
    Write-Verbose "Start adding MPs to the list $ListName on SharePoint site $SharepointSiteURL"
    $arrAddedMps = InlineScript
    {
        $arrAddedMPs = @()
        Import-Module SharePointOnline
        Foreach ($MP in $USING:arrMPsToAdd)
        {
            #Prepare a hash table that contains the MP information
            $htMPDetails = @{
                $USING:SystemNameField = $MP.SystemName
                $USING:CategoriesField = $MP.Categories
                $USING:CatalogItemIDField = $MP.CatalogItemId
                $USING:MPVersionField = $MP.Version
                $USING:PublicKeyField = $MP.PublicKey
                $USING:VersionIndependentGUIDField = $MP.VersionIndependentGuid
                $USING:DownloadLinkeField = $MP.DownloadLink
                $USING:ReleaseDateField = $MP.ReleaseDate
            }
            #Add the MP information (hash table) to the SharePoint List  
            $MPAdded= Add-SPOListItem -SPOConnection $USING:htConn -ListName $USING:ListName -ListFieldsValues $htMPDetails
            If ($MPAdded -eq $true)
            {
                $arrAddedMPs += "$($MP.SystemName)- Version: $($MP.Version), Release Date: $($MP.ReleaseDate)"
            }
        }
        $arrAddedMPs
    }
    
    #Send Email Notification if new MPs are added to the catalog
    #Using Customised SMA Email integration module(http://blog.tyang.org/2014/10/31/simplified-way-send-emails-mobile-push-notifications-sma/)
    if ($NotifyByEmail -and $arrAddedMPs.count -gt 0)
    {
        if (!$ContactName)
        {
            Write-Error "Contact name for receiving the notification email is not specified."
        } else {
            Write-Verbose "Getting SMA Address Book entry for $ContactName"
	        $Contact = Get-AutomationConnection -Name $ContactName
	
	        #Get SMTP settings
	        Write-Verbose "Getting SMTP configuration"
	        $SMTPSettings = Get-AutomationConnection -Name 'OutlookSMTP'

            #Email message
            Write-Verbose 'Sending email'
            $strAddedMPs = [string]::Join("`n", $arrAddedMPs)
            $Subject = "Additional Management Packs have been added to SharePoint MP Catalog"
            $Message = "$($arrAddedMPs.count) Management Pack(s) added to the SharePoint List." + "`n" + $strAddedMPs
	        Send-Email -SMTPSettings $SMTPSettings -To $Contact.Email -Subject $Subject -Body $Message -HTMLBody $false
        }
    }
    Write-Output "Done. $($arrAddedMPs.count) Management Pack(s) added to the SharePoint List."
}