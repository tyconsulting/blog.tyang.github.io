Param($globalSelectedItems)
$dataObject = $ScriptContext.CreateInstance("xsd://Microsoft.SystemCenter.Visualization.Component.Library!Microsoft.SystemCenter.Visualization.Component.Library.WebBrowser.Schema/Request")
$dataObject["BaseUrl"]="http://maps.google.com/maps"
$parameterCollection = $ScriptContext.CreateCollection("xsd://Microsoft.SystemCenter.Visualization.Component.Library!Microsoft.SystemCenter.Visualization.Component.Library.WebBrowser.Schema/UrlParameter[]")
foreach ($globalSelectedItem in $globalSelectedItems)
{
$globalSelectedItemInstance = Get-SCOMClassInstance -Id $globalSelectedItem["Id"]
$DNSNameProperty = $globalSelectedItemInstance.GetMonitoringProperties() | Where-Object {$_.name -match "^DNSName$"}
$DNSName = $globalSelectedItemInstance.GetMonitoringPropertyValue($DNSNameProperty)

#Get Coordinates via WinRM

#Create a WinRM session to the remote computer
$RemoteSession = New-PSSession -ComputerName $DNSName
$objRemoteLoc = Invoke-command -scriptblock {
# Windows Location API
$mylocation = new-object -comObject LocationDisp.LatLongReportFactory
$mylocation.ListenForReports(1000)
Start-Sleep -Seconds 1
# Get Status
$mylocationstatus = $mylocation.status

#try again if first attemp is not successful
if ($mylocationstatus -ne 4)
{
Remove-Variable mylocation
Start-Sleep -Seconds 1
$mylocation = new-object -comObject LocationDisp.LatLongReportFactory
$mylocationstatus = $mylocation.status
}
If ($mylocationstatus -eq 4)
{
# Windows Location Status returns 4, so we're "Running"
# Get Latitude and Longitude from LatlongReport property
$latitude = $mylocation.LatLongReport.Latitude
$longitude = $mylocation.LatLongReport.Longitude
$altitude = $mylocation.LatLongReport.altitude
$errorRadius = $mylocation.LatLongReport.ErrorRadius
}
 
#Pass invalid values if location is not detected
If ($latitude -eq $null -or $longitude -eq $null)
{
$bValidLoc = $false
} else {
$bValidLoc = $true
}
    
#Return Data
$objLoc = New-Object psobject
Add-Member -InputObject $objLoc -membertype noteproperty -name "ValidLocation" -value $bValidLoc
Add-Member -InputObject $objLoc -membertype noteproperty -name "LocationStatus" -value $mylocationstatus
Add-Member -InputObject $objLoc -membertype noteproperty -name "latitude" -value $latitude
Add-Member -InputObject $objLoc -membertype noteproperty -name "longitude" -value $longitude
Add-Member -InputObject $objLoc -membertype noteproperty -name "altitude" -value $altitude
Add-Member -InputObject $objLoc -membertype noteproperty -name "errorRadius" -value $errorRadius
$objLoc
} -Session $RemoteSession
$latitude = $objRemoteLoc | select -ExpandProperty latitude
$longitude = $objRemoteLoc | select -ExpandProperty longitude
$ValidLocation = $objRemoteLoc | select -ExpandProperty ValidLocation
$parameter = $ScriptContext.CreateInstance("xsd://Microsoft.SystemCenter.Visualization.Component.Library!Microsoft.SystemCenter.Visualization.Component.Library.WebBrowser.Schema/UrlParameter")
$parameter["Name"] = "q"
$parameter["Value"] = "loc:" + $latitude + "+" + $longitude
$parameterCollection.Add($parameter)
Remove-PSSession $RemoteSession
}
$dataObject["Parameters"]= $parameterCollection
$ScriptContext.ReturnCollection.Add($dataObject)
