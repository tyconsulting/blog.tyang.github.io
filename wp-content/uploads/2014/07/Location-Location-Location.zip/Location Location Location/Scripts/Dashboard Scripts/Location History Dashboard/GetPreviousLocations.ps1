Param($globalSelectedItems)

$i = 1
foreach ($globalSelectedItem in $globalSelectedItems)
{
    $MonitoringObjectID = $globalSelectedItem["Id"]
    $MG = Get-SCOMManagementGroup
    $globalSelectedItemInstance = Get-SCOMClassInstance -Id $MonitoringObjectID
    $Computername = $globalSelectedItemInstance.DisplayName
    $strInstnaceCriteria = "FullName='Microsoft.Windows.Computer:$Computername'"
    $InstanceCriteria = New-Object Microsoft.EnterpriseManagement.Monitoring.MonitoringObjectGenericCriteria($strInstnaceCriteria)
    $Instance = $MG.GetMonitoringObjects($InstanceCriteria)[0]
    $Events = Get-SCOMEvent -instance $Instance -EventId 10001 -EventSource "LocationMonitoring" | Where-Object {$_.Parameters[1] -eq 4} |Sort-Object TimeAdded -Descending | Select -First 50
    foreach ($Event in $Events)
    {
        $EventID = $Event.Id.Tostring()
        $LocalTime = $Event.Parameters[0]
        $LocationStatus = $Event.Parameters[1]
        $Latitude = $Event.Parameters[2]
        $Longitude = $Event.Parameters[3]
        $Altitude = $Event.Parameters[4]
        $ErrorRadius = $Event.Parameters[5].trimend(".")
        
        $dataObject = $ScriptContext.CreateInstance("xsd://foo!bar/baz")
        $dataObject["Id"]=$EventID
        $dataObject["No"]=$i
        $dataObject["LocalTime"]=$LocalTime
        $dataObject["Latitude"]=$Latitude
        $dataObject["Longitude"]=$Longitude
        $dataObject["Altitude"]=$Altitude
        $dataObject["ErrorRadius (Metres)"]=$ErrorRadius
        $ScriptContext.ReturnCollection.Add($dataObject)
        $i++
    } 
}
