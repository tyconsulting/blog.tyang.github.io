function Start-Lab {
<# 
 .Synopsis
  Start All Physical And Virtual Machines in My Home Lab

 .Description
  Starts all physical and virtual machines in my home lab in a preconfigured order


 .Example
   # Start lab computers
   Start-Lab

#>
    Invoke-Expression 'D:\Scripts\LabAdmin\Start-Lab.ps1'
}

function Stop-Lab {
<# 
 .Synopsis
  Shutdown All Physical And Virtual Machines in My Home Lab

 .Description
  Shutdown all physical and virtual machines in my home lab in a preconfigured order


 .Example
   # Shutdown lab computers
   Stop-Lab

#>
    Invoke-Expression 'D:\Scripts\LabAdmin\Stop-Lab.ps1'
}
