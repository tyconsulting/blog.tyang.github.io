#============================================================
# AUTHOR:	Tao Yang 
# DATE:		04/04/2014
# Name:		Stop-Lab.PS1
# Version:	0.1
# COMMENT:	Script to shut down all computers in my home lab
#============================================================

$thisScript = $MyInvocation.MyCommand.path
$scriptRoot = split-path (Resolve-Path $thisScript)

#Load LabConfig.xml
$configXml = Join-Path $scriptRoot "LabConfig.xml"
$xml = [xml](Get-Content $configXml)
$bWOLSent = $false
$arrLabMembers = New-Object System.Collections.ArrayList
$arrPSSessionIds = New-Object System.Collections.ArrayList
Clear-Host

#region FunctionLib
function Get-CurrentUser
{
    $me = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    Return $me
}

function Validate-Credential($Cred)
{
    $UserName = $Cred.Username
    $Password = $Cred.GetNetworkCredential().Password
    Add-Type -assemblyname System.DirectoryServices.AccountManagement
    $DS = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine)
    Try {
        $ValidCredential = $DS.ValidateCredentials($UserName, $Password)
    } Catch {
        #if the account does not have required logon rights to the local machine, validation failed.
        $ValidCredential = $false
    }
    Return $ValidCredential
}

function Check-GroupMembership ([string]$GroupName)
{
    $CurrentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $WindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($CurrentUser)
    if($WindowsPrincipal.IsInRole($GroupName))
    {
        $bIsMember = $true
    } else {
        $bIsMember = $false
    }
    return $bIsMember
}


Function Ping-Check($computer, $iPingRetryWait, $iPingRetryTimes)
{
	$bPing = $false
	$ping = New-Object Net.NetworkInformation.Ping
    #ping with timeout setting of 1 second
	$PingResult = $ping.send($computer, 1000)
	if ($PingResult.Status.Tostring().ToLower() -eq "success")
	{
		$bPing = $true
	} else {
		#if first attemp failed, wait for number of seconds that's defined in XML file and try again
		Start-Sleep $iPingRetryWait
		#attemp to ping few more times (defined in XML file)
		For ($i=1; $i -le $iPingRetryTimes; $i++)
		{
			$PingResult = $ping.send($computer)
			if ($PingResult.Status.Tostring().ToLower() -eq "success")
			{
				$bPing = $true
			}
		}
		
	}
	return $bPing
}

Function Shutdown-PhysicalComputer ($ComputerName, $iTimeout, $cred)
{
    $ShutdownJob = Stop-Computer -ComputerName $ComputerName -Force -AsJob -Credential $cred
    For ($i = 1; $i -le $iTimeout; $i++)
    {
        $ShutdownJob | Receive-Job
        if ($ShutdownJob.State -ieq "Completed" -and (!(Ping-Check $computerName 0 0)))
        {
            #shutdown completed, no need to wait anymore
            $i = $iTimeout
        } else {
            Start-Sleep -seconds 1
            Write-Host "." -NoNewline
        }
    }
    Write-Host ""
    #Double check again
    $pingCheck = Ping-Check $ComputerName 0 3
    $Result = !$pingCheck
    $Result
}

#endregion

#region Main
#Make sure the user is authorised to run this script
$AuthorizedGroup = $xml.Configuration.AuthorizedGroup
Write-Host "Warning: Only member of `'$AuthorizedGroup`' has access to perform this operation!" -ForegroundColor Yellow
If (!(Check-GroupMembership $AuthorizedGroup))
{
    #Not in the group, exit straightaway
    Write-Host "You are not authorised to start anything in my lab!" -ForegroundColor Red
    Exit
}
#First of all, users need to enter password again for CredSSP
$me = Get-CurrentUser

$MyCred = Get-Credential -UserName $me -Message "Please enter your password for CredSSP (Second Hop):"
#Validate Credential
Write-Host "Validating your credential..."
If (!(Validate-Credential $MyCred))
{
    Write-Host "Invalid crendential specified. Script Aborted!" -ForegroundColor Red
    Exit
} else {
    Write-Host "The credential is valid. continuing...." -ForegroundColor Green
}

#Read list of lab physical computers from xml
$arrPhysicalComputers = $xml.Configuration.PhysicalComputers.PhysicalComputer

Foreach ($item in $arrPhysicalComputers)
{
    Write-Host "Checking $($item.ComputerName)`..." -ForegroundColor Green
    if ([System.Convert]::ToBoolean($item.LabMember))
    {
        #This computer is a lab member, check if it's currently online

        Write-Host " - Pinging $($item.ComputerName)..." -ForegroundColor Green
        if (Ping-Check $($item.ComputerName) 1 3)
        {
            #Currently Online, add it to $arrLabMembers array to process later
            [Void]$arrLabMembers.Add($item)
        } else {
            Write-Host " - Skipping $($item.ComputerName) because it is currently offline." -ForegroundColor Yellow
        }
    } else {
        Write-Host " - Skipping $($item.ComputerName) because it is not part of the lab!" -ForegroundColor Yellow
    }
}
Write-Host ""

#start shutting down lab computers
If ($arrLabMembers.count -gt 0)
{
    Foreach ($labmember in $arrLabMembers)
    {
        [int]$iTimeout = $labmember.ShutdownTimeout
        If ($labmember.Role -ine "HYPERV")
        {
            #perform normal shutdown
            Write-Host "Shutting down Non-HyperV computer $($labmember.ComputerName)`..."
            
            $ShutdownResult = Shutdown-PhysicalComputer $($labmember.ComputerName) $iTimeout $MyCred
            If ($ShutdownResult)
            {
                Write-Host " - $($labmember.ComputerName) is now powered off!" -ForegroundColor Green
            } else {
                Write-Host " - Failed to shutdown $($labmember.ComputerName), it still responding to Ping. Please check manually." -ForegroundColor Red
            }
        } else {
            #For Hyper-V servers, need to shutdown VM's first.
            #Create a WinRM session
            Write-Host "Creating a WinRM session for Hyper-V server $($Labmember.ComputerName)..." -ForegroundColor Green
            $HyperVHostName = $($Labmember.ComputerName).split(".")[0] #in case name is FQDN
        
            $PSSessionID = (New-PSSession -ComputerName $HyperVHostName -Credential $MyCred).Id
            #Keep record of all PSSessions this script creates
            [Void]$arrPSSessionIds.Add($PSSessionId)
            #Shutdown All VMs from this Hyper-V box
            Write-Host "Entering remote session for $HyperVHostName to shutdown VM's..."
            $VMsAllOff = Invoke-Command -Session (Get-PSSession -id $PSSessionID) -ScriptBlock {
                #region functionlib
                Function Get-ShutdownOrder ($VMName)
                {
                    #CentOS routers must shutdown last
                    If ($VMName -imatch "RT0[1-9]$")
                    {
                        [int]$ShutdownOrder = 4
                    } elseif ($VMName -imatch "^AD0")
                    {
                        #Domain controllers second last
                        [int]$ShutdownOrder = 3
                    } elseif ($VMName -imatch "SQL" -or $VMName -imatch "DB" -or $VMName -imatch "[PS]SS")
                    {
                        #SQL and ConfigMgr site servers (because SQL is installed on site servers) before domain controllers
                        [int]$ShutdownOrder = 2
                    } elseif ($VMName -inotmatch "^OpsMgrMS")
                    {
                        #all other VMs except OpsMgr managmenet servers before domain SQL
                        [int]$ShutdownOrder = 1
                    } else {
                        #OpsMgr management servers must be shutdown first so we don't get flooded with alerts
                        [int]$ShutdownOrder = 0
                    }
                    $ShutdownOrder
                }

                Function Shutdown-VMs ([System.Collections.ArrayList]$Batch, [int]$iTimeout)
                {
                    $ShutdownJobs = $Batch | stop-vm -AsJob -Force
                    
                    For ($i = 1; $i -le $iTimeout; $i++)
                    {
                        $ShutdownJobs | Receive-Job
                        $bAllJobCompleted = $true
                        Foreach ($job in $ShutdownJobs)
                        {
                            if ($job.State -ine "Completed")
                            {
                                $bAllJobCompleted = $false
                            }
                        }
                        if ($bAllJobCompleted)
                        {
                            #Check VM state to be sure
                            $bAllVMsOff = $true
                            $VMs = $Batch |Get-VM
                            Foreach ($VM in $VMs)
                            {
                                if ($VM.state -ine "off")
                                {
                                    $bAllVMsOff = $false
                                }
                            }

                            if (!($bAllVMsOff))
                            {
                                #continue to wait
                                Start-Sleep -seconds 1
                                Write-Host "." -NoNewline
                            } else {
                                #shutdown completed, no need to wait anymore
                                $i = $iTimeout
                            }
                        } else {
                            Start-Sleep -seconds 1
                            Write-Host "." -NoNewline
                        }
                    }
                    Write-Host ""
                    #display result
                    $VMs = $Batch |Get-VM
                    Foreach ($VM in $VMs)
                    {
                        Write-Host " - $($VM.VMName)`: $($VM.state)"
                    }
                    #return result
                    $bAllVMsOff
                }

                #endregion

                #Load Hyper-V module if required
                if (!(get-module Hyper-V)) {import-module Hyper-V}

                #Get All VMs that are not currently not at the off state
                #categorise them by shutdown order
                $Batch0 = New-Object System.Collections.ArrayList
                $Batch1 = New-Object System.Collections.ArrayList
                $Batch2 = New-Object System.Collections.ArrayList
                $Batch3 = New-Object System.Collections.ArrayList
                $Batch4 = New-Object System.Collections.ArrayList

                Foreach ($VM in (Get-VM | Where-Object {$_.state -ine "off"}))
                {
                    [int]$ShutdownOrder = Get-ShutdownOrder $($VM.VMName)
                    switch ($ShutdownOrder)
                    {
                        0{[void]$Batch0.Add($VM)}
                        1{[void]$Batch1.Add($VM)}
                        2{[void]$Batch2.Add($VM)}
                        3{[void]$Batch3.Add($VM)}
                        4{[void]$Batch4.Add($VM)}
                        default {[void]$Batch1.Add($VM)}
                    }

                }

                #Shutdown Batch 0
                If ($Batch0.Count -gt 0)
                {
                    Write-Host "Shutting down VMs in Batch 0, $($Batch0.count) in total..."
                    $Batch0Result = Shutdown-VMs $Batch0 45
                    Write-Host " - Batch 0 all powered off: $Batch0Result"
                } else {
                    Write-Host "No virtual machines in Batch 0, skipped."
                    $Batch0Result = $true
                }
                
                #Shutdown Batch 1
                If ($Batch1.Count -gt 0)
                {
                    Write-Host "Shutting down VMs in Batch 1, $($Batch1.count) in total..."
                    $Batch1Result = Shutdown-VMs $Batch1 45
                    Write-Host " - Batch 1 all powered off: $Batch1Result"
                } else {
                    Write-Host "No virtual machines in Batch 1, skipped."
                    $Batch1Result = $true
                }
                Write-Host ""

                #Shutdown Batch 2
                If ($Batch2.Count -gt 0)
                {
                    Write-Host "Shutting down VMs in Batch 2, $($Batch2.count) in total..."
                    $Batch2Result = Shutdown-VMs $Batch2 45
                    Write-Host " - Batch 2 all powered off: $Batch2Result"
                } else {
                    Write-Host "No virtual machines in Batch 2, skipped."
                    $Batch2Result = $true
                }
                Write-Host ""

                #Shutdown Batch 3
                If ($Batch3.Count -gt 0)
                {
                    Write-Host "Shutting down VMs in Batch 3, $($Batch3.count) in total..."
                    $Batch3Result = Shutdown-VMs $Batch3 45
                    Write-Host " - Batch 3 all powered off: $Batch3Result"
                } else {
                    Write-Host "No virtual machines in Batch 3, skipped."
                    $Batch3Result = $true
                }
                Write-Host ""

                #Shutdown Batch 4
                If ($Batch1.Count -gt 0)
                {
                    Write-Host "Shutting down VMs in Batch 4, $($Batch4.count) in total..."
                    $Batch4Result = Shutdown-VMs $Batch4 45
                    Write-Host " - Batch 4 all powered off: $Batch4Result"
                } else {
                    Write-Host "No virtual machines in Batch 4, skipped."
                    $Batch4Result = $true
                }
                Write-Host ""

                If (!($Batch0Result) -or !($Batch1Result) -or !($Batch2Result) -or !($Batch3Result) -Or !($Batch4Result))
                {
                    #There are still some VMs running, Wait for 10 seconds then force turn off
                    Write-Host "Some VM's are still running. Wait for 10 seconds to kill 'em all!" -ForegroundColor Yellow
                    For ($i = 1; $i -le 10; $i++)
                    {
                        Write-Host "." -NoNewline
                        Start-Sleep -seconds 1
                    }
                    Write-Host "TURN OFF running VMs..."
                    $ToBeKilled = Get-VM | Where-Object {$_.state -ine "off"}
                    Write-host "These VMs are going to be killed (Turned off):"
                    Foreach ($item in $ToBeKilled)
                    {
                        Write-Host " - $($item.VMName)"
                    }
                    $ToBeKilled | Stop-VM -TurnOff
                    #give it another 30 seconds
                    $bAllOff = $false
                    For ($i = 1; $i -le 30; $i++)
                    {
                       if (Get-VM | Where-Object {$_.state -ine "off"})
                       {
                           Write-Host "." -NoNewline
                           Start-Sleep -seconds 1
                       } else {
                        $bAllOff = $true
                        $i = 30
                       }
                    }
                } else {
                    $bAllOff = $true
                }
                $bAllOff
            }
        
            if (!($VMsAllOff))
            {
                Write-Host "Warning: Some virtual machines could not be turned off. Will try to shutdown the Hyper-V server without shutting down all the VM's!" -ForegroundColor Yellow
            }
        
            #Shutdown the Hyper-V Host
            Write-Host "Shutting down HyperV server $($labmember.ComputerName)`..."
            $ShutdownResult = Shutdown-PhysicalComputer $($labmember.ComputerName) $iTimeout $MyCred
            If ($ShutdownResult)
            {
                Write-Host " - $($labmember.ComputerName) is now powered off!" -ForegroundColor Green
            } else {
                Write-Host " - Failed to shutdown $($labmember.ComputerName), it still responding to Ping. Please check manually." -ForegroundColor Red
            }
            }

    }
}
#House Clean
#Close previously opened PSSessions
If ($arrPSSessionIds.count -gt 0)
{
    Write-Host "Closing PS Sessions..."
    Foreach ($Id in $arrPSSessionIds)
    {
        Get-PSSession -Id $Id | Remove-PSSession
    }
}
Write-Host "All Done! Have fun!" -ForegroundColor Green
#endregion