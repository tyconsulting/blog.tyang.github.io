#============================================================
# AUTHOR:	Tao Yang 
# DATE:		04/04/2014
# Name:		Start-Lab.PS1
# Version:	0.1
# COMMENT:	Script to start up all computers in my home lab
#============================================================

$thisScript = $MyInvocation.MyCommand.path
$scriptRoot = split-path (Resolve-Path $thisScript)

#Load LabConfig.xml
$configXml = Join-Path $scriptRoot "LabConfig.xml"
$xml = [xml](Get-Content $configXml)
$bWOLSent = $false
$arrLabMembers = New-Object System.Collections.ArrayList
Clear-Host

#region FunctionLib
function Get-CurrentUser
{
    $me = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    Return $me
}

function Validate-Credential($Cred)
{
    $UserName = $Cred.Username
    $Password = $Cred.GetNetworkCredential().Password
    Add-Type -assemblyname System.DirectoryServices.AccountManagement
    $DS = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine)
    Try {
        $ValidCredential = $DS.ValidateCredentials($UserName, $Password)
    } Catch {
        #if the account does not have required logon rights to the local machine, validation failed.
        $ValidCredential = $false
    }
    Return $ValidCredential
}

function Check-GroupMembership ([string]$GroupName)
{
    $CurrentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $WindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($CurrentUser)
    if($WindowsPrincipal.IsInRole($GroupName))
    {
        $bIsMember = $true
    } else {
        $bIsMember = $false
    }
    return $bIsMember
}

function Send-WOL {
    param(
        [string]$mac,
        [string]$ip,
        [int]$port=9
    )
    $broadcast = [Net.IPAddress]::Parse($ip)
 
    $mac=(($mac.replace(":","")).replace("-","")).replace(".","")
    $target=0,2,4,6,8,10 | % {[convert]::ToByte($mac.substring($_,2),16)}
    $packet = (,[byte]255 * 6) + ($target * 16)
 
    $UDPclient = new-Object System.Net.Sockets.UdpClient
    $UDPclient.Connect($broadcast,$port)
    [void]$UDPclient.Send($packet, 102)
}

Function Ping-Check($computer, $iPingRetryWait, $iPingRetryTimes)
{
	$bPing = $false
	$ping = New-Object Net.NetworkInformation.Ping
    #ping with timeout setting of 1 second
	$PingResult = $ping.send($computer, 1000)
	if ($PingResult.Status.Tostring().ToLower() -eq "success")
	{
		$bPing = $true
	} else {
		#if first attemp failed, wait for number of seconds that's defined in XML file and try again
		Start-Sleep $iPingRetryWait
		#attemp to ping few more times (defined in XML file)
		For ($i=1; $i -le $iPingRetryTimes; $i++)
		{
			$PingResult = $ping.send($computer)
			if ($PingResult.Status.Tostring().ToLower() -eq "success")
			{
				$bPing = $true
			}
		}
		
	}
	return $bPing
}

Function Check-OSReadiness ($Computername, $MinUpTimeSeconds,$arrCriticalServices, $cred)
{
    #Firstly, assume OS is ready
    $bReady = $true

    ##Test connection to Admin$ Share - Comment out, doesn't work in PSWA because Test-path doesn't like -Credential and won't work due to second hop.
    #$AdminShare = "`\`\$Computername`\Admin`$"
    #If (!(Test-Path $AdminShare -Credential $cred))
    #{
    #   $bReady = $false
    #}

    #Then try to query Win32_OperatingSystem class and calculate system uptime - only when test connection to Admin$ share is successful.
    if($bReady)
    {
        Try
        {
            $wmiOS = Get-WmiObject Win32_OperatingSystem -ComputerName $Computername -Credential $cred
            $SysUpTime = $wmiOS.ConvertToDateTime($wmiOS.LocalDateTime) - $wmiOS.ConvertToDateTime($wmiOS.LastBootupTime)
            $SysUpSeconds = [system.convert]::ToInt32($($sysUpTime.TotalSeconds))
            If ($SysUpSeconds -lt $MinUpTimeSeconds)
            {
                $bReady = $false
            }
        } Catch {
            $bReady = $false
        }
    }

    #Lastly, if System Up time is longer than configured minimum up time, query each critical services, start them if they are not started
    if ($bReady)
    {
        Foreach ($Service in $arrCriticalServices)
        {
            #Check Service State
            Try
            {
                $WmiService = Get-WmiObject Win32_Service -Filter "Name = '$Service'" -ComputerName $Computername -Credential $cred
                if ($WmiService)
                {
                    #Service exists
                    #Write-Host "$service exists"
                    #Write-Host "$($WmiService.state)"
                    If ($WmiService.state -ine "running" -and $WmiService.state -ine "start pending")
                    {
                        #service not running, try to start it
                        #Write-Host "$Service is not running. trying to start it"
                        If ($WmiService.StartMode -ine "disabled")
                        {
                            $WmiService.StartService()
                            $bReady = $false
                        }
                    }
                }
            } Catch {
                #Something wrong with remote WMI query
                $bReady = $false
            }
        }
    }
    $bReady
}

Function Start-VirtualMachine ($VMName, $PSSession)
{
    $StartResult = invoke-command -Session $PSSession -ScriptBlock {
        param ([string]$VMName)
        $VM = Get-VM | Where-object {$_.VMName -eq $VMName}
        $VM | Start-VM
        #wait 3 seconds then confirm if it's started
        Start-Sleep -Seconds 3
        If ($VM.State -ieq "running")
        {
            $bStarted = $true
        } else {
            $bStarted = $false
        }

        #return result
        $bStarted
    } -ArgumentList $VMName
    
    #Return Result
    $StartResult
}
#endregion

#region main
#Make sure the user is authorised to run this script
$AuthorizedGroup = $xml.Configuration.AuthorizedGroup
Write-Host "Warning: Only member of `'$AuthorizedGroup`' has access to perform this operation!" -ForegroundColor Yellow
If (!(Check-GroupMembership $AuthorizedGroup))
{
    #Not in the group, exit straightaway
    Write-Host "You are not authorised to start anything in my lab!" -ForegroundColor Red
    Exit
}
#First of all, users need to enter password again for CredSSP
$me = Get-CurrentUser

$MyCred = Get-Credential -UserName $me -Message "Please enter your password for CredSSP (Second Hop):"
#Validate Credential
Write-Host "Validating your credential..."
If (!(Validate-Credential $MyCred))
{
    Write-Host "Invalid crendential specified. Script Aborted!" -ForegroundColor Red
    Exit
} else {
    Write-Host "The credential is valid. continuing...." -ForegroundColor Green
}


#Read list of lab physical computers from xml
$arrPhysicalComputers = $xml.Configuration.PhysicalComputers.PhysicalComputer

Foreach ($item in $arrPhysicalComputers)
{
    Write-Host "Checking $($item.ComputerName)`..." -ForegroundColor Green
    if ([System.Convert]::ToBoolean($item.LabMember))
    {
        #This computer is a lab member, check if it's currently online
        #firstly add it to $arrLabMembers array to process later
        [Void]$arrLabMembers.Add($item)
        Write-Host " - Pinging $($item.ComputerName)..." -ForegroundColor Green
        if (!(Ping-Check $($item.ComputerName) 1 3))
        {
            Write-Host " - Sending Magic Packet to $($item.ComputerName) `(MAC: $($item.MAC), Broadcast IP: $($item.BroadcastIP)`)..." -ForegroundColor Green
            Send-WOL $($item.MAC) $($item.BroadcastIP)
            $bWOLSent = $true
        } else {
            Write-Host " - Skipping $($item.ComputerName) because it is currently online." -ForegroundColor Yellow
        }
    } else {
        Write-Host " - Skipping $($item.ComputerName) because it is not part of the lab!" -ForegroundColor Yellow
    }
}
Write-Host ""

#If sent any WOL magic packets, wait a while before connecting to the OS
If ($bWOLSent)
{
    [int]$WaitAfterWOLSeconds = $xml.Configuration.WaitAfterWOLSeconds
    Write-Host "Wait for $WaitAfterWOLSeconds seconds before continuing..."
    For ($i = 1; $i -le $WaitAfterWOLSeconds; $i++)
    {
        if ((($i/10).gettype()).name -ieq "int32")
        {
            Write-Host "$i" -NoNewline
        } else {
            Write-Host "." -NoNewline
        }
        Start-Sleep -Seconds 1
    }
}
Write-host ""

#Continue, only if $arrLabMembers array is not empty
#Create an array and when the computer is fully booted, add to this array
$arrFullyBooted = New-Object System.Collections.ArrayList
If ($arrLabMembers.Count -gt 0)
{
    #Maximum number of attempts for checking OS Readiness
    [int]$NumberOfAttempts = $xml.Configuration.OSReadinessCheck.NumberOfAttempts

    #Wait time in seconds between each attempts
    [int]$AttemptsWaitSeconds = $xml.Configuration.OSReadinessCheck.AttemptsWaitSeconds

    For ($i = 1; $i -le $NumberOfAttempts; $i++)
    {
        If ($arrFullyBooted.Count -lt $arrLabMembers.Count)
        {
            Foreach ($Labmember in $arrLabMembers)
            {
                #Only check for OS readiness if it's not yet fully booted
                if (!($arrFullyBooted.Contains($Labmember)))
                {
                    #Get Computer name
                    $LabMemberComputername = $Labmember.ComputerName
                    Write-Host "Checking $LabMemberComputerName Operating System's readiness..."
        
                    #Get allowed minimum uptime in seconds
                    [int]$MinUpTimeSeconds = $Labmember.MinUpTimeSeconds

                    #Add critical service names to an array
                    $arrCriticalServices = New-Object System.Collections.ArrayList
                    Foreach ($ServiceName in $Labmember.CriticalServices.ServiceName)
                    {
                        [void]$arrCriticalServices.Add($ServiceName)
                    }

                    #Check OS Readiness
                    $bOSReady = Check-OSReadiness $LabMemberComputername $MinUpTimeSeconds $arrCriticalServices $MyCred
            
                    if ($bOSReady)
                    {
                        Write-Host " - $LabMemberComputername is now fully started..." -ForegroundColor Green
                        [Void]$arrFullyBooted.Add($Labmember)
                    } else {
                        Write-Host " - $LabMemberComputername is not yet fully started..." -ForegroundColor Yellow
                    }
                }

            }
        }

        #Only continue to wait if there are still machines pending
        If ($arrFullyBooted.Count -lt $arrLabMembers.Count)
        {
            Write-Host "Wait for $AttemptsWaitSeconds seconds and check again"
            For ($iWait = 1; $iWait -le $AttemptsWaitSeconds; $iWait++)
            {
                Write-Host "." -NoNewline
                Start-Sleep -Seconds 1
            }
            Write-Host ""
        }
    }
    #Check if any machines still haven't fully booted
    Foreach ($item in $arrLabMembers)
    {
        If (!($arrFullyBooted.Contains($item)))
        {
            Write-Host "Error: It seems $($item.ComputerName) is not fully started. please manually check!" -ForegroundColor Red
        }
    }
}

#Continue starting up VM's on Hyper-V hosts
$arrHyperVHosts = New-Object System.Collections.ArrayList
$arrVMs = New-Object System.Collections.ArrayList
$arrIgnoredVMs = New-Object System.Collections.ArrayList
$arrPSSessionIds = New-Object System.Collections.ArrayList

Foreach ($item in $($xml.Configuration.IgnoredVMs.VMName).ToUpper())
{
    [void]$arrIgnoredVMs.Add($item)
}

Foreach ($Labmember in $arrFullyBooted)
{
    If ($Labmember.Role -imatch "HyperV")
    {
        #Create a WinRM session
        Write-Host "Creating a WinRM session for Hyper-V server $($Labmember.ComputerName)..." -ForegroundColor Green
        $HyperVHostName = $($Labmember.ComputerName).split(".")[0] #in case name is FQDN
        
        $PSSessionID = (New-PSSession -ComputerName $HyperVHostName -Credential $MyCred).Id
        #Keep record of all PSSessions this script creates
        [Void]$arrPSSessionIds.Add($PSSessionId)
        #Get all VMs that are not running hosted on this Hyper-V host
        $VMs = Invoke-Command -Session (Get-PSSession -id $PSSessionID) -ScriptBlock {
            param ([string]$PSSessionID)

            #region functionlib
            Function Get-StartOrder ($VMName)
            {
                #CentOS routers must start first
                If ($VMName -imatch "RT01$")
                {
                    [int]$StartOrder = 0
                } elseif ($VMName -imatch "^AD0")
                {
                    #Domain controllers starts next
                    [int]$startOrder = 1
                } elseif ($VMName -imatch "SQL" -or $VMName -imatch "DB" -or $VMName -imatch "[PS]SS")
                {
                    #SQL and ConfigMgr site servers (because SQL is installed on site servers) starts next
                    [int]$StartOrder = 2
                } elseif ($VMName -inotmatch "^OpsMgrMS")
                {
                    #all other VMs except OpsMgr managmenet servers starts next
                    [int]$StartOrder = 3
                } else {
                    [int]$StartOrder = 4
                }
                $StartOrder
            }
            #endregion

            #Load Hyper-V module if required
            if (!(get-module Hyper-V)) {import-module Hyper-V}

            #Get All VMs that are not currently at the off state
            $VMs = @()
            Foreach ($VM in (Get-VM | Where-Object {$_.state -ieq "off"}))
            {
                [int]$StartOrder = Get-StartOrder $($VM.VMName)
                $objVM = new-object psobject
                Add-Member -InputObject $objVM -MemberType NoteProperty -name "VMName" -value $VM.VMname
                Add-Member -InputObject $objVM -MemberType NoteProperty -name "StartOrder" -value $StartOrder
                Add-Member -InputObject $objVM -MemberType NoteProperty -name "PSSessionID" -value $PSSessionID
                $VMs += $objVM
            }


            ,$VMs
        } -ArgumentList $PSSessionID

        Foreach ($VM in $VMs)
        {
            #only add to the list if the VM is not on the ignored list
            If (!($arrIgnoredVMs.Contains($($VM.VMName).ToUpper())))
            {
                [void]$arrVMs.Add($VM)
            }
        }
        #add the Hyper-V host to an array and process later
        [void]$arrHyperVHosts.Add($Labmember)
    } else {
        Write-Host "$($Labmember.ComputerName) is not a Hyper-V server. Nothing else needs to be done!" -ForegroundColor Green
    }
}

#Workout the sequence to start VMs
If ($arrVMs.Count -gt 0)
{
    #Categorise VMs based on StartOrder
    #Any VMs whose start order is 0
    $Batch0 = New-Object System.Collections.ArrayList
    Foreach ($objVM in $arrVMs)
    {
        if ($objVM.StartOrder -eq 0)
        {
            [Void]$Batch0.Add($objVM)
        }
    }

    #Any VMs whose start order is 1
    $Batch1 = New-Object System.Collections.ArrayList
    Foreach ($objVM in $arrVMs)
    {
        if ($objVM.StartOrder -eq 1)
        {
            [Void]$Batch1.Add($objVM)
        }
    }

    #Any VMs whose start order is 2
    $Batch2 = New-Object System.Collections.ArrayList
    Foreach ($objVM in $arrVMs)
    {
        if ($objVM.StartOrder -eq 2)
        {
            [Void]$Batch2.Add($objVM)
        }
    }

    #Any VMs whose start order is 3
    $Batch3 = New-Object System.Collections.ArrayList
    Foreach ($objVM in $arrVMs)
    {
        if ($objVM.StartOrder -eq 3)
        {
            [Void]$Batch3.Add($objVM)
        }
    }

    #Any VMs whose start order is 4
    $Batch4 = New-Object System.Collections.ArrayList
    Foreach ($objVM in $arrVMs)
    {
        if ($objVM.StartOrder -eq 4)
        {
            [Void]$Batch4.Add($objVM)
        }
    }

    #Start Batch 0 first
    If ($Batch0.count -gt 0)
    {
        Write-Host "Starting CentOS Routers..." -ForegroundColor Green
    }
    Foreach ($objVM in $Batch0)
    {
        Write-Host " - Starting VM $($objVM.VMName)`..." -ForegroundColor Green
        $StartVMResult = Start-VirtualMachine $($ObjVM.VMName) (Get-PSSession -Id $($objVM.PSSessionID))
        If ($StartVMResult -eq $true)
        {
            Write-Host "   - $($objVM.VMName) started successfully!" -ForegroundColor Green
        } else {
            Write-Host "   - $($objVM.VMName) Failed to start! Please manually check." -ForegroundColor Red
        }
        #Wait for 5 seconds before starting next Vm
        Write-Host "   - Wait for 5 seconds " -ForegroundColor Green -NoNewline
        For ($i = 1; $i -le 5; $i++)
        {
            Write-Host "." -NoNewline
            Start-Sleep -seconds 1
        }
        Write-Host ""
    }
    Write-Host ""

    #Start Batch 1 next
    If ($Batch1.count -gt 0)
    {
        #Wait for 15 seconds before starting batch 1
        Write-Host "   - Wait for 5 seconds Before Next group of VMs " -ForegroundColor Green -NoNewline
        For ($i = 1; $i -le 5; $i++)
        {
            Write-Host "." -NoNewline
            Start-Sleep -seconds 1
        }
        Write-Host ""
        Write-Host "Starting Domain controllers..." -ForegroundColor Green
    }
    Foreach ($objVM in $Batch1)
    {
        Write-Host " - Starting VM $($objVM.VMName)`..." -ForegroundColor Green
        $StartVMResult = Start-VirtualMachine $($ObjVM.VMName) (Get-PSSession -Id $($objVM.PSSessionID))
        If ($StartVMResult -eq $true)
        {
            Write-Host "   - $($objVM.VMName) started successfully!" -ForegroundColor Green
        } else {
            Write-Host "   - $($objVM.VMName) Failed to start! Please manually check." -ForegroundColor Red
        }
        #Wait for 5 seconds before starting next Vm
        Write-Host "   - Wait for 5 seconds " -ForegroundColor Green -NoNewline
        For ($i = 1; $i -le 5; $i++)
        {
            Write-Host "." -NoNewline
            Start-Sleep -seconds 1
        }
        Write-Host ""
    }
    Write-Host ""

    #Start Batch 2 next
    If ($Batch2.count -gt 0)
    {
        #Wait for 15 seconds before starting batch 2
        Write-Host "   - Wait for 5 seconds Before Next group of VMs " -ForegroundColor Green -NoNewline
        For ($i = 1; $i -le 5; $i++)
        {
            Write-Host "." -NoNewline
            Start-Sleep -seconds 1
        }
        Write-Host ""
        Write-Host "Starting SQL servers and ConfigMgr site servers..." -ForegroundColor Green
    }
    Foreach ($objVM in $Batch2)
    {
        Write-Host " - Starting VM $($objVM.VMName)`..." -ForegroundColor Green
        $StartVMResult = Start-VirtualMachine $($ObjVM.VMName) (Get-PSSession -Id $($objVM.PSSessionID))
        If ($StartVMResult -eq $true)
        {
            Write-Host "   - $($objVM.VMName) started successfully!" -ForegroundColor Green
        } else {
            Write-Host "   - $($objVM.VMName) Failed to start! Please manually check." -ForegroundColor Red
        }
        #Wait for 5 seconds before starting next Vm
        Write-Host "   - Wait for 5 seconds " -ForegroundColor Green -NoNewline
        For ($i = 1; $i -le 5; $i++)
        {
            Write-Host "." -NoNewline
            Start-Sleep -seconds 1
        }
        Write-Host ""
    }
    Write-Host ""

     #Start Batch 3 next
    If ($Batch3.count -gt 0)
    {
        #Wait for 15 seconds before starting batch 3
        Write-Host "   - Wait for 5 seconds Before Next group of VMs " -ForegroundColor Green -NoNewline
        For ($i = 1; $i -le 5; $i++)
        {
            Write-Host "." -NoNewline
            Start-Sleep -seconds 1
        }
        Write-Host ""
        Write-Host "Starting All other servers..." -ForegroundColor Green
    }
    Foreach ($objVM in $Batch3)
    {
        Write-Host " - Starting VM $($objVM.VMName)`..." -ForegroundColor Green
        $StartVMResult = Start-VirtualMachine $($ObjVM.VMName) (Get-PSSession -Id $($objVM.PSSessionID))
        If ($StartVMResult -eq $true)
        {
            Write-Host "   - $($objVM.VMName) started successfully!" -ForegroundColor Green
        } else {
            Write-Host "   - $($objVM.VMName) Failed to start! Please manually check." -ForegroundColor Red
        }
        #Wait for 5 seconds before starting next Vm
        Write-Host "   - Wait for 5 seconds " -ForegroundColor Green -NoNewline
        For ($i = 1; $i -le 5; $i++)
        {
            Write-Host "." -NoNewline
            Start-Sleep -seconds 1
        }
        Write-Host ""
    }
    Write-Host ""

    #Start Batch 4 next
    If ($Batch4.count -gt 0)
    {
        #Wait for 15 seconds before starting batch 4
        Write-Host "   - Wait for 5 seconds Before Next group of VMs " -ForegroundColor Green -NoNewline
        For ($i = 1; $i -le 5; $i++)
        {
            Write-Host "." -NoNewline
            Start-Sleep -seconds 1
        }
        Write-Host ""
        Write-Host "Starting OpsMgr management servers..." -ForegroundColor Green
    }
    Foreach ($objVM in $Batch4)
    {
        Write-Host " - Starting VM $($objVM.VMName)`..." -ForegroundColor Green
        $StartVMResult = Start-VirtualMachine $($ObjVM.VMName) (Get-PSSession -Id $($objVM.PSSessionID))
        If ($StartVMResult -eq $true)
        {
            Write-Host "   - $($objVM.VMName) started successfully!" -ForegroundColor Green
        } else {
            Write-Host "   - $($objVM.VMName) Failed to start! Please manually check." -ForegroundColor Red
        }
        #Wait for 5 seconds before starting next Vm
        Write-Host "   - Wait for 5 seconds " -ForegroundColor Green -NoNewline
        For ($i = 1; $i -le 5; $i++)
        {
            Write-Host "." -NoNewline
            Start-Sleep -seconds 1
        }
        Write-Host ""
    }
}
Write-Host ""

#House Clean
#Close previously opened PSSessions
If ($arrPSSessionIds.count -gt 0)
{
    Write-Host "Closing PS Sessions..."
    Foreach ($Id in $arrPSSessionIds)
    {
        Get-PSSession -Id $Id | Remove-PSSession
    }
}
Write-Host "All Done! Have fun!" -ForegroundColor Green
#endregion