Function Get-AlertMonitors
{
    PARAM (
        [Parameter(Mandatory=$true,HelpMessage="OpsMgr Management Group Connection" )][Microsoft.EnterpriseManagement.ManagementGroup] $ManagementGroup,
        [Parameter(Mandatory=$false,HelpMessage="Monitoring Class Name" )][string] $MonitoringClassName = $null
    )
    
    $arrAlertMonitors = New-object System.Collections.ArrayList
    #firstly get all monitoring classes
    #Populate Search criteria
    If ($MonitoringClassName)
    {
        $strClassCriteria = "Name = '$MonitoringClassName'"
    } else {
        $strClassCriteria = "Name LIKE '%'"
    }
    $ClassCriteria = New-Object Microsoft.EnterpriseManagement.Configuration.MonitoringClassCriteria($strClassCriteria)
    $MonitoringClasses = $MG.GetMonitoringClasses($ClassCriteria)
    Foreach ($MC in $MonitoringClasses)
    {
        $MCId = $MC.Id
        $strMonitorCriteria = "TargetMonitoringClassId = '$MCId' AND AlertOnState IS NOT NULL"
        $MonitorCriteria = New-Object Microsoft.EnterpriseManagement.Configuration.MonitorCriteria($strMonitorCriteria)
        $Monitors = $MG.getmonitors($MonitorCriteria)
       Foreach ($Monitor in $Monitors)
        {
            #Add to arraylist
            [void]$arrAlertMonitors.Add($Monitor)
        }
    }
    ,$arrAlertMonitors
}