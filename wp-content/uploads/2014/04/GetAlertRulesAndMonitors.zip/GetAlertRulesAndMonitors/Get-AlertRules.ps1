Function Get-AlertRules
{
    PARAM (
        [Parameter(Mandatory=$true,HelpMessage="OpsMgr Management Group Connection" )][Microsoft.EnterpriseManagement.ManagementGroup] $ManagementGroup,
        [Parameter(Mandatory=$false,HelpMessage="Monitoring Class Name" )][string] $MonitoringClassName = $null
    )
    
    $arrAlertRules = New-object System.Collections.ArrayList
    #Get GenerateAlert WriteAction module
    $HealthMPId = [guid]"0abff86f-a35e-b08f-da0e-ff051ab2840c" #this is unique
    $HealthMP = $MG.GetManagementPack($HealthMPId)
    $AlertWA = $HealthMP.GetModuleType("System.Health.GenerateAlert")
    $AlertWAId = $AlertWA.Id
    #firstly get all monitoring classes
    #Populate Search criteria
    If ($MonitoringClassName)
    {
        $strClassCriteria = "Name = '$MonitoringClassName'"
    } else {
        $strClassCriteria = "Name LIKE '%'"
    }
    $ClassCriteria = New-Object Microsoft.EnterpriseManagement.Configuration.MonitoringClassCriteria($strClassCriteria)
    $MonitoringClasses = $MG.GetMonitoringClasses($ClassCriteria)
    Foreach ($MC in $MonitoringClasses)
    {
        $MCId = $MC.Id
        $strRuleCriteria = "TargetMonitoringClassId = '$MCId'"
        $RuleCriteria = New-Object Microsoft.EnterpriseManagement.Configuration.MonitoringRuleCriteria($strRuleCriteria)
        $Rules = $MG.GetMonitoringRules($RuleCriteria)
        Foreach ($rule in $Rules)
        {
            #Unfortunately, we cannot use a member module name/id in MonitoringRUleCriteria.
            #So we have to manually filter out the rules with GenerateAlert Write Action Module
            #Check if it has a GenerateAlert WriteAction module
            $bAlertRule = $false
            Foreach ($WAModule in $Rule.WriteActionCollection)
            {
                if ($WAModule.TypeId.Id -eq $AlertWAId)
                {
                    #this rule generates alert
                    $bAlertRule = $true
                } else {
                    #need to detect if it's using a customized WA which the GenerateAlert WA is a member of
                    $WAId = $WAModule.TypeId.Id
                    $WASource = $MG.GetMonitoringModuleType($WAId)
                    #Check each write action member modules in the customized write action module...
                    Foreach ($item in $WASource.WriteActionCollection)
                    {
                        $itemId = $item.TypeId.Id
                        If ($ItemId -eq $AlertWAId)
                        {
                            $bAlertRule = $true
                        }
                    }
                }

                if ($bAlertRule)
                {
                    #Add to arraylist
                    [void]$arrAlertRules.Add($rule)
                }
            }
        }
    }
    ,$arrAlertRules
}