Function Get-MonitoringClass
{
    PARAM (
        [Parameter(Mandatory=$true,HelpMessage="OpsMgr Management Group Connection" )][Microsoft.EnterpriseManagement.ManagementGroup] $ManagementGroup,
        [Parameter(Mandatory=$true,HelpMessage="Monitoring Class Display Name" )][string] $MonitoringClassDisplayName
    )
    
    #Populate Search criteria
    $strClassCriteria = "DisplayName = '$MonitoringClassDisplayName'"
    $ClassCriteria = New-Object Microsoft.EnterpriseManagement.Configuration.MonitoringClassCriteria($strClassCriteria)
    #Search monitoring class
    $MonitoringClasses = $MG.GetMonitoringClasses($ClassCriteria)
    $MonitoringClasses
}