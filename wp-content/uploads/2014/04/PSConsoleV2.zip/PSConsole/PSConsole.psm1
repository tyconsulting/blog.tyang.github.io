Function Resize-Console
{
<# 
 .Synopsis
  Resize PowerShell console window

 .Description
  Resize PowerShell console window. Make it bigger, smaller or increase / reduce the width and height by a specified number

 .Parameter -Bigger
  Increase the window's both width and height by 10.

 .Parameter -Smaller
  Reduce the window's both width and height by 10.

 .Parameter Width
  Resize the window's width by passing in an integer.

 .Parameter Height
  Resize the window's height by passing in an integer.

 .Example
   # Make the window bigger.
   Resize-Console -bigger
   Or
   resize -bigger
 .Example
   # Make the window smaller.
   Resize-Console -smaller
   OR
   resize -smaller
 .Example
   # Maximize the window on PRIMARY monitor
   Resize-Console -max
   OR
   resize -max
 .Example
   # Increase the width by 15.
   Resize-Console -Width 15
   Or
   resize -w 15
 .Example
   # Reduce the Height by 10.
   Resize-Console -Height -10
   OR
   resize -h -10
 .Example
   # Reduce the Width by 5 and Increase Height by 10.
   Resize-Console -Width -5 -Height 10
   OR
   resize -w -5 -h 10
 .Example
   # Resize the console window to a pre-configured profile
   Resize-Console -profile iPad
   OR
   resize -p iPad
#>

    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$false,HelpMessage="Increase Width and Height by 10")][Switch] $Bigger,
		[Parameter(Mandatory=$false,HelpMessage="Maximize the console")][Alias("m")][Switch] $max,
        [Parameter(Mandatory=$false,HelpMessage="Reduce Width and Height by 10")][Switch] $Smaller,
        [Parameter(Mandatory=$false,HelpMessage="Increase / Reduce Width")][Alias("w")][Int32] $Width,
        [Parameter(Mandatory=$false,HelpMessage="Increase / Reduce Height")][Alias("h")][Int32] $Height,
        [Parameter(Mandatory=$false,HelpMessage="Enter name of predefined size profile for Powershell Web Access (PSWA)")][Alias("p", "profile")][String] $PSWAProfile = $null
    )

    #Get Current Buffer Size and Window Size
    $bufferSize = $Host.UI.RawUI.BufferSize
    $WindowSize = $host.UI.RawUI.WindowSize
    If ($Bigger -and $Smaller)
    {
        Write-Error "Please make up your mind, you can't go bigger and smaller at the same time!"
    } else {
        if ($Bigger)
        {
            $NewWindowWidth = $WindowSize.Width + 10
            $NewWindowHeight = $WindowSize.Height + 10

            #Buffer size cannot be smaller than Window size
            If ($bufferSize.Width -lt $NewWindowWidth)
            {
                $bufferSize.Width = $NewWindowWidth
            }
            if ($bufferSize.Height -lt $NewWindowHeight)
            {
                $bufferSize.Height = $NewWindowHeight
            }
            $WindowSize.Width = $NewWindowWidth
            $WindowSize.Height = $NewWindowHeight
			#commit resize
	        $host.UI.RawUI.BufferSize = $buffersize
	        $host.UI.RawUI.WindowSize = $WindowSize


        } elseif ($Smaller)
        {
            $NewWindowWidth = $WindowSize.Width - 10
            $NewWindowHeight = $WindowSize.Height - 10
            $WindowSize.Width = $NewWindowWidth
            $WindowSize.Height = $NewWindowHeight
			#Buffer size cannot be smaller than Window size
			$bChangeBufferFirst = $false
            if ($bufferSize.Height -lt $NewWindowHeight)
            {
                #increase buffer height
				$bufferSize.Height = $NewWindowHeight
				$bChangeBufferFirst = $true
            }
			If ($bufferSize.Width -lt $NewWindowWidth)
            {
                #Increase buffer width
				$bufferSize.Width = $NewWindowWidth
				$bChangeBufferFirst = $true
            } else {
				$bufferSize.Width = $NewWindowWidth
			}
            
			if ($bChangeBufferFirst)
			{
				#commit resize
		        $host.UI.RawUI.BufferSize = $buffersize
		        $host.UI.RawUI.WindowSize = $WindowSize
			} else {
				#commit resize
				$host.UI.RawUI.WindowSize = $WindowSize	
		        $host.UI.RawUI.BufferSize = $buffersize		
			}
        }

        if ($Width)
        {
            #Resize Width
            $NewWindowWidth = $WindowSize.Width + $Width
			$WindowSize.Width = $NewWindowWidth
			#Buffer size cannot be smaller than Window size
			$bChangeBufferFirst = $false
			If ($bufferSize.Width -lt $NewWindowWidth)
            {
                #Increase buffer width
				$bufferSize.Width = $NewWindowWidth
				$bChangeBufferFirst = $true
            } else {
				$bufferSize.Width = $NewWindowWidth
			}
            
			if ($bChangeBufferFirst)
			{
				#commit resize
		        $host.UI.RawUI.BufferSize = $buffersize
		        $host.UI.RawUI.WindowSize = $WindowSize
			} else {
				#commit resize
				$host.UI.RawUI.WindowSize = $WindowSize	
		        $host.UI.RawUI.BufferSize = $buffersize		
			}
        }
        if ($Height)
        {
            #Resize Height
            $NewWindowHeight = $WindowSize.Height + $Height
            If ($bufferSize.Height -lt $NewWindowHeight)
            {
                $bufferSize.Height = $NewWindowHeight
            }
            $WindowSize.Height = $NewWindowHeight
			#commit resize
			$host.UI.RawUI.BufferSize = $buffersize
			$host.UI.RawUI.WindowSize = $WindowSize
        }
        if ($PSWAProfile)
        {
            #read predefined profiles from xml
			$profilePath = (Get-Module PSConsole).FileList[0]
            $xml = [xml](Get-Content $profilePath)
            $arrProfiles = $xml.profiles.profile
			Foreach ($item in $arrProfiles)
			{
				if ($item.name -ieq $PSWAProfile)
				{
					[int]$NewWindowWidth = $item.Width
					[int]$NewWindowHeight = $item.Height
					$WindowSize.Width = $NewWindowWidth
		            $WindowSize.Height = $NewWindowHeight
					#Buffer size cannot be smaller than Window size
					$bChangeBufferFirst = $false
		            if ($bufferSize.Height -lt $NewWindowHeight)
		            {
		                #increase buffer height
						$bufferSize.Height = $NewWindowHeight
						$bChangeBufferFirst = $true
		            }
					If ($bufferSize.Width -lt $NewWindowWidth)
		            {
		                #Increase buffer width
						$bufferSize.Width = $NewWindowWidth
						$bChangeBufferFirst = $true
		            } else {
						$bufferSize.Width = $NewWindowWidth
					}
		            
					if ($bChangeBufferFirst)
					{
						#commit resize
				        $host.UI.RawUI.BufferSize = $buffersize
				        $host.UI.RawUI.WindowSize = $WindowSize
					} else {
						#commit resize
						$host.UI.RawUI.WindowSize = $WindowSize	
				        $host.UI.RawUI.BufferSize = $buffersize		
					}
				}
			}

        }
        if ($max)
		{
			#This will not work when in PSWA sessions
			if ($Host.UI.RawUI.MaxPhysicalWindowSize)
			{
				$signature = @'

				[DllImport("user32.dll")]
				public static extern bool MoveWindow(
				IntPtr hWnd,
				int X,
				int Y,
				int nWidth,
				int nHeight,
				bool bRepaint);

				[DllImport("user32.dll")]
				public static extern IntPtr GetForegroundWindow();

				[DllImport("user32.dll")]
				public static extern bool GetWindowRect(
				HandleRef hWnd,
				out RECT lpRect);

				public struct RECT
				{
					public int Left;        // x position of upper-left corner
					public int Top;         // y position of upper-left corner
					public int Right;       // x position of lower-right corner
					public int Bottom;      // y position of lower-right corner
				}

'@
				Add-Type -MemberDefinition $signature -Name Wutils -Namespace WindowsUtils

				$newX = -4
				$newY = -4
				$phandle = [WindowsUtils.Wutils]::GetForegroundWindow()            

				$o = New-Object -TypeName System.Object            
				$href = New-Object -TypeName System.RunTime.InteropServices.HandleRef -ArgumentList $o, $phandle            

				$rct = New-Object WindowsUtils.Wutils+RECT

				[WindowsUtils.Wutils]::GetWindowRect($href, [ref]$rct) | out-null

				$width = $rct.Right - $rct.Left
				$height = $rct.Bottom - $rct.Top

				[WindowsUtils.Wutils]::MoveWindow($phandle, $newX, $newY, $width, $height, $false) | out-null

				$bufferSize = $Host.UI.RawUI.BufferSize
				$WindowSize = $host.UI.RawUI.WindowSize
				$maxSize = $Host.UI.RawUI.MaxPhysicalWindowSize
				$newheight = $maxSize.Height
				$newwidth = $maxsize.Width -3
				If ($bufferSize.Width -lt $maxSize.Width)
				{
					$bufferSize.Width = $newwidth
				}

				$bufferSize.Height = 9999
				$WindowSize.Width = $newwidth
				$WindowSize.Height = $newheight
				#commit resize
		        $host.UI.RawUI.BufferSize = $buffersize
		        $host.UI.RawUI.WindowSize = $WindowSize
			} else {
				Write-Error "You cannot maximize the console window when in PowerShell Web Access sessions!"
			}
		}
    }
}

Function Save-ConsoleProfile
{
<# 
 .Synopsis
  Save current console size to a profile so it can be re-used

 .Description
  Save current console size to a XML profile so it can be re-used later

 .Parameter -Name
  Name of the profile.

 .Example
   # Save current window to a size with a name "iPad"
   Save-ConsoleProfile -Name iPad
   Or
   scp -n iPad
#>
    [CmdletBinding()]
    PARAM (

        [Parameter(Mandatory=$true,HelpMessage="Enter name of of predefined size profile for Powershell Web Access (PSWA) that you wish to save")][Alias("n")][String] $Name
    )
	#get the profile Xml
	$profilePath = (Get-Module PSConsole).FileList[0]
    $xml = [xml](Get-Content $profilePath)
	$ExistingProfiles = @($xml.profiles.profile)
	$bNameTaken = $false
	Foreach ($item in $ExistingProfiles)
	{
		if ($item.Name -ieq $Name)
		{
			$bNameTaken = $true
		}
	}
	If ($bNameTaken)
	{
		Write-Error "The profile name you have specified `"$Name`" is already in use. Please choose another name"
	} else {
		#Get current console size
    	$WindowSize = $host.UI.RawUI.WindowSize
		$WindowWidth = $WindowSize.Width
		$WindowHeight = $WindowSize.Height
		#save config to xml
		$newprofile = $xml.Profiles.AppendChild($xml.CreateElement("Profile"))
		$NewProfileName = $newprofile.AppendChild($xml.CreateElement("Name"))
		$NewProfileWidth = $newprofile.AppendChild($xml.CreateElement("Width"))
		$NewProfileHeight = $newprofile.AppendChild($xml.CreateElement("Height"))
		$newprofile.Name = $Name
		$newprofile.Width = [string]$WindowWidth
		$newprofile.Height = [string]$WindowHeight
		$xml.save($profilePath)
		$newprofile
	}
}

Function Get-CurrentConsoleSize
{
<# 
 .Synopsis
  Get current console size

 .Description
  Get the current concole's window and buffer size


 .Example
   # Get the the current console size
   Get-CurrentConsoleSize
   OR
   gccs

#>
	
    #Get Current Buffer Size and Window Size
    $bufferSize = $Host.UI.RawUI.BufferSize
    $WindowSize = $host.UI.RawUI.WindowSize
	$objConsoleSize = New-Object psobject
	Add-Member -InputObject $objConsoleSize -MemberType NoteProperty -Name "Window Title" -Value $($host.UI.RawUI.WindowTitle)
	Add-Member -InputObject $objConsoleSize -MemberType NoteProperty -Name "Window Width" -Value $($WindowSize.Width)
	Add-Member -InputObject $objConsoleSize -MemberType NoteProperty -Name "Window Height" -Value $($WindowSize.Height)
	Add-Member -InputObject $objConsoleSize -MemberType NoteProperty -Name "Buffer Width" -Value $($bufferSize.Width)
	Add-Member -InputObject $objConsoleSize -MemberType NoteProperty -Name "Buffer Height" -Value $($bufferSize.Height)
	
	#return result
	$objConsoleSize
}

Function Get-ConsoleProfile
{
<# 
 .Synopsis
  Get console size profile

 .Description
  Get Console Size profile based on a name or list all profiles

 .Parameter -Name
  Name of the profile.

 .Example
   # Get the console profile with the name of "iPad"
   Get-ConsoleProfile -Name iPad
   OR
   gcp -n ipad
   OR
   gcp iPad

 .Example
   # Get the all currently saved console profiles
   get-ConsoleProfile
   OR
   gcp
#>
    [CmdletBinding()]
    PARAM (

        [Parameter(Mandatory=$false,HelpMessage="Enter name of the predefined size profile  that you wish to get")][Alias("n")][String] $Name = $null
    )
	#get the profile Xml
	$profilePath = (Get-Module PSConsole).FileList[0]
    $xml = [xml](Get-Content $profilePath)
	$ExistingProfiles = @($xml.profiles.profile)
	if ($Name)
	{
		#Get the the profile with the specific name
		$bProfileExists = $false
		Foreach ($item in $ExistingProfiles)
		{
			if ($item.Name -ieq $Name)
			{
				$bProfileExists = $true
				$theProfile = $item
			}
		}
		If (!$bProfileExists)
		{
			Write-Error "There is no profile with this name: $Name"
		}
	}
	#return results
	If ($Name)
	{
		$theProfile
	} else {
		$existingprofiles
	}
}

Function Remove-ConsoleProfile
{
<# 
 .Synopsis
  Remove a console size profile

 .Description
  Remove a  Console Size profile based on a name

 .Parameter -Name
  Name of the profile.

 .Example
   # Remove the console profile with the name of "iPad"
   Remove-ConsoleProfile -Name iPad
   OR
   rcp -n ipad
   OR
   rcp iPad

#>
    [CmdletBinding()]
    PARAM (

        [Parameter(Mandatory=$true,HelpMessage="Enter name of the predefined size profile  that you wish to remove")][Alias("n")][String] $Name
    )
	#get the profile Xml
	$profilePath = (Get-Module PSConsole).FileList[0]
    $xml = [xml](Get-Content $profilePath)
	$ExistingProfiles = @($xml.profiles.profile)
	if ($Name)
	{
		#Get the the profile with the specific name
		$bProfileExists = $false
		Foreach ($item in $ExistingProfiles)
		{
			if ($item.Name -ieq $Name)
			{
				$bProfileExists = $true
				$theProfile = $item
			}
		}
		If (!$bProfileExists)
		{
			Write-Error "There is no profile with this name: $Name"
		}else {
		 	#Delete this profile
			$xml.Profiles.RemoveChild($theProfile)
			$xml.save($profilePath)
			Write-Host "$Name deleted."
		 }
	} else {
		Write-Error "Please specify the name of the console size profile that you wish to delete"
	}
}

Function Update-ConsoleProfile
{
<# 
 .Synopsis
  Update an existing console size profile

 .Description
 Update the width or height of an existing console size profile

 .Parameter -Name
  Name of the profile.

 .Example
   # Update the console size profile "iPad" with existing window size.
   Update-ConsoleProfile -Name iPad
   Or
   ucp -n iPad
   
 .Example
   # Update the width console size profile "iPad" to 100
   Update-ConsoleProfile -Name iPad -width 100
   Or
   ucp -n iPad -w 100
   
 .Example
   # Update the height console size profile "iPad" to 30
   Update-ConsoleProfile -Name iPad -Height 30
   Or
   ucp -n iPad -h 30

 .Example
   # Update the width to 100 and the height console size profile "iPad" to 30 
   Update-ConsoleProfile -Name iPad -Width 100-Height 30
   Or
   ucp -n iPad -w 100 -h 30
#>
    [CmdletBinding()]
    PARAM (

        [Parameter(Mandatory=$true,HelpMessage="Enter name of the console size profile for Powershell Web Access (PSWA) that you wish to udpate")][Alias("n")][String] $Name,
		[Parameter(Mandatory=$false,HelpMessage="Enter the new width for the profile that you wish to update")][Alias("w")][int32] $Width,
		[Parameter(Mandatory=$false,HelpMessage="Enter the new height for the profile that you wish to update")][Alias("h")][int32] $Height
    )
	#get the profile Xml
	$profilePath = (Get-Module PSConsole).FileList[0]
    $xml = [xml](Get-Content $profilePath)
	$ExistingProfiles = @($xml.profiles.profile)
	$bProfileExists = $false
	Foreach ($item in $ExistingProfiles)
	{
		if ($item.Name -ieq $Name)
		{
			$bProfileExists = $true
			$theProfile = $item
		}
	}
	If (!$bProfileExists)
	{
		Write-Error "The profile `"$Name`" that you wish to update does not exist"
	} else {
		#Get current console size if no width and height specified
		If (!$Width -and !$Height)
		{
	    	$WindowSize = $host.UI.RawUI.WindowSize
			$WindowWidth = $WindowSize.Width
			$WindowHeight = $WindowSize.Height
			$theProfile.Width = [string]$WindowWidth
			$theProfile.Height = [string]$WindowHeight
		}
		#override width or height if specified from input
		If ($Width)
		{
			$WindowWidth = $Width
			$theProfile.Width = [string]$WindowWidth
		}
		if ($Height)
		{
			$WindowHeight = $Height
			$theProfile.Height = [string]$WindowHeight
		}
		
		#Update the xml
		$theProfile
		$xml.save($profilePath)
	}
}

#alias
New-Alias -Name resize -Value Resize-Console
New-Alias -Name rsc -Value Resize-Console
New-Alias -Name scp -Value Save-ConsoleProfile
New-Alias -Name gcp -Value Get-ConsoleProfile
New-Alias -Name rcp -Value Remove-ConsoleProfile
New-Alias -Name ucp -Value Update-ConsoleProfile
New-Alias -Name gccs -Value Get-CurrentConsoleSize
Export-ModuleMember -Alias * -Function *